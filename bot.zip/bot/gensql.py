import openai

openai.api_type = "azure"
openai.api_base = "https://jnj-ls-rg.openai.azure.com/"
openai.api_version = "2023-09-15-preview"
openai.api_key = "abc7a61ffc8748e885768d47d6221efe"

# Define the schema
schema = {
    "pdrmformula": ["FormulaStatus", "FormulaID"],
    "pdrmrawmaterial": ["RawMaterialID", "RawMaterialStatus", "PrimaryFunction"],
    "pdrmrawmaterialformulamapping": ["FormulaID", "RawMaterialID"],
    "pdrmrawmaterialregionmapping": ["Region", "RawMaterialID"],
    "pdrmrawmaterialsuppliercost": ["RawMaterial", "Supplier", "PerKgCost"]
}

def get_tables_for_columns(columns):
    """Helper function to determine which tables contain the given columns."""
    tables = set()
    for column in columns:
        for table, cols in schema.items():
            if column in cols:
                tables.add(table)
                break
    return tables

def generate_new_trial(input):
    # Extract requested columns from the input query
    columns = [word.strip(" ,") for word in input.split() if word.strip(" ,") in sum(schema.values(), [])]

    # Determine relevant tables
    relevant_tables = get_tables_for_columns(columns)
    
    # Prepare the prompt for the language model
    prompt = f"""
    You are a MySQL expert. User asks you questions about the given schema of the database. First, obtain the schema of the database to check the tables, column names, and datatypes, then generate simple MySQL correct queries.
    Here is the database schema:

    -- Table [pdrmformula]
    CREATE TABLE pdrmformula(
        FormulaStatus VARCHAR(50) NULL,
        FormulaID VARCHAR(50) NOT NULL
    );

    -- Table [pdrmrawmaterial]
    CREATE TABLE pdrmrawmaterial(
        RawMaterialID VARCHAR(50) NOT NULL,
        RawMaterialStatus VARCHAR(50) NULL,
        PrimaryFunction VARCHAR(50) NULL,
        PRIMARY KEY (RawMaterialID)
    );

    -- Table [pdrmrawmaterialformulamapping]
    CREATE TABLE pdrmrawmaterialformulamapping(
        FormulaID VARCHAR(50) NOT NULL,
        RawMaterialID VARCHAR(50) NOT NULL
    );

    -- Table [pdrmrawmaterialregionmapping]
    CREATE TABLE pdrmrawmaterialregionmapping(
        Region VARCHAR(50) NULL,
        RawMaterialID VARCHAR(50) NULL
    );

    -- Table [pdrmrawmaterialsuppliercost]
    CREATE TABLE pdrmrawmaterialsuppliercost(
        RawMaterial VARCHAR(500) NULL,
        Supplier VARCHAR(500) NULL,
        PerKgCost DECIMAL(18, 0) NULL
    );

    **User Query:**
    {input}

    **Your Task:**
    1. Translate the natural language query into a corresponding SQL query.
    2. Ensure that the query focuses on finding information based on the raw materials and region specified.
    3. Use the LIKE operator for filters instead of '=' in the WHERE clause (e.g., WHERE XYZ LIKE '%ABC%').
    4. Avoid unnecessary joins. If the requested attributes are present in the same table, do not perform any joins.

    Ensure the SQL query is correctly formatted and syntactically correct.
    """

    # Generate the SQL query using the OpenAI model
    response = openai.Completion.create(
        engine="chatbot35",
        prompt=prompt,
        temperature=0.7,
        max_tokens=1800,
        top_p=0.5,
        frequency_penalty=0,
        presence_penalty=0,
        best_of=1,
        stop=None
    )

    sql_query = response.choices[0].text.strip()
   
    # Return the SQL query
    return sql_query

# Example usage
if __name__ == "__main__":
    user_query = "give me formula id for formula statuses as 'Commercial'"
    sql_query = generate_new_trial(user_query)
    print(sql_query)
