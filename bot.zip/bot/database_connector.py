import mysql.connector

def execute_sql_query(query):
    # Define your database connection parameters
    config = {
        'user': 'root',
        'password': 'root',
        'host': 'localhost',
        'database': 'commandcenterdb_dev',
    }

    # Connect to the database
    conn = mysql.connector.connect(**config)
    cursor = conn.cursor()

    # Execute the query
    cursor.execute(query)

    # Fetch the results
    results = cursor.fetchall()

    # Get the column names
    column_names = [i[0] for i in cursor.description]

    # Close the connection
    cursor.close()
    conn.close()

    return column_names, results

# Example usage
if __name__ == "__main__":
    query = "SELECT * FROM pdrmrawmaterial;"
    column_names, results = execute_sql_query(query)
    print(column_names)
    for row in results:
        print(row)
