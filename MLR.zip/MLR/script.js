document.addEventListener('DOMContentLoaded', () => {
    const fileUpload = document.getElementById('file-upload');
    const previewImage = document.getElementById('preview-image');
    const fileName = document.getElementById('file-name');
    const fileSize = document.getElementById('file-size');
    const uploadBtn = document.getElementById('upload-btn');
    const browseBtn = document.getElementById('browse-btn');
    const resultPage = document.getElementById('result-page');
    const resultImage = document.getElementById('result-image');
    const resultFileName = document.getElementById('result-file-name');
    let selectedFile;

    browseBtn.addEventListener('click', () => {
        fileUpload.click();
    });

    fileUpload.addEventListener('change', (event) => {
        selectedFile = event.target.files[0];
        if (selectedFile) {
            const reader = new FileReader();
            reader.onload = function(e) {
                previewImage.src = e.target.result;
                previewImage.style.display = 'block';
                fileName.textContent = `Name: ${selectedFile.name}`;
                fileSize.textContent = `Size: ${(selectedFile.size / 1024).toFixed(2)} KB`;
            }
            reader.readAsDataURL(selectedFile);
        }
    });

    uploadBtn.addEventListener('click', () => {
        if (selectedFile) {
            resultImage.src = previewImage.src;
            resultFileName.textContent = selectedFile.name;
            document.querySelector('.upload-container').style.display = 'none';
            resultPage.style.display = 'block';
        }
    });
});
