import React, { useState, useEffect, useRef} from 'react';
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import CustomCard from './CustomCard';
import { Link } from 'react-router-dom';
import { fetchDataJointJs } from "../api/api";
import { dataConstants } from '../utils/constants';
import CustomDatePicker from './DatePicker';
import { timeFormat, calculateOverallTime,handleBackButtonClick } from '../utils/common';
import { SyncLoader } from 'react-spinners';
import { jobsInfo, demandJobsInfo, in0589APSJobsInfo, in0589endojobdata,in0428endoScoreForecast ,in0428endoScoreDemand} from '../data/jobsInfo'; // Import job lists
import MaterialUITable from './MaterialUITable';
import processJobData from './processJobData';
import backButtonImg from '../assets/backButtton.png';

const { columnDefs } = dataConstants;
const DataSourceFeedButton = ({ handleDataSourceFeedClick }) => {
  return (
      <button className='reportOverviewButton' onClick={handleDataSourceFeedClick}>
          Data Source Feed
      </button>
  );
};

const ReportOverviewButton = ({ handleReportDownloadClick }) => {
  return (
      <button className='reportOverviewButton' onClick={handleReportDownloadClick}>
          Report Overview
      </button>
  );
};
// let serialNumberCounter = 1;

const JobCardList = ({ gridData, serialNumberCounter, formattedDate, jobName }) => {
  return (
    <div className='row' style={{ marginLeft: '13px', marginBottom: '-2px' }}>
      {gridData.map((job, i) => (
        <div key={job['Sr.no']} className={gridData ? 'col-md-3' : 'col-md-4'}>
          <CustomCard
            job={job}
            serialNumber={serialNumberCounter++}
            headerName={job.Chain.startsWith('ZDP') ? 'BPU Process Chains' : 'APU Jobs'}
            formattedDate={formattedDate}
            jobName={jobName}
          />
        </div>
      ))}
    </div>
  );
};

const SliderComp = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { state } = location;
  const [loading, setLoading] = useState(true);
  const [breadcrumbPaths, setBreadcrumbPaths] = useState([]);
  const [jobName, setJobName] = useState(null);
  const [mergedData, setMergedData] = useState([]);
  const [gridData, setGridData] = useState(state ? state.gridData : []); 
  const mergedDataRef = useRef(null); // Ref to hold mergedData


 
  const [queryParameters] = useSearchParams()
  let urlDate = queryParameters.get("date")
  const [selectedDate, setSelectedDate] = React.useState(urlDate);

  const excelFileUrls = {
    'B11O013.dat': {
        path: './Files/B11O013.xlsx',
        sourceFeed: false,
    },
    'B11O012.dat': {
        path: './Files/IN0428 ETHICON - SCORE - Demand History.htm',
        sourceFeed: true,
    },
    'B11O011.dat': {
        path: './Files/IN0589 ETHICON - Forecast APS load v1.0.htm',
        sourceFeed: false,
    },
    'EES_FCST': {
        path: './Files/IN0589 ENDO- Demand Forecast load v1.0.htm',
        sourceFeed: false,
    },
    'EES_SCORE_FCST': {
        path: './Files/IN0428 ENDO - SCORE_FORECAST.htm',
        sourceFeed: false,
    },
    'EES_SCORE_DMND': {
      path: './Files/IN0428 ENDO - SCORE - Demand History.htm',
      sourceFeed: true,
  },
    // Add other mappings as needed
};

const handleReportDownloadClick = () => {


  if (!loading && state && state.fileName) {
    if (state.fileName.trim() === "B11O013.dat") {
      navigate("/ppt");
    } else {
      const fileInfo = excelFileUrls[state.fileName];
      if (fileInfo) {
        window.open(fileInfo.path, "_blank");
      } else {
        console.error("File URL not found for the given filename");
      }
    }
  }
};

  const getJobList = (jobName) => {
    switch (jobName) {
      case 'demandJobsInfo':
        return demandJobsInfo;
      case 'in0589APSJobsInfo':
        return in0589APSJobsInfo;
      case 'in0589endojobdata':
        return in0589endojobdata;
      case 'in0428endoScoreForecast':
        return in0428endoScoreForecast;
      case 'in0428endoScoreDemand':
        return in0428endoScoreDemand;
      // Add other cases for different job lists as needed
      default:
        return jobsInfo; // Default to jobsInfo if no specific job list is found
    }
  };

  const handleDateChange = (date) => {
    console.log("date", date);


    setSelectedDate(date);
   
  };
  
  useEffect(() => {
    if (state && state.gridData) {
      setLoading(false);
    }

    const fetchData = async () => {
      try {
        const response = await fetchDataJointJs();
        const { BPUProcessChains, apujobs } = response.data;
        const mergeData = [...BPUProcessChains, ...apujobs];
        setMergedData(mergeData);
        mergedDataRef.current = mergeData; // Update ref
        setLoading(false);
      } catch (error) {
        console.error('Error fetching data:', error);
        setLoading(false);
      }
    };

    fetchData();

    if (state && state.gridData && state.fileName) {
      const { fileName, jobName } = state;
      let label;
      if (fileName === 'B11O013.dat') {
        label = 'Statistical and Consensus Forecast [B11O013.dat]';
      } else if (fileName === 'B11O012.dat') {
        label = 'Demand Planning Order History [B11O012.dat]';
      } 
      else if (fileName === 'EES_FCST') {
        label = 'IN0589 Demand Forecast [EES_FCST.DAT]';
      } 
      else if (fileName === 'EES_SCORE_FCST') {
        label = 'IN0428 SCORE Forecast [EES_SCORE_FCST.DAT]';
      } 
      else if (fileName === 'EES_SCORE_DMND') {
        label = 'IN0428 Demand History [EES_SCORE_DMND.DAT]';
      } 
      else {
        label = 'IN0589 Forecast APS [B11O011.dat]';
      }
      const systems = [
        {
          name: 'ETHICON',
          jobNames: ['jobsInfo', 'demandJobsInfo', 'in0589APSJobsInfo'],
          link: '/reports?ETHICON',
          linkName:'home'
        },
        {
          name: 'ENDO',
          jobNames: ['in0589endojobdata', 'in0428endoScoreForecast','in0428endoScoreDemand'],
          link: '/reports?ENDO',
          linkName:'endo'
        },
        // Add more systems as needed
      ];
      
      const generateBreadcrumbPaths = (fileName, jobName) => {
        let system = '';
      
        // Find the system that matches the jobName
        systems.forEach(sys => {
          if (sys.jobNames.includes(jobName)) {
            system = sys;
          }
        });
      
        // Construct breadcrumb paths
        const breadcrumbPaths = [
          { label: 'Home', link: '/' },
          { label: system.name, link: system.link },
          { label: "Demand Planning", link: system.link },
          { label: 'Weekly', link: `/${system.linkName.toLowerCase()}?reportType=Weekly` },
          { label: label, isClickable: false }, // Add an isClickable property
        ];
      
        return breadcrumbPaths;
      };
      
const breadcrumbPaths = generateBreadcrumbPaths(fileName, jobName);
setBreadcrumbPaths(breadcrumbPaths);
      setJobName(jobName);
    }
  }, [state]);

  useEffect(() => {
    if (selectedDate && mergedDataRef.current && jobName) {
      const jobInfoList = getJobList(jobName);
      const updatedGridData = processJobData(jobInfoList, selectedDate, mergedDataRef.current);
      setGridData(updatedGridData);
    }
  }, [selectedDate, jobName]);
  
 
  const handleDataSourceFeedClick = () => {
    if (!loading) {
      const searchParams = new URLSearchParams(location.search);
      const dateParam = searchParams.get('date');
      navigate(`/bpmn?date=${dateParam}`, { state });
    }
  };

  if (!state || !state.gridData) {
    return null;
  }

  const { fileName,formattedDate} = state;
 
  
  let serialNumberCounter = 1; // Initialize the serial number counter

  let firstgridData, secondgridData, thirdgridData, fourthgridData, fifthgridData;
  if (gridData) {
    if (fileName === 'B11O013.dat') {
      firstgridData = gridData.slice(0, 4);
      secondgridData = gridData.slice(4, 8);
      thirdgridData = gridData.slice(8, 9);
    } else if (fileName === 'B11O012.dat') {
      // Adjust slicing logic for different file names
      firstgridData = gridData.slice(0, 3);
      secondgridData = gridData.slice(3, 7);
      thirdgridData = gridData.slice(7, 10);
    } else if (fileName === 'B11O011.dat') {
      // Adjust slicing logic for another file name
      firstgridData = gridData.slice(0, 4);
      secondgridData = gridData.slice(4, 7);
      thirdgridData = gridData.slice(7, 11);
      fourthgridData = gridData.slice(11, 16);
    }
    else if (fileName.includes('EES_FCST')) {
      // Adjust slicing logic for another file name
      firstgridData = gridData.slice(0, 2);
      secondgridData = gridData.slice(2, 5);
    }
    else if(fileName.includes('EES_SCORE_FCST')) {
      firstgridData = gridData.slice(0, 2);
      secondgridData = gridData.slice(2, 6);
      //EES Score FCST Added in File
    }
    else if(fileName.includes('EES_SCORE_DMND')) {
      firstgridData = gridData.slice(0, 3);
      secondgridData = gridData.slice(3, 7);
      thirdgridData = gridData.slice(7, 12);
    }
  }

  const updatedGridData = gridData.map((job) => ({
    ...job,
    runtimeStatus: calculateOverallTime(job, state.formattedDate) < 0 ? 'Yes' : 'No',
    exceededRuntime: calculateOverallTime(job, state.formattedDate) < 0 ? timeFormat(Math.abs(calculateOverallTime(job, state.formattedDate))) : '00:00:00',
}));

  // console.log("Pinned Top Row Data:", columnDefs.map((colDef) => colDef.headerName));
  const showDataSourceFeedButton = state && state.fileName && excelFileUrls[state.fileName] && excelFileUrls[state.fileName].sourceFeed;

  return (
<div className='backContainer' style={{ background: '#F2F2F2', display: 'flex', flexDirection: 'column' }}>
  <div className="display" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
    <div style={{ display: 'flex', alignItems: 'center', marginLeft:'6px' }}>
    <button onClick={handleBackButtonClick} style={{ backgroundImage: `url(${backButtonImg})`, backgroundSize: 'contain', backgroundRepeat: 'no-repeat', margin: '8px 0px 0px 0px', color: 'transparent', border: 'none', padding: '0', width: '40px', height: '40px', cursor: 'pointer' }}></button>
      <div className="breadcrumb-section" style={{ marginLeft: '10px' }}>
        {breadcrumbPaths.map((item, index) => (
          <span key={index}>
            {index !== breadcrumbPaths.length - 1 ? (
              <Link to={item.link}>{item.label}</Link>
            ) : (
              <span>{item.label}</span>
            )}
            {index < breadcrumbPaths.length - 1 && ' > '}
          </span>
        ))}
      </div>
    </div>
    <div style={{ display: 'flex', alignItems: 'center', marginLeft: 'auto' }}>
    <p style={{ color: '#007bff', marginRight: '10px' }}><span style={{ color: 'red' }}>*</span> All times in EST</p>
    <CustomDatePicker onChange={handleDateChange} selectedDate={selectedDate} placeholder={selectedDate} className='date-input' />
  </div>
   </div>

   {state && (
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', margin: '10px 0' }}>
                    {showDataSourceFeedButton && <DataSourceFeedButton handleDataSourceFeedClick={handleDataSourceFeedClick} />}
                    <ReportOverviewButton handleReportDownloadClick={handleReportDownloadClick} />
                </div>
            )}
            {loading && <SyncLoader color='#36D7B7' loading={true} size={15} />}
 
            {!loading && state && (
                <>
                    <JobCardList gridData={firstgridData} serialNumberCounter={serialNumberCounter} formattedDate={state.formattedDate} jobName={jobName} />
                    <JobCardList gridData={secondgridData} serialNumberCounter={serialNumberCounter} formattedDate={state.formattedDate} jobName={jobName} />
                    {thirdgridData && <JobCardList gridData={thirdgridData} serialNumberCounter={serialNumberCounter} formattedDate={state.formattedDate} jobName={jobName} />}
                    {fourthgridData && <JobCardList gridData={fourthgridData} serialNumberCounter={serialNumberCounter} formattedDate={state.formattedDate} jobName={jobName} />}
                </>
            )}
 
            {!loading && (
                <div className='TableAgGrid' style={{ marginTop: '10px' }}>
                    <MaterialUITable data={updatedGridData} columns={columnDefs} />
                </div>
            )}
    </div>
  );
};

export default SliderComp;
