import React, { useState, useEffect, useRef } from "react";
import { useLocation, useSearchParams } from "react-router-dom";
import { createRectangle, createCircle, createSDCircle, createErrorCircle, formatTableData, renderDatePicker,createFormattedLink } from '../utils/common';
import * as joint from "jointjs";
import { fetchData } from '../api/api';
import MaterialUITable from './MaterialUITable';
import { formatTime,handleBackButtonClick } from "../utils/common";
import { dataConstants } from '../utils/constants';
import { UsrotcConfig } from "../data/usrotcconfigs";
import backButtonImg from '../assets/backButtton.png';
const { tableColumns } = dataConstants;

const MyJointJSComponent = () => {
  const paperContainerRef = useRef(null);
  const location = useLocation();

  // Access 'Date' query parameter directly from location object
  const dateParam = new URLSearchParams(location.search).get("Date");
  const [queryParameters] = useSearchParams()
  let urlDate = queryParameters.get("Date")
  const [month, day, year] = urlDate.split('/');

  // Format the date as "yyyy-MM-dd"
  const formattedDate = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
  const [graphData, setGraphData] = useState({
    graph: null,
    rectDict: [],
  });

  const [selectedDate, setSelectedDate] = React.useState(urlDate)
  const [sourceFiles, setSourceFiles] = React.useState([]);
  const [targetFiles, setTargetFiles] = React.useState([]);
  const [source, setSource] = React.useState(0);
  const [target, setTarget] = React.useState(0);
  const [missing, setMissing] = React.useState(0);
  const [success, setSuccess] = React.useState(0);
  const [delayed, setDelayed] = React.useState(0);
  const [tableDataFiles, settableDataFiles] = React.useState([]);

  const handleDate = (date) => {
    handleChange(date, sourceFiles, targetFiles)
    setSelectedDate(date)
  }
  const e2eData = async () => {
    const allData = await fetchData();
    const sourceFile = allData.sourceFiles;
    const targetFile = allData.targetFiles;
    setSourceFiles(sourceFile);
    setTargetFiles(targetFile);
    handleChange(selectedDate, sourceFile, targetFile);
 
  }

  const formatDate = (date) => {
    return new Date(date).toLocaleDateString('en-US');
  };

  const filterByDate = (data, formattedDate) => {
    return data.filter(e => e.Date === formattedDate);
  };

  const filterByFilename = (data, string) => {
    return data.filter(item => item.filename.includes(string));
  };

  const countFilesByStatus = (data) => {
    return {
      success: data.filter(item => item.fileStatus === 'Success').length,
      delayed: data.filter(item => item.fileStatus === 'Delayed').length
    };
  };

  const findMissingFiles = (sourceData, targetData) => {
    const targetFilenames = new Set(targetData.map(item => item.filename));
    return sourceData.filter(item => !targetFilenames.has(item.filename));
  };

  const handleSearch = async () => {
 
    if (graphData.graph) {
      UsrotcConfig.forEach((item, index) => {
        createRectangle(item, graphData);
      });

      // Recursive function to render rectangles and links
      const renderRectanglesAndLinks = async (currentIndex) => {
        if (currentIndex < UsrotcConfig.length) {
          const item = UsrotcConfig[currentIndex];
          const sourceRect = graphData.rectDict[currentIndex];
          

          if (sourceRect) {

            sourceRect.addTo(graphData.graph);

            if (item.tasktype === "servicetask") {
              let targetRect = "";
              if (item.connection !== "") {
                targetRect = graphData.rectDict[item.connection];
              }

              if (targetRect) {
                targetRect.addTo(graphData.graph);
                createFormattedLink(graphData.graph, sourceRect, targetRect, item);
              }    
              
              if (source === target) {
                sourceRect.attr("body/fill", item.color);
                createCircle(graphData.graph, 575, 155, "green", "✓");
              } else {
                sourceRect.attr("body/fill", item.errorColor);
                createCircle(graphData.graph, 575, 155, "red", "✕");
              }  
              if (item.taskid === 5) {
                createErrorCircle(graphData.graph, item, "green", source);
              } else if (item.taskid === 6) {
                if (missing === 0) {
                  createSDCircle(graphData.graph, 470, 30, "green", success.toString(), "white");
                  createSDCircle(graphData.graph, 490, 30, "#FFBF00", delayed.toString(), "black");
                  createCircle(graphData.graph, 685, 30, "green", "✓");
                } else {
                  createSDCircle(graphData.graph, 470, 30, "green", success.toString(), "white");
                  createSDCircle(graphData.graph, 490, 30, "#FFBF00", delayed.toString(), "black");
                  createCircle(graphData.graph, 685, 30, "red", missing.toString());
                }
              } else if (item.taskid === 7) {
                if (missing === 0) {
                  createSDCircle(graphData.graph, 470, 210, "green", success.toString(), "white");
                  createSDCircle(graphData.graph, 490, 210, "#FFBF00", delayed.toString(), "black");
                } else {
                  createSDCircle(graphData.graph, 470, 210, "green", success.toString(), "white");
                  createSDCircle(graphData.graph, 490, 210, "#FFBF00", delayed.toString(), "black");
                }
              }
            
            }
          }
          await renderRectanglesAndLinks(currentIndex + 1);
        }
      };
      await renderRectanglesAndLinks(0);
    }
  };


  const handleChange = async(date, sourceData, targetData) => {
    const formattedDate = formatDate(date);
    const currentDateSourceData = filterByDate(sourceData, formattedDate);
    const currentDateTargetData = filterByDate(targetData, formattedDate);
    const gmed812SourceData = filterByFilename(currentDateSourceData, 'USROTC');
    const gmed812TargetData = filterByFilename(currentDateTargetData, 'USROTC');
    const gmedSourceCount = gmed812SourceData.length;
    const gmedTargetCount = gmed812TargetData.length;
    
    setSource(gmedSourceCount);
    setTarget(gmedTargetCount);
    
    const gmedTargetFileStatus = countFilesByStatus(gmed812TargetData);
    


    const missingFiles = findMissingFiles(gmed812SourceData, gmed812TargetData);
    const missingCount = missingFiles.length;
    setSuccess(gmedTargetFileStatus.success);
    setDelayed(gmedTargetFileStatus.delayed);
    setMissing(missingCount);

    await handleSearch();

    const tableData = formatTableData([...gmed812TargetData, ...missingFiles], gmed812TargetData, formatTime);
    settableDataFiles(tableData);
  };
  const initializeGraph = () => {
    const namespace = { ...joint.shapes };
    const graphPaper = new joint.dia.Graph({}, { cellNamespace: namespace });
    const paper = new joint.dia.Paper({
      el: paperContainerRef.current,
      model: graphPaper,
      width: 1220,
      height: 350,
      gridSize: 10,
      drawGrid: true,
      interactive: false,
      background: {
        color: "#ffffff",
      },
      cellViewNamespace: namespace,
    });
  
    setGraphData((prev) => {      
      prev.graph = graphPaper;
      return prev
    });
    
  };
  useEffect(() => {
    if (paperContainerRef.current) {
      initializeGraph();
    }
  }, [paperContainerRef]);

  useEffect(() => {
  e2eData();
}, [dateParam, source, target, missing,success, delayed ]);
  return (
    <div className="homeContainer" style={{ width: '100%' }}>
          <div className='display'>
  <div className="headerContainer">
  <button onClick={handleBackButtonClick} style={{ backgroundImage: `url(${backButtonImg})`, backgroundSize: 'contain', backgroundRepeat: 'no-repeat', margin: '8px 0px 0px 0px', color: 'transparent', border: 'none', padding: '0', width: '40px', height: '40px', cursor: 'pointer' }}></button>

    <p className="headerHome">IN0428 Demand Planning Order History (B11O012.dat)</p>
  </div>
  <div className='displayDate'>
    <div style={{ marginTop: '-10px',marginRight:'-190px' }}>
      <p style={{ color: '#007bff', marginBottom: '5px' }}><span style={{ color: 'red' }}>*</span> All times in EST</p>
    </div>
    <div style={{marginTop:'10px'}}>
      {renderDatePicker("", handleDate, selectedDate)}
    </div>
  </div>
</div>
      <div className="paper-container" ref={paperContainerRef}></div>
        <div className='tableAgGrid'>
        <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '16px', fontFamily: 'math', margin: '10px' }}>
          Total Records: {tableDataFiles.length}

        </div>
        <MaterialUITable data={tableDataFiles} columns={tableColumns} />
        </div> 
    </div>
  );
};
export default MyJointJSComponent;