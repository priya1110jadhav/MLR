import React from 'react';
import { Doughnut } from 'react-chartjs-2';
import { doughnutOptions } from "../utils/common";
const HomeCardsComponent = ({ header, chartData, percentage, semiComplete, Delay, FailedJob, pendingJobs, fileData,fileName }) => {
    // Filter the files based on the fileName
    const pmIndex = header.indexOf("PM");
const amIndex = header.indexOf("AM");
const pmBracketIndex = header.indexOf("]", pmIndex); // Index of "]" after "PM"
const amBracketIndex = header.indexOf("]", amIndex); // Index of "]" after "AM"
const splitIndex = Math.max(pmBracketIndex, amBracketIndex) + 1; // Add 1 to include "]" in the first line

const firstLine = header.slice(0, splitIndex + 1).trim(); // Include "]" in the first line
const secondLine = header.slice(splitIndex + 1).trim();
   
const filteredFiles = fileData
  .filter(file => {
    const endIndex = file.filename.toLowerCase().indexOf('.dat') + 4; // Get the index of '.DAT' and add 4 to include the extension
    const extractedFilename = file.filename.substring(0, endIndex);
    
    return extractedFilename.includes(fileName);
  })
  .map(file => {
    const endIndex = file.filename.toLowerCase().indexOf('.dat') + 4; // Get the index of '.DAT' and add 4 to include the extension
    const extractedFilename = file.filename.substring(0, endIndex);
    return {
      filename: extractedFilename,
      Date: file.Date
    };
  });



   

    return (
        <>
          <div className="col-md-3">
        
<div className='cardContainer' style={{textAlign: 'center',height:'110px'}}>
  {/* <p className='homeHeader' style={{padding:'20px',fontWeight: 'bold'}}>{header}</p> */}
  <p className='homeHeader' style={{ padding: '20px', fontWeight: 'bold' }}>
               <span style={{color:'#007bff'}} >{firstLine}</span> 
                <br />
                {secondLine}
              </p>
</div>
            <div>
              <Doughnut data={chartData} options={doughnutOptions} style={{ marginLeft: '-15px', marginBottom: '10px' }} />
            </div>
            <div className="chartLabel">{percentage}%</div>
      
            <div className="row">
              <p className='jobs'><span className='bullet completed'></span>Completed On Time:</p>
              <p className='jobsNum'>{semiComplete}</p>
            </div>
            <div className="row">
              <p className='jobs'><span className='bullet exceeded'></span>Completed But Delayed:</p>
              <p className='jobsNum'>{Delay}</p>
            </div>
            <div className='row'>
              <p className='jobs'><span className='bullet failed'></span>Failed:</p>
              <p className='jobsNum'>{FailedJob}</p>
            </div>
            <div className='row'>
              <p className='jobs'><span className='bullet pending'></span>Pending:</p>
              <p className='jobsNum'>{pendingJobs}</p>
            </div>
          </div>
            <div className='col-md-3'>
              <div className={filteredFiles.length > 0 ? "cardio" : "cardio reduced-height"}>
                <p className="cardioc">
                  {filteredFiles.length > 0 ? 'File Is Generated' : 'File In Progress..'}
                </p>
                {filteredFiles.length > 0 && (
                  <ul className='boxx'>
                    {filteredFiles.map((file, index) => (
                      <li key={index}>
                        <div className='filename'><span className='label'>File Name:</span> {file.filename}</div>
                        <div className='filenameDate' style={{fontSize:'15px', paddingTop:'5px', marginLeft:'-48px'}}><span className='label'>Date:</span> {file.Date}</div>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
       
        </>
      );
      
};

export default HomeCardsComponent;
