import moment from 'moment';
import { format } from "date-fns";

const convertTo12HourFormat = (timeString) => {
  const [hours, minutes, seconds] = timeString.split(":");
  const date = new Date(0, 0, 0, hours, minutes, seconds);

  return format(date, "hh:mm:ss a");
};

const getNextDayOfWeek = (startOfWeek, endOfWeek, dayName) => {
  const startDate = moment(startOfWeek, "MM/DD/YYYY");
  const endDate = moment(endOfWeek, "MM/DD/YYYY");

  let targetDay = startDate.clone().day(dayName);

  // If the target day is before the start date, move to the next occurrence within the range
  if (targetDay.isBefore(startDate)) {
    targetDay.add(7, 'days');
  }

  // If the target day is after the end date, return null
  if (targetDay.isAfter(endDate)) {
    return null;
  }

  return targetDay.format("MM/DD/YYYY");
};
const isDayOfWeek = (dateString, dayName) => {
  const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const date = new Date(dateString);
  const dayOfWeek = daysOfWeek[date.getDay()];
  return dayOfWeek === dayName;
};

const processJobData = (jobData, selectedDate, mergedData) => {
  const startOfWeek = moment(selectedDate, "MM/DD/YYYY").startOf('isoWeek').format("MM/DD/YYYY");
  const endOfWeek = moment(selectedDate, "MM/DD/YYYY").endOf('isoWeek').format("MM/DD/YYYY");

  console.log(startOfWeek,endOfWeek)

  const filteredDateData = mergedData.filter((job) => {
    const jobDate = job["Actual Start Date"];
    const formattedJobDate = moment(jobDate, "MM/DD/YYYY").format("MM/DD/YYYY");
    return formattedJobDate >= startOfWeek && formattedJobDate <= endOfWeek;
  });

  const isJobProcessed = (jobChain, processedData) => {
    return processedData.some(job => job.Chain === jobChain);
  };
  const getExpectedEndDate = (selectedDate, expectedEndDay) => {
    const startOfWeek = moment(selectedDate, "MM/DD/YYYY").startOf('isoWeek');
    const endOfWeek = moment(selectedDate, "MM/DD/YYYY").endOf('isoWeek');
    // Find the date of the expectedEndDay within the week range
    let expectedEndDate;
    if(expectedEndDay==='Sunday')
    {
    expectedEndDate=endOfWeek;
    }
  else
  {
  
  
    expectedEndDate = startOfWeek.clone().day(expectedEndDay);
    
  }
    return expectedEndDate.format("MM/DD/YYYY");
  };

  const processedData = [];

  jobData.forEach((jobInfo) => {
    
    // const expectedEndDate = moment(startOfWeek, "MM/DD/YYYY").day(jobInfo.expectedEndDay).format("MM/DD/YYYY");
    const occurrencesFiltered = [];
    let expectedEndDate = '';
    if (jobInfo.executes === "weekly") {
      const jobName = jobInfo.jobName;
      const dayOfWeek = jobInfo.day;
      expectedEndDate = getExpectedEndDate(selectedDate, jobInfo.expectedEndDay);
      
     
      
      let filteredJobs = filteredDateData.filter(job => job.Chain.includes(jobName) && isDayOfWeek(job["Actual Start Date"], dayOfWeek));
      if (filteredJobs.length === 0) {
        // Check for occurrences on the next day
        const nextDay = getNextDayOfWeek(startOfWeek, endOfWeek, dayOfWeek);
        if (nextDay) {
          const nextDate = moment(nextDay, "MM/DD/YYYY").add(1, 'days').format("MM/DD/YYYY"); // Adding 1 day to get the next day

          filteredJobs = filteredDateData.filter(job => {
            const isSameDay = moment(job["Actual Start Date"], "MM/DD/YYYY").isSame(moment(nextDate, "MM/DD/YYYY"), 'day');

            return job.Chain.includes(jobName) && isSameDay;
          });
        }
      }
      filteredJobs.sort((a, b) => moment(b["Actual Start Date"], "MM/DD/YYYY").valueOf() - moment(a["Actual Start Date"], "MM/DD/YYYY").valueOf());

      if (filteredJobs.length > 0) {
        occurrencesFiltered.push(filteredJobs[0]); // Push the latest occurrence
      }
    } else if (jobInfo.executes === "daily") {
      const jobName = jobInfo.jobName;
     
      const filteredJobs = filteredDateData.filter(job => job.Chain.includes(jobName));
      if (filteredJobs.length > 0) {
        const latestOccurrence = filteredJobs.reduce((latest, current) => {
          const latestDateTime = moment(`${latest["Actual Start Date"]} ${latest["Actual Start Time"]}`, "MM/DD/YYYY hh:mm:ss A");
          const currentDateTime = moment(`${current["Actual Start Date"]} ${current["Actual Start Time"]}`, "MM/DD/YYYY hh:mm:ss A");
          return currentDateTime.isAfter(latestDateTime) ? current : latest;
          
        });
        expectedEndDate = latestOccurrence["Actual Start Date"];
        if (!isJobProcessed(latestOccurrence.Chain, processedData)) {
          occurrencesFiltered.push(latestOccurrence);
        }
      }
    }
    


    if (occurrencesFiltered.length === 0) {
      processedData.push({
        Chain: jobInfo.jobName, // Push the job name as the Chain when no occurrences are found
        Status: null,
        "Actual Start Time": null,
        Runtime: null,        
        "Runtime [sec]": null,
        "Actual Start Date": null,
        "Actual End Date": null,
        "Actual End Time": null,
        "Expected Start Time": jobInfo.expectedStartTime,
        "Expected Run Time": jobInfo.expectedEndTime,
        "Expected End Date": expectedEndDate,
        "Interval": jobInfo.interval,
        percentage: 0
      });
    } else {
      occurrencesFiltered.forEach((job) => {
        processedData.push({
          Chain: job["Chain"],
          Status: job["Status"],
          "Actual Start Time": convertTo12HourFormat(job["Actual Start Time"]),
          Runtime: job["Runtime"],
          "Runtime [sec]": job["Runtime [sec]"],
          "Actual Start Date": job["Actual Start Date"],
          "Actual End Date": job["Actual End Date"],
          "Actual End Time": convertTo12HourFormat(job["Actual End Time"]),
          "Expected Start Time": jobInfo.expectedStartTime,
          "Expected Run Time": jobInfo.expectedEndTime,
          "Expected End Date": expectedEndDate,
          "Interval": jobInfo.interval,
          percentage: job["Status"] === 'Completed' || job["Status"] === 'Failed' ? 100 : 0
        });
      });
    }
  });
  
  return processedData;
};

export default processJobData;
