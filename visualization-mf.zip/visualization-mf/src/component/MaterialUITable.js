import React, { useState } from 'react';
import { TableContainer, Table, TableHead, TableBody, TableRow, TableCell, TablePagination, TextField, Button, TableSortLabel } from '@mui/material';
import { CSVLink } from 'react-csv';
import InputAdornment from '@mui/material/InputAdornment';
import SearchIcon from '@mui/icons-material/Search';
import dayjs from 'dayjs';

function MaterialUITable({ data, columns }) {
    
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [orderBy, setOrderBy] = useState('');
    const [order, setOrder] = useState('asc');
    const [filterText, setFilterText] = useState('');
    const [filterColumn, setFilterColumn] = useState('');

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };
    const handleSort = (field) => {
        const isAsc = orderBy === field && order === 'asc';
        setOrderBy(field);
        setOrder(isAsc ? 'desc' : 'asc');
    };

    const handleFilterChange = (event) => {
        setFilterText(event.target.value);
    };

    const handleFilterColumnChange = (event) => {
        setFilterColumn(event.target.value);
    };
    const filteredData = data.filter((row) => {
        if (!filterText) return true; // If filterText is empty, return true for all rows
        for (const column of columns) {
            const cellValue = String(row[column.field]).toLowerCase(); // Convert cell value to lowercase string
            if (cellValue.includes(filterText.toLowerCase())) {
                return true; // If the cell value contains the filter text, include the row in filtered data
            }
        }
        return false; // If none of the cells contain the filter text, exclude the row
    });

    const sortedData = orderBy
        ? filteredData.sort((a, b) => {
            const aValue = String(a[orderBy]); // Convert to string
            const bValue = String(b[orderBy]); // Convert to string
            return order === 'asc' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
        })
        : filteredData;

 
    const getExpectedTime = (filename) => {
        if (filename.includes('GMED')) {
            return 'Within every 5 mins for Every 3 Hours';
        } else if (filename.includes('LEAPLIVE')) {
            return '10:45 AM - 11:00 AM';
        } else if (filename.includes('USROTC_COD')) {
            return '23:00 PM - 00:00 AM';
        } else if (filename.includes('USROTC_ORTHO')) {
            return '5:00 AM - 8:00 AM';
        } else if (filename.includes('USROTC_MTK')) {
            return '1:00 AM - 2:00 AM';
        } else if (filename.includes('USROTC_SPN')) {
            return '00:00 AM - 1:30 AM';
        } else if (filename.includes('908')) {
            return '1:30 AM - 2:30 AM';
        } else {
            return '';
        }
    };
    return (
        <div>
       <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
    <TextField
        style={{ marginRight: '20px', flexGrow: 1}}
        label="Filter Here"
        variant="outlined"
        value={filterText}
        onChange={handleFilterChange}
        InputProps={{
            startAdornment: (
                <InputAdornment position="start">
                    <SearchIcon />
                </InputAdornment>
            ),
            sx: {
                borderRadius: '40px !important',
                height: '40px',
                width: '350px'
            }
        }}
    />
      <Button variant="contained" color="primary">
                <CSVLink
                    data={sortedData.map(row => ({
                        'Job Name': row.Chain || '',

                        'Status': row.Status || '',
                        'Actual Start Date': row['Actual Start Date'] || '',
                        'Expected Start Time': row['Expected Start Time'] || '',
                        'Actual Start Time': row['Actual Start Time'] || '',
                        'Expected End Time': row['Expected Run Time'] || '',
                        'Actual End Time': row['Actual End Time'] || '',
                        'Actual End Date': row['Actual End Date'] || '',
                        'Actual Runtime': row.Runtime || '',
                        'Exceeded Runtime': row.exceededRuntime || '',
                        'Frequency': row.Interval || '',
                        'Filename': row.filename || '', // Replace undefined/null with empty string
                        'FileSize (KB)': row.FileSize || '',
                        'Filesize in KB': row.FileSize || '',
                        'Date': row.Date || '',
                        'Date: MM/DD/YYYY': row.Date || '',
                        'Expected Time': row.filename ? getExpectedTime(row.filename) : '',
                        'Actual Receiving Time': row.Time || '',
                        'File Status': row.fileStatus || '',
                        'MSG': row.msg || row.MSG,
                        'Message': row.msg || row.MSG
                    }))}
                    headers={Object.keys(columns).map(key => columns[key].headerName)}
                    filename={'data.csv'}
                    style={{ color: 'white', textDecoration: 'none' }}
                >
                    Export CSV
                </CSVLink>
            </Button>
</div>


            <TableContainer style={{ maxHeight: '400px', overflow: 'auto', marginTop:'20px' }}>
                <Table stickyHeader>
                    <TableHead>
                        <TableRow>
                            {columns.map((column) => (

                                <TableCell key={column.field} align="center" sx={{ backgroundColor: '#007bff', color: 'white' }}>
                                    <TableSortLabel
                                        active={orderBy === column.field}
                                        direction={orderBy === column.field ? order : 'asc'}
                                        onClick={() => handleSort(column.field)}
                                    >
                                        {column.headerName}
                                    </TableSortLabel>
                                </TableCell>
                            ))}
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {sortedData.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row, index) => (
                            <TableRow key={index} sx={{ backgroundColor: getFileStatusBackgroundColor(row) }}>
                                {columns.map((column) => (
                                    <TableCell
                                        key={column.field}
                                        style={{
                                            color: 'black',
                                            fontSize: '12px',
                                            backgroundColor: column.field === 'fileStatus' ? getFileStatusColor(row.fileStatus) : getBackgroundColor(row)
                                        }}
                                    >
                                        {column.field === 'expectedTime' ? getExpectedTime(row.filename) : row[column.field]}
                                    </TableCell>
                                ))}
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
                <TablePagination
                    rowsPerPageOptions={[10, 15, 25]}
                    component="div"
                    count={data.length}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    onPageChange={handleChangePage}
                    onRowsPerPageChange={handleChangeRowsPerPage}
                />
            </TableContainer>

           
        </div>
    );

    function getBackgroundColor(row) {
        if (row.hasOwnProperty('fileStatus')) {
            // If fileStatus column is present, return empty string to allow other logic to handle coloring
            return "";
        } else if (row.exceededRuntime !== "00:00:00" || row.Status === "Inprogress") {
            return "#FFBF00"; // Amber color
        } else if (row.Status === "Failed") {
            return "#FFD6D6"; // Red color
        } else {
            return "#f8f8f8"; // Default row background color
        }
    }

    function getFileStatusColor(fileStatus) {
        if (fileStatus === "Success") {
            return "#0bda51"; // Green color
        } else if (fileStatus === "Delayed") {
            return "#FFBF00"; // Amber color
        } else {
            return "#f8f8f8"; // Default column background color
        }
    }

    function getFileStatusBackgroundColor(row) {
        return row.fileStatus ? "#f8f8f8" : "#FFBF00"; // Change row background color only if fileStatus is present
    }
}

export default MaterialUITable;
