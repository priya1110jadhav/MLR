import React, { useState } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
 
const CustomDatePicker = ({ onChange, selectedDate, placeholder }) => {
  // Initialize selectedDate to current date in local time zone
  const [startDate, setStartDate] = useState(selectedDate || placeholder);

 
  const handleDateChange = (date) => {
    setStartDate(date);
    
    onChange(date.toLocaleDateString('en-US', {
      month: '2-digit', // 2-digit numeric representation of the month
      day: '2-digit',   // 2-digit numeric representation of the day
      year: 'numeric'   // Full numeric representation of the year
    }));
  };
 
 
  return (
<div className='date-picker-main'>
<label>Select Date:</label>
<DatePicker
        selected={startDate}
        onChange={handleDateChange}
        dateFormat="MM/dd/yyyy"
        placeholderText={placeholder}
        maxDate={new Date()}
        className='date-input'
        showYearDropdown
        scrollableYearDropdown
        yearDropdownItemNumber={10}
        calendarStartDay={1}
        weekLabel="Wk#" 
        locale="en" 
        showWeekNumbers
        
      />
</div>
  );
};
 
export default CustomDatePicker;