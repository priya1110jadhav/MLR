
import React, { useState, useEffect } from 'react';
import { FaCogs } from 'react-icons/fa';
import { FaSitemap } from 'react-icons/fa';
import { IoHome } from "react-icons/io5";
import { NavLink } from 'react-router-dom';
import Logo from './Logo';
import './Dashboard.scss';

const Sidebar = ({ children }) => {
  const [currentDate, setCurrentDate] = useState('');

  useEffect(() => {
    const getCurrentDate = () => {
      const options = { month: 'long', day: 'numeric', year: 'numeric' };
      const today = new Date().toLocaleDateString('en-US', options);
      setCurrentDate(today);
    };

    getCurrentDate();
  }, []);

  const menuItem = [
    {
      path: '/home',
      name: 'Home',
      icon: <IoHome />,
    },
    // {
    //   path: '/dashboard',
    //   name: 'Dashboard',
    // },
  
    {
      path: '/bpmn',
      name: 'AIN0001',
      icon: <FaCogs />,
      // subMenu: [
      //   { path: '/bpmn/gmed', name: 'GMED' },
      //   { path: '/bpmn/leaplive', name: 'LAEPLIVE' },
      //   { path: '/bpmn/usrotc', name: 'USROTC' },
      // ],
    },
    {
      path: '/btb',
      name: 'IN0429',
      icon: <FaSitemap />,
      subMenu: [
        { path: '/btb/canada', name: 'BTBCANADA' },
        // { path: "/btb/japan", name: "BtBJAPAN" },
      ],
    },
  ];

  return (
    <div className="container">
      <Logo />
      <div className="sidebar">
        <div className="top_section"></div>
        {menuItem.map((item, index) => (
          <div key={index}>
            <NavLink to={item.path} className="link" activeClassName="active">
              <div className="icon">{item.icon}</div>
              <div className="link_text">{item.name}</div>
            </NavLink>
            {item.subMenu && (
              <div className="sub_menu">
                {item.subMenu.map((subItem, subIndex) => (
                  <NavLink
                    to={subItem.path}
                    key={subIndex}
                    className="link sub_link"
                    activeClassName="active"
                  >
                    <div className="sub_icon">{subItem.icon}</div>
                    <div className="sub_link_text">{subItem.name}</div>
                  </NavLink>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
      <main>
      <div className="header-container">
      {/* <p className="header" style={{ backgroundColor: 'white', display: 'inline-block' }}>
            {customHeader}
          </p> */}
  <svg
    className="custom-svg"  // Add a class to the SVG element
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    style={{ display: 'inline-block', verticalAlign: 'middle', marginLeft: '695px' }}
  >
    <path
      d="M13 17L18 12L13 7"
      stroke="#9F9F9F"
      style={{ stroke: '#9F9F9F', strokeOpacity: 1 }}
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M6 17L11 12L6 7"
      stroke="#9F9F9F"
      style={{ stroke: '#9F9F9F', strokeOpacity: 1 }}
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
  <p className="date">{currentDate}</p>
  {/* User greeting and icon */}
  <div style={{ display: 'flex', alignItems: 'center', marginLeft: '200px', fontFamily: 'Inter' }}>
  <p style={{ margin: '-25px 3px 2px 650px', marginRight: '10px' }}>Hello Priyanka</p>
  <div style={{ width: '30px', height: '30px', borderRadius: '50%', overflow: 'hidden', marginTop: '-30px' }}>
    <img src='/Image.png' alt="User Avatar" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
  </div>
</div>
</div>


        <hr className="line"/>
        {children}
      </main>
    </div>
  );
};
 {/* <p className='subHeader'>For Ethicon System [B11O13.dat]</p> */}

export default Sidebar;