import React, { useRef, useState, useEffect } from "react";
import Chart from "chart.js/auto";
import { useLocation } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import moment from "moment";
import { SyncLoader } from "react-spinners";
import { fetchDataJointJs } from "../api/api";
import CustomDatePicker from './DatePicker';
import { jobsInfo, demandJobsInfo, in0589APSJobsInfo } from "../data/jobsInfo";
import processJobData from './processJobData';
import HomeCardsComponent from "./HomeCardsComponent";
import {
  doughnutOptions,
  calculateOverallTime,
} from "../utils/common";
import Breadcrumb from "./Breadcrumb";
import { format } from "date-fns";

const useJobDataState = (initialCount = 0) => {
  const [semiComplete, setSemiComplete] = useState(initialCount);
  const [Delay, setDelay] = useState(initialCount);
  const [FailedJob, setFailedJobs] = useState(initialCount);
  let count = 0;
  const [chartData, setChartData] = useState();
  const [percentage, setPercentage] = useState(0);
  const [gridData, setGridData] = useState([]);
  const [totalJobs, setTotalJobs] = useState(0);
  const [completedJobs, setCompletedJobs] = useState(0);
  return {
    semiComplete,
    setSemiComplete,
    Delay,
    setDelay,
    FailedJob,
    setFailedJobs,
    count,
    chartData,
    setChartData,
    percentage,
    setPercentage,
    gridData,
    setGridData,
    totalJobs,
    setTotalJobs,  // Add setTotalJobs to the returned object
    completedJobs,
    setCompletedJobs,
  };
};
const HomeComponent = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [breadcrumbPaths, setBreadcrumbPaths] = useState([]);
  const chartRef = useRef(null);
  const [latestDate, setLatestDate] = useState(null);

  const jobDataState = useJobDataState();
  const demandJobDataState = useJobDataState();
  const in0589forecastDataState = useJobDataState();
  const [selectedDate, setSelectedDate] = useState(
    new Date().toLocaleDateString('en-US', {
      month: '2-digit', // 2-digit numeric representation of the month
      day: '2-digit',   // 2-digit numeric representation of the day
      year: 'numeric'   // Full numeric representation of the year
    })
  );

  const [apobwdatFilesNextWeek, setApobwdatFilesNextWeek] = useState([]);
  const [loading, setLoading] = useState(true);

  const handleDateChange = (date) => {


    setSelectedDate(date);
  };
  const handleDoughnutClick = (dataState, gridData, fileName, jobName) => {
    const formattedDate = moment(selectedDate).format('MM/DD/YYYY');
    navigate(`/processChains?date=${formattedDate}`, { state: { gridData, fileName, formattedDate, jobName } });
  };
  const convertTo12HourFormat = (timeString) => {
    const [hours, minutes, seconds] = timeString.split(":");
    const date = new Date(0, 0, 0, hours, minutes, seconds);

    return format(date, "hh:mm:ss a");
  };
  const updateChartData = (jobsData, dataState, counts) => {
    const completedJobs = jobsData.filter((job) => job.Status === "Completed" && job.percentage === 100);

    const completedPercentage = Math.round((completedJobs.length / jobsData.length) * 100);

    const delayedPerc = Math.round((counts / jobsData.length) * 100);
    const completedPerc = completedPercentage - delayedPerc;


    const FailedTheJobs = jobsData.filter((job) => job.Status === "Failed");
    const failedPerc = Math.round((FailedTheJobs.length / jobsData.length) * 100);

    const jobFailed = FailedTheJobs.length;
    const DelayedComp = completedJobs.length - counts;
    const pendingperc = 100 - completedPerc - failedPerc - delayedPerc;

    let delayedColor = "#FFBF00"; // Yellow color
    let completedColor = "#0BDA51"; // Green color
    let failedColor = "red"; // Red color
    let pendingColor = "#f2f2f2";

    if (completedPerc === 100) {
      delayedColor = "#f2f2f2"; // No delay, set delayed color to #f2f2f2
      failedColor = "#f2f2f2"; // No failure, set failed color to #f2f2f2
    } else if (delayedPerc === 0 && completedPerc > 0 && failedPerc === 0) {
      completedColor = "#0BDA51"; // Yellow color for combined completed and delayed
      failedColor = "#f2f2f2"; // No failure, set failed color to #f2f2f2
      delayedColor = "#f2f2f2";
    } else if (delayedPerc > 0 && completedPerc > 0 && failedPerc > 0) {
      completedColor = "red"; // Red color for combined completed, delayed, and failed
      delayedColor = "red";
    }
    else if (delayedPerc > 0 && failedPerc > 0) {
      completedColor = "red";
      delayedColor = "red";
    } else if (delayedPerc > 0 && failedPerc === 0) {
      completedColor = "#FFBF00"; // Yellow color for only delayed
      failedColor = "#FFBF00"; // No failure, set failed color to #f2f2f2
    } else if (completedPerc === 0 && delayedPerc === 0 && failedPerc === 0) {
      completedColor = "#f2f2f2";
      delayedColor = "#f2f2f2";
      failedColor = "#f2f2f2";
    } else if (failedPerc > 0) {
      completedColor = "red"; // Red color for combined delayed and failed
      delayedColor = "red";
    }

    const updatedChartData = {
      labels: ["Delayed", "Completed", "Failed", "Pending"],
      datasets: [
        {
          data: [delayedPerc, completedPerc, failedPerc, pendingperc],
          backgroundColor: [delayedColor, completedColor, failedColor, pendingColor],
          legend: { display: false },
        },
      ],
    };

    const updatedPercentage = completedPercentage;
    // Ensure dataState.chartData is updated correctly
    dataState.setChartData(updatedChartData);
    dataState.setPercentage(updatedPercentage);
    dataState.setTotalJobs(jobsData.length);
    dataState.setCompletedJobs(completedJobs.length);
    dataState.setSemiComplete(DelayedComp);
    dataState.setFailedJobs(jobFailed);
    dataState.setDelay(counts)

  };

  const fetchDataFromAPI = async () => {
    try {
      setLoading(true);
      const response = await fetchDataJointJs();
      const { apobwdatFiles, BPUProcessChains, apujobs } = response.data;
      const mergedData = [...BPUProcessChains, ...apujobs];

      //set latest date as refreshed date
      const dateObjects = mergedData.map(
        (item) => new Date(item["Last Updated Date"])
      );
      const maxDate = new Date(Math.max.apply(null, dateObjects));
      const formattedDate = moment(maxDate).format("YYYY-MM-DD HH:mm:ss");
      setLatestDate(formattedDate);

      const toDate = moment(selectedDate, "MM/DD/YYYY");
      const startOfWeek = toDate.clone().startOf('isoWeek');

      const endOfWeek = toDate.clone().endOf('isoWeek');
      console.log("start", startOfWeek, endOfWeek)
      const nextWeekFiles = apobwdatFiles.filter((file) => {
        const fileDate = moment(file.Date, "MM/DD/YYYY HH:mm:ss");
        return fileDate.isBetween(startOfWeek, endOfWeek, null, '[]'); // '[]' includes start and end dates
      });

      setApobwdatFilesNextWeek(nextWeekFiles);


      // Create or update the chart
      const renderChart = (data) => {
        if (chartRef.current) {
          const ctx = chartRef.current.getContext("2d");
          new Chart(ctx, {
            type: "doughnut",
            data: data,
            options: doughnutOptions,
          });
        }
      };

      renderChart(jobDataState.chartData);
      renderChart(demandJobDataState.chartData);
      renderChart(in0589forecastDataState.chartData)

      const selectedDateObj = new Date(selectedDate);


      // Usage example
      const jobInfoData = processJobData(jobsInfo, selectedDate, mergedData);
      const demandJobInfoData = processJobData(demandJobsInfo, selectedDate, mergedData);
      const in0589forecast = processJobData(in0589APSJobsInfo, selectedDate, mergedData);
      // Update state or perform further actions
      jobDataState.setGridData(jobInfoData);
      demandJobDataState.setGridData(demandJobInfoData);
      in0589forecastDataState.setGridData(in0589forecast);
      const jobCompletionStatus = {};
      jobInfoData.forEach((job) => {
        const overallTime = calculateOverallTime(job, selectedDate);

        if (overallTime < 0 && job['Status'] === 'Completed') {
          // Update dictionary value to 1 if overallTime is less than 0
          jobCompletionStatus[job.Chain] = 1;
        } else {
          // Set dictionary value to 0 if overallTime is not less than 0
          jobCompletionStatus[job.Chain] = 0;
        }
      });

      // Count the number of completed jobs (where value is 1 in the dictionary)
      jobDataState.count = Object.values(jobCompletionStatus).filter((value) => value === 1).length;

      updateChartData(jobInfoData, jobDataState, jobDataState.count);

      const demandJobCompletionStatus = {};
      demandJobInfoData.forEach((job) => {
        const overallTime = calculateOverallTime(job, selectedDate);

        if (overallTime < 0 && job['Status'] === 'Completed') {
          // Update dictionary value to 1 if overallTime is less than 0
          demandJobCompletionStatus[job.Chain] = 1;
        } else {
          // Set dictionary value to 0 if overallTime is not less than 0
          demandJobCompletionStatus[job.Chain] = 0;
        }
      });

      // Count the number of completed jobs (where value is 1 in the dictionary)
      demandJobDataState.count = Object.values(demandJobCompletionStatus).filter((value) => value === 1).length;


      updateChartData(demandJobInfoData, demandJobDataState, demandJobDataState.count);


      const in0589forecastCompletionStatus = {};
      in0589forecast.forEach((job) => {
        const overallTime = calculateOverallTime(job, selectedDate);

        if (overallTime < 0 && job['Status'] === 'Completed') {
          // Update dictionary value to 1 if overallTime is less than 0
          in0589forecastCompletionStatus[job.Chain] = 1;
        } else {
          // Set dictionary value to 0 if overallTime is not less than 0
          in0589forecastCompletionStatus[job.Chain] = 0;
        }
      });

      // Count the number of completed jobs (where value is 1 in the dictionary)
      in0589forecastDataState.count = Object.values(in0589forecastCompletionStatus).filter((value) => value === 1).length;

      updateChartData(in0589forecast, in0589forecastDataState, in0589forecastDataState.count);

      const searchParams = new URLSearchParams(location.search);
      const dateParam = searchParams.get("date");
      const paths = [
        { label: "Home", link: "/" },
        { label: "ETHICON", link: "/reports?ETHICON" },
        { label: "Demand Planning", link: "/reports?ETHICON" },

        { label: "Weekly", link: "/home?reportType=Weekly" },
      ];
      setBreadcrumbPaths(paths);

      setLoading(false);
    } catch (error) {
      console.error("Error fetching data from API:", error);
      setLoading(false);
      // Handle error as needed
    }
  };
  useEffect(() => {

    fetchDataFromAPI();
  }, [selectedDate]);
  // useEffect(() => {
  //   if (location.state && location.state.from === "handleDoughnutClick") {
  //     const searchParams = new URLSearchParams(location.search);
  //     const dateParam = searchParams.get("date");
  //     const paths = [
  //       { label: "Home", link: "/" },
  //       { label: "ETHICON", link: "/reports?ETHICON" },
  //       { label: "Weekly", link: "/home?reportType=Weekly" },
  //       {
  //         label: "Statistical & Consensus Report",
  //         link: `/processChains?date=${dateParam}`,
  //       },
  //     ];
  //     setBreadcrumbPaths(paths);
  //   }
  //   setPreviousPath(location.pathname);
  // }, [location.state, location.pathname]);


  return (
    <div className="homeContainer">
      {loading ? (
        <div className="spinner-container">
          <SyncLoader color="#36D7B7" loading={loading} size={15} />
        </div>
      ) : (
        <div className="display">
          <div className="breadcrumb-section">
            <Breadcrumb paths={breadcrumbPaths} />
          </div>
          <div className="right-section">
            <p className="last-refresh">
              Last Refresh: {latestDate}<span style={{ color: 'red', marginLeft: '10px' }}>*</span> <span style={{ color: '#007bff' }}>All times in EST</span>
            </p>
            {/* <CustomDatePicker onChange={handleDateChange} placeholder={selectedDate} className='date-input' /> */}

            <CustomDatePicker onChange={handleDateChange} selectedDate={selectedDate} placeholder={selectedDate} className='date-input' />

          </div>
        </div>
      )}

      {!loading && (
        <>
          <div className="row mx-auto" style={{ marginTop: '-20px', marginLeft: '20px' }}>
            <HomeCard

              header="[Saturday 03:30 PM EST] IN0428 Statistical & Consensus Forecast [B11O013.dat]"
              chartData={jobDataState.chartData}
              percentage={jobDataState.percentage}
              semiComplete={jobDataState.semiComplete}
              Delay={jobDataState.Delay}
              FailedJob={jobDataState.FailedJob}
              pendingJobs={jobDataState.totalJobs - jobDataState.completedJobs - jobDataState.FailedJob}
              fileData={apobwdatFilesNextWeek}
              fileName={"B11O013.dat"}
              onClick={() => handleDoughnutClick(jobDataState, jobDataState.gridData, "B11O013.dat", "jobsInfo")}
            />
            <HomeCard

              header="[Saturday 06:00 PM EST] IN0428 Demand Planning Order History [B11O012.dat]"
              chartData={demandJobDataState.chartData}
              percentage={demandJobDataState.percentage}
              semiComplete={demandJobDataState.semiComplete}
              Delay={demandJobDataState.Delay}
              FailedJob={demandJobDataState.FailedJob}
              pendingJobs={demandJobDataState.totalJobs - demandJobDataState.completedJobs - demandJobDataState.FailedJob}
              fileData={apobwdatFilesNextWeek}
              fileName={"B11O012.dat"}
              onClick={() => handleDoughnutClick(demandJobDataState, demandJobDataState.gridData, "B11O012.dat", "demandJobsInfo")}
            />
            <HomeCard

              header="[Friday 07:10 AM EST] IN0589 Ethicon Forecast APS [B11O011.dat]"
              chartData={in0589forecastDataState.chartData}
              percentage={in0589forecastDataState.percentage}
              semiComplete={in0589forecastDataState.semiComplete}
              Delay={in0589forecastDataState.Delay}
              FailedJob={in0589forecastDataState.FailedJob}
              pendingJobs={in0589forecastDataState.totalJobs - in0589forecastDataState.completedJobs - in0589forecastDataState.FailedJob}
              fileData={apobwdatFilesNextWeek}
              fileName={"B11O011.dat"}
              onClick={() => handleDoughnutClick(in0589forecastDataState, in0589forecastDataState.gridData, "B11O011.dat", "in0589APSJobsInfo")}
            />
          </div>
        </>
      )}
    </div>
  );
};

const HomeCard = ({ header, chartData, percentage, semiComplete, Delay, FailedJob, pendingJobs, fileData, fileName, onClick }) => (
  <div className="col-md-3">
    <div className="card-Home" onClick={onClick}>
      <HomeCardsComponent

        header={header}
        chartData={chartData}
        percentage={percentage}
        semiComplete={semiComplete}
        Delay={Delay}
        FailedJob={FailedJob}
        pendingJobs={pendingJobs}
        fileData={fileData}
        fileName={fileName}
      />
    </div>
  </div>
);
export default HomeComponent;


