import React, { useEffect, useState } from 'react';
import { NavLink ,useNavigate} from 'react-router-dom';
import logo_light from '../assets/JnJLogo2.png';
import logo_dark from '../assets/JnJLogo2.png';
import search_icon_light from '../assets/search-w.png';
import search_icon_dark from '../assets/search-b.png';
import toogle_light from '../assets/day.png';
import toogle_dark from '../assets/night.png';
import people from '../assets/Image.png';
import home_icon from '../assets/home.png'; // Import the home icon image
import about from '../assets/about.png';
import techStackImg from '../assets/techStack.png';

const Navbar = ({ theme, setTheme }) => {
  const navigate = useNavigate();

  const [currentDate, setCurrentDate] = useState('');

  const [activeLink, setActiveLink] = useState('Home');
  const handleAboutClick = () => {
    
    navigate('/about');
  };
  

 
  useEffect(() => {
    const getCurrentDate = () => {
      const options = { month: 'long', day: 'numeric', year: 'numeric' };
      const today = new Date().toLocaleDateString('en-US', options);
      setCurrentDate(today);
    };

    getCurrentDate();
  }, []);

  const toggle_mode = () => {
    theme === 'light' ? setTheme('dark') : setTheme('light');
  };

  return (
    <div className='navbar'>
      <NavLink to="/">
        <img src={theme === 'light' ? logo_light : logo_dark} alt="" className='logo' />
        <img src={home_icon} alt="Home" className='home-icon' /> {/* Home icon */}
      </NavLink>
      <ul>
        <li>
        <p className='dashboardName'>Back To Basics - DePuy Synthes MiTek & Joints Planning Reports</p>
      
        </li>
       
      </ul>
      
      
      <div style={{display:'contents'}}>
         <img src={about} alt="" className='people' onClick={handleAboutClick} />
      
      {/* <p className='user'>Hello Priyanka</p> */}
      
      {/* <img src={people} alt="" className='people' /> */}
      {/* <img onClick={() => { toggle_mode() }} src={theme === 'light' ? toogle_dark : toogle_light} alt="" className='toggle-icon' /> */}
    </div>
    
    </div>
  );
    };

export default Navbar;
