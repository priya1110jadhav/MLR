import * as React from 'react';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import { TreeView, TreeItem } from '@mui/x-tree-view';

const getSteps = (treeData, id) => {
  let steps = [];
  const findPath = (obj, targetId) => {
    if (obj.id === targetId) {
      steps.push(obj.name);
      return steps
    }

    if (obj.children) {
      for (let i = 0; i < obj.children.length; i++) {
        steps.push(obj.name);
        let result = findPath(obj.children[i], targetId);
        if (result) {
          return result;
        }
        steps.pop();
      }
    }
  }

  return findPath(treeData, id);
}

export const Tree = (props) => {
  const { setSalesOrderData, setBreadcrumbsData, treeStructure, setCurrentGraphData } = props
  const treeData = {
    id: 'root',
    name: 'Business Process Explorer',
    children: [{
      id: 'subroot',
      name: 'Business Scenarios',
      children: [treeStructure.children[0]]
    }],
  };

  const renderTree = (nodes, isFirstNode = true) => {
    return (
      <TreeItem
        key={nodes.id}
        nodeId={nodes.id}
        label={nodes.name}
        onClick={() => {
          setBreadcrumbsData(getSteps(treeData, nodes.id));
          setCurrentGraphData({
            labels: [],
            datasets: [],
          })
          setSalesOrderData(nodes.data ? nodes.data : []);
        }}
      >
        {Array.isArray(nodes.children)
          ? nodes.children.map((node, index) =>
            renderTree(node, isFirstNode && index === 0)
          )
          : null}
      </TreeItem>
    );
  };

  return (
    <TreeView
      defaultCollapseIcon={<ExpandMoreIcon />}
      defaultExpanded={['root']}
      defaultExpandIcon={<ChevronRightIcon />}
    >
      {renderTree(treeData)}
    </TreeView>
  );
}