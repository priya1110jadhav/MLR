import { AppBar, Box, Divider, Grid, Typography } from '@mui/material';
import { Tree } from './Tree.component'
import { useState } from 'react';
import { BreadcrumbComponent } from './BreadCrumbs.component';
import { SalesOrderComponent } from './SalesOrder.component';
import dayjs from 'dayjs';


export const HomePageComponent = (props) => {
    const { graphData ,treeData } = props
    const [salesOrderData, setSalesOrderData] = useState([])
    const [breadcrumbsData, setBreadcrumbsData] = useState(["Business Process Explorer"])
    const [currentGraphData, setCurrentGraphData] = useState({
        labels: [],
        datasets: [],
    })
    return <Grid container>
        <Grid item xs={2.8}>
            <Box className="sidebar component-background-color">
                <AppBar position="sticky" elevation={0}>
                    <div className='logo-container'>
                        <Box
                            component="img"
                            className='logo'
                            src="/JnJLogo2.png"
                        />
                    </div>
                </AppBar>
                <Tree
                    setSalesOrderData={setSalesOrderData}
                    treeStructure={treeData}
                    setBreadcrumbsData={setBreadcrumbsData}
                    setCurrentGraphData={setCurrentGraphData}
                />
            </Box>
        </Grid>
        <Grid item xs={9.2}>
            <Box className="breadcrumbs-container component-background-color">
                <Typography variant='h6' sx={{ m: 1 }}>BPMON_PROD({dayjs().format("DD-MMMM-YYYY")})</Typography>
            </Box>
            <BreadcrumbComponent data={breadcrumbsData} />
            <Divider variant="middle" />
            <SalesOrderComponent
                salesOrderData={salesOrderData}
                graphData={graphData}
                currentGraphData={currentGraphData}
                setCurrentGraphData={setCurrentGraphData}
            />
        </Grid>
    </Grid>
}