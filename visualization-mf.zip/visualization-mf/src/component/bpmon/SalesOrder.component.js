import { useEffect, useState } from "react";
import { Button, Divider, Grid } from "@mui/material";
import { CardComponent } from "./Card.component";
import { ChartComponent } from "./Chart.component";
import { DateRangePicker } from "rsuite";
import { dateFormat } from "./common";
import LaunchIcon from "@mui/icons-material/Launch";
import dayjs from "dayjs";

export const SalesOrderComponent = (props) => {
  let { salesOrderData, graphData, currentGraphData, setCurrentGraphData } =
    props;
  const [selectedId, setSelectedId] = useState("");
  const [filterDates, setFilterDates] = useState();
  const [tempGraphValues, setTempGraphValues] = useState();
  const [redirectUrl, setRedirectUrl] = useState();

  salesOrderData = salesOrderData.map((parentEle) => ({
    ...parentEle,
    csvData: graphData?.filter(
      (graphEle) => graphEle.LMO_ID === parentEle.lmoId
    ),
  }));
  useEffect(() => {
    setSelectedId("");
  }, [graphData]);

  const dateRangeFilter = (newValues) => {
    const [fromDate, toDate] = [
      dateFormat(newValues[0]),
      dateFormat(newValues[1]),
    ];
    if (fromDate && toDate) {
      const spliceArr = [];
      for (let i = 0; i < currentGraphData.labels.length; i++) {
        const currEle = new Date(currentGraphData.labels[i]);
        if (!(currEle >= new Date(fromDate) && currEle <= new Date(toDate))) {
          spliceArr.push(i);
        }
      }
      if (spliceArr.length !== 0) {
        const filterArr = (originalArr) => {
          const newArr = [...originalArr];
          for (var i = spliceArr.length - 1; i >= 0; i--)
            newArr.splice(spliceArr[i], 1);
          return newArr;
        };
        const itemSet = [];
        for (let i = 0; i < currentGraphData.datasets.length; i++) {
          itemSet.push({
            label: currentGraphData.datasets[i].label,
            data: filterArr(currentGraphData.datasets[i].data),
          });
        }
        setCurrentGraphData({
          labels: filterArr(currentGraphData.labels),
          datasets: itemSet,
        });
      }
    }
  };

  const handleCardClick = (id, selectedCardCsvData, name, ctxId) => {
    setSelectedId(id);
    setFilterDates(null);
    const data = selectedCardCsvData?.sort(
      (a, b) => new Date(a.TIMESTAMP) - new Date(b.TIMESTAMP)
    );
    const maximum = data?.map((e) => e.MAXIMUM);
    const dates = data?.map((e) => e.TIMESTAMP);
    const stateData = {
      labels: dates,
      datasets: [
        {
          label: name,
          data: maximum,
        },
      ],
    };
    setCurrentGraphData(stateData);
    setTempGraphValues(stateData);
    const date = dayjs().format("YYYYMMDD");
    const time = dayjs().format("HHmmss");
    let metricId = "",
      url;
    if (selectedCardCsvData?.length !== 0) {
      metricId = selectedCardCsvData[0].METRIC_HASH_ID;
      const REACT_APP_REDIRECT_URL_PROD =
        "https://wdmp2.jnj.com/sap/bc/gui/sap/its/webgui?%7etransaction=*%2fSDF%2fAD%20%2fSDF%2fAD-4%3d{date}%3b%2fSDF%2fAD-5%3d{time}%3b%2fSDF%2fAD-CONTEXT_ID%3d{ctxId}%3b%2fSDF%2fAD-DATE1%3d{date}%3b%2fSDF%2fAD-METRIC_ID%{metricId}%3b%2fSDF%2fAD-SOLMAN_INST%3d0020205066%3b%2fSDF%2fAD-SOLMAN_SID%3dMPC%3b%2fSDF%2fAD-TIME1%3d{time}%3b%2fSDF%2fAD-VALUE%3d212%20&sap-language=EN&sap-client=100";
      url = (REACT_APP_REDIRECT_URL_PROD || "")
        .replaceAll("{date}", date)
        .replaceAll("{time}", time)
        .replaceAll("{ctxId}", ctxId)
        .replaceAll("{metricId}", metricId);
    }
    setRedirectUrl(url);
  };

  const handleCompare = () => {
    let fromDate, toDate;

    if (filterDates) {
      // If date range is filtered, use filtered dates
      fromDate = new Date(filterDates[0]);
      toDate = new Date(filterDates[1]);
    } else {
      // If no date range is filtered, use the entire range of dates
      fromDate = new Date(
        Math.min(...graphData.map((e) => new Date(e.TIMESTAMP)))
      );
      toDate = new Date(
        Math.max(...graphData.map((e) => new Date(e.TIMESTAMP)))
      );
    }

    // Filter original data dates based on the date range
    const filteredDates = [...new Set(graphData.map((e) => e.TIMESTAMP))]
      .filter((date) => {
        const currentDate = new Date(date);
        return currentDate >= fromDate && currentDate <= toDate;
      })
      .sort((a, b) => new Date(a) - new Date(b));

    // Filter salesOrderData csvData based on the date range
    const filteredCsvData = salesOrderData.map((e) => ({
      ...e,
      csvData: e.csvData.filter((x) => {
        const date = new Date(x.TIMESTAMP);
        return date >= fromDate && date <= toDate;
      }),
    }));

    let datasets = filteredCsvData.map((e) => ({
      label: e.name,
      data: e.csvData.map((x) => x.MAXIMUM),
    }));

    const stateData = {
      labels: filteredDates,
      datasets: datasets,
    };

    setCurrentGraphData(stateData);
    setTempGraphValues(stateData);
  };

  return (
    <>
      {salesOrderData.length !== 0 && (
        <>
          <Grid container spacing={3} className="card-container">
            {salesOrderData.map((e, i) => (
              <Grid item>
                <CardComponent
                  name={e.name}
                  id={i}
                  selectedId={selectedId}
                  handleCardClick={() =>
                    handleCardClick(i, e.csvData, e.name, e.ctxId)
                  }
                />
              </Grid>
            ))}
          </Grid>
          <Divider variant="middle" sx={{ borderStyle: "dashed" }} />
          <Grid
            container
            xs={11.5}
            className="component-background-color chart"
          >
            <>
              <Grid container spacing={2}>
                <Grid item xs={5}>
                  <DateRangePicker
                    value={filterDates}
                    // onChange={data => onChange(data)}
                    onChange={(newv) => {
                      setFilterDates(newv);
                      setCurrentGraphData(tempGraphValues);
                      if (newv) {
                        dateRangeFilter(newv);
                      }
                    }}
                    // disabled={currentGraphData.labels.length === 0}
                    ranges={[]}
                    character=" ~ "
                    showMeridian
                    format="yyyy-MM-dd hh:mm aa"
                  />
                </Grid>
                <Grid item xs={3} sx={{ position: "static" }}>
                  <Button
                    variant="outlined"
                    style={{
                      textTransform: "none",
                    }}
                    onClick={handleCompare}
                  >
                    Check with other KPIs
                  </Button>
                </Grid>
                <Grid item xs={3} sx={{ position: "static" }}>
                  <Button
                    variant="outlined"
                    style={{
                      border: "none",
                      textTransform: "none",
                    }}
                    disabled={redirectUrl ? false : true}
                    onClick={() => {
                      const newTab = window.open(redirectUrl, "_blank");
                      newTab.focus();
                    }}
                  >
                    View More Details&nbsp;
                    <LaunchIcon />
                  </Button>
                </Grid>
              </Grid>
              <br />
              <ChartComponent dataset={currentGraphData} />
            </>
          </Grid>
        </>
      )}
    </>
  );
};
