import { useEffect, useState } from "react"
import { getGraphData, getTreeData } from "./api"
import { simplifyTree } from "./utilsConfig"
import { dateFormat } from './common'
import { HomePageComponent } from './HomePage.component';


const BpmonComponent = (props) => {
    props.setCssClass("temporary-app")
    const [graphData, setGraphData] = useState()
    const [treeData, setTreeData] = useState()

    const fetchTreeConfigAndGraphData = () => {
        getGraphData().then(data => {
            const res = data.response.map(e => ({ ...e, TIMESTAMP: dateFormat(`${e.TIMESTAMP}`) }))
            setGraphData(res)
        })
        getTreeData().then(data => {
            let tree = data.response
            if (tree) {
                for (let i = 0; i < tree.sections.length; i++) {
                    tree.sections[i]["section-content"] = JSON.parse(tree.sections[i]["section-content"])
                }
                const simplifiedTreeData = simplifyTree(tree)
                setTreeData(simplifiedTreeData)
            }
        })
    }

    useEffect(() => {
        fetchTreeConfigAndGraphData()
    }, [])

    return <>{graphData && treeData ?
        <HomePageComponent graphData={graphData} treeData={treeData} />
        : <>Loading...</>}</>
}

export default BpmonComponent