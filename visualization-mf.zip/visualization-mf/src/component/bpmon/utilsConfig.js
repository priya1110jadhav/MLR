// import { jsonConfig } from "./config";
// import { jsonConfig } from "./config2";
// import { jsonConfig } from "./config3";
export const simplifyTree = (jsonConfig) => {
    const nodes = jsonConfig.sections.find(e => e["section-id"] === "NODES")["section-content"]
    
    const heirarchy = jsonConfig.sections.find(e => e["section-id"] === "NODES-STRUCTURE")["section-content"]
    
    const monitoring = jsonConfig.sections.find(e => e["section-id"] === "MONITORING_OBJECTS")["section-content"]

    const findRoot = () => nodes.find(e => e.obj_type === "ROOT")

    const findChildren = (id) => heirarchy.find(e => e.parent_occ === id)?.children

    const findMonitoringObj = (id) => monitoring.D.MONITORING_DATA_TAB.find(e => e.LMO_ID === id)

    const findNode = (id) => {
        let data = nodes.find(e => e.occ_id === id)
        if (data?.attributes?.length > 0) {
            const obj = data.attributes.reduce((acc, curr) => {
                acc[curr["attr_type"]] = curr.values[0]
                return acc
            }, {})
            data.attributes = obj
        }
        return data
    }

    const getNode = (id) => {
        let data = findNode(id)
        if ((!data?.attributes?.DESCRIPTION) && (data?.reference !== "") && (data?.reference !== undefined)) {
            data = findNode(data?.reference)
        }
        return data
    }

    const constructParentChild = () => {
        function buildTree(node) {
            const getAttributes = getNode(node)
            const treeNode = {
                name: getAttributes?.attributes?.DESCRIPTION,
                type: getAttributes.obj_type,
                id: node,
                lmoId: getAttributes?.attributes?.LMO_ID,
                children: []
            };
            const getChildren = findChildren(node)
            if (getChildren) {
                for (const child of getChildren) {
                    treeNode.children.push(buildTree(child));
                }
            }
            return treeNode;
        }
        const idObj = findRoot()
        const tree = buildTree(idObj.occ_id);
        return tree
    }

    const getMonitorObj = (obj) => {
        let data = []
        if (obj && obj.length > 0) {
            data = obj.map(e => {
                const monitorData = findMonitoringObj(e.lmoId)
                return {
                    lmoId: e?.lmoId,
                    ctxId: monitorData?.MAI_CONFIG_DATA[0]?.MAI_CTX_ID || "",
                    docId: monitorData?.LMO_NAME ? monitorData?.LMO_NAME.toUpperCase() : "",
                    name: monitorData?.LMO_NAME
                }
            })
        }
        return data
    }


    const simplifyObject = (obj) => {
        if (obj.name === undefined && obj.children.length === 1 && obj.lmoId === undefined) {
            // if (obj.name === undefined && obj.children.length === 1) {
            return simplifyObject(obj.children[0]);
        } else {
            if (obj?.children && obj?.children[0]?.type && obj?.children[0]?.type === "PROCSTEPGRP") {
                obj.children = obj.children[0].children
            }
            if (obj?.children && obj?.children[0]?.type && obj?.children[0]?.type === "MONOBJGRP") {
                obj.data = getMonitorObj(obj?.children[0]?.children)
                obj.children = []
            }

            let simplifiedObj = {
                id: obj.id,
                name: obj.name || obj.type,
            };
            if (obj.lmoId) {
                simplifiedObj.lmoId = obj.lmoId
            }
            if (obj.children && obj.children.length !== 0) {
                simplifiedObj.children = []
            }
            if (obj.data) {
                simplifiedObj.data = obj.data
            }
            for (let i = 0; i < obj.children.length; i++) {
                simplifiedObj.children.push(simplifyObject(obj.children[i]));
            }
            return simplifiedObj;
        }
    }

    return simplifyObject(constructParentChild());
}
