import axios from "axios";

const BASEURL = `${process.env.REACT_APP_VISUALIZATION_MS_URL}/salesOrder`
export const getGraphData = async () => {
    const response = await axios.get(`${BASEURL}/graphData`).then(res => res.data)
    return response
}


export const getTreeData = async () => {
    const response = await axios.get(`${BASEURL}/treeConfig`).then(res => res.data)
    return response
}