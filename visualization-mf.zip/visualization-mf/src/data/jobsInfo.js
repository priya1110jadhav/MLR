export const jobsInfo = [
  { jobName: 'DPMDD5_WEEKLY_BATCH',
   expectedStartTime: '12:17:00 AM',
   expectedEndTime: '12:50:00 AM',
    jobDivisor: 1, executes: "weekly",day:'Saturday',expectedEndDay:'Saturday', frequency: 1,interval:1 },
  { jobName: 'DPMDD5_COPY_FCST_REL', expectedStartTime: '01:00:00 AM', expectedEndTime: '01:15:00 AM', jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Saturday', interval:1},
  { jobName: 'DPMDD5_BACKUP_FUTURE', expectedStartTime: '02:03:00 AM', expectedEndTime: '03:05:00 AM', jobDivisor: 1,executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Saturday', interval:1},
  { jobName: 'DPMDD5_MOD_LOC_DET', expectedStartTime: '03:05:00 AM', expectedEndTime: '03:55:00 AM', jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Saturday', interval:1},
  { jobName: 'ZDP_TRANS_FCST_PA5_PSA', expectedStartTime: '03:30:00 AM', expectedEndTime: '05:30:00 AM', jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Saturday', interval:1},
  { jobName: 'ZDP_TRANS_FCST_PLNGAREA_3', expectedStartTime: '04:00:00 AM', expectedEndTime: '05:30:00 AM', jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Saturday', interval:1},
  { jobName: 'ZDP_TRAN_FCST_PA5_PSA_MTD', expectedStartTime: '06:30:00 AM', expectedEndTime: '07:30:00 AM', jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Saturday', interval:1},
  { jobName: 'ZDP_TRANS_FCST_MANU', expectedStartTime: '12:15:00 PM', expectedEndTime: '02:30:00 PM', jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Saturday', interval:1},
  { jobName: 'ZDP_TRANS_FCST_ETHICON', expectedStartTime: '12:30:00 PM', expectedEndTime: '03:30:00 PM', jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Saturday', interval:1},
   ]
 
export const demandJobsInfo = [
  // { jobName: 'ZDP_TRANS_SO_COMPLETE', expectedStartTime: '04:00:00 AM', expectedEndTime: "07:00:00 AM" , jobDivisor: 2, executes: "daily", frequency: 2,interval:1 },
  // { jobName: 'ZDP_TRANS_SO_MERGE', expectedStartTime: '07:00:00 AM', expectedEndTime: "07:15:00 AM" , jobDivisor: 2, executes: "daily", frequency: 2 ,interval:1},
  // { jobName: 'ZDP_TRANS_OTC_COMPLETE', expectedStartTime: '07:15:00 AM', expectedEndTime: "09:30:00 AM" , jobDivisor: 2, executes: "daily", frequency: 2,interval:1 },
 
  { jobName: 'ZDP_TRANS_SO_COMPLETE', expectedStartTime: '04:00:00 PM', expectedEndTime: "07:00:00 PM" , jobDivisor: 2, executes: "daily", frequency: 2,interval:2 },
  { jobName: 'ZDP_TRANS_SO_MERGE', expectedStartTime: '07:00:00 PM', expectedEndTime: "07:15:00 PM" , jobDivisor: 2, executes: "daily", frequency: 2 ,interval:2},
  { jobName: 'ZDP_TRANS_OTC_COMPLETE', expectedStartTime: '07:15:00 PM', expectedEndTime: "09:30:00 PM" , jobDivisor: 2, executes: "daily", frequency: 2 ,interval:2},
 
  { jobName: 'DPMDD6_FCST_REL_SNP_CONS',expectedStartTime: '05:30:00 AM', expectedEndTime: "07:00:00 AM" ,jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Saturday', interval:1},
  { jobName: 'DP_BTB_LOAD_ORDER_HIST', expectedStartTime: '09:00:00 AM', expectedEndTime: "11:52:36 AM" , jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Saturday', interval:1},
  { jobName: 'DPMDD4_BACKUP_PAST', expectedStartTime: '12:15:00 PM', expectedEndTime: "01:17:47 PM" , jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Saturday', interval:1},
  { jobName: 'DPMDD5_BACKUP_PAST', expectedStartTime: '12:15:00 PM', expectedEndTime: "01:50:39 PM" , jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Saturday', interval:1},
 
  { jobName: 'ZDP_TRANS_WKBKP_PA4_PSA', expectedStartTime: '02:00:00 PM', expectedEndTime: "07:30:00 PM" , jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Saturday', interval:1},
  { jobName: 'ZDP_TRANS_WKBKP_PA5_PSA', expectedStartTime: '02:00:00 PM', expectedEndTime: "04:00:00 PM" , jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Saturday', interval:1},
  { jobName: 'ZDP_TRANS_SHIST_ETHICON', expectedStartTime: '04:00:00 PM', expectedEndTime: "06:00:00 PM" , jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Saturday', interval:1},
 
 
 
]
export const in0589APSJobsInfo = [
  { jobName: 'DPBTB_DAILY_BATCH_ASPAC', expectedStartTime: '01:00:00 PM', expectedEndTime: "01:30:00 PM" , jobDivisor: 1, executes: "weekly", day:"Friday",expectedEndDay:"Friday", frequency: 1,interval:1 },
  { jobName: 'DPBTB_DAILY_BATCH_EMEA', expectedStartTime: '05:00:00 PM', expectedEndTime: "05:15:00 PM" , jobDivisor: 1, executes: "weekly", day:"Friday",expectedEndDay:"Friday", frequency: 1,interval:1 },
  { jobName: 'DPMDD4_THURS_REL_CHAIN', expectedStartTime: '06:00:04 PM', expectedEndTime: "06:45:37 PM" , jobDivisor: 1, executes: "weekly", day:"Friday",expectedEndDay:"Friday", frequency: 1,interval:1 },
  { jobName: 'DPMDD6_DAILY_DCF_FORECAST', expectedStartTime: '07:00:03 PM', expectedEndTime: "07:06:00 PM" , jobDivisor: 1, executes: "weekly", day:"Friday",expectedEndDay:"Friday", frequency: 1,interval:1 },
  { jobName: 'DPMDD6_MOD_LOC_DET', expectedStartTime: '07:06:12 PM', expectedEndTime: "07:08:23 PM" , jobDivisor: 1, executes: "weekly", day:"Friday",expectedEndDay:"Friday", frequency: 1,interval:1 },
  { jobName: 'DPMDD5_DAILY_ETHICON_FCST', expectedStartTime: '06:00:05 PM', expectedEndTime: "06:57:27 PM" , jobDivisor: 1, executes: "weekly", day:"Friday",expectedEndDay:"Friday", frequency: 1,interval:1 },
  { jobName: 'DPMDD5_MOD_LOC_DET', expectedStartTime: '07:08:23 PM', expectedEndTime: "07:35:00 PM" , jobDivisor: 1, executes: "weekly", day:"Friday",expectedEndDay:"Friday", frequency: 1,interval:1 },
  { jobName: 'ZDP_TRANS_FCST_PA4_PSA', expectedStartTime: '06:45:00 PM', expectedEndTime: "06:45:10 PM" , jobDivisor: 1, executes: "weekly", day:"Friday",expectedEndDay:"Friday", frequency: 2,interval:1 },
  // { jobName: 'ZDP_TRANS_FCST_PA4_PSA', expectedStartTime: '06:45:00 PM', expectedEndTime: "06:45:10 PM" , jobDivisor: 1, executes: "weekly", day:"Friday",expectedEndDay:"Friday", frequency: 2,interval:2 },
 
  { jobName: 'ZDP_TRANS_FCST_PA6_PSA', expectedStartTime: '07:10:00 PM', expectedEndTime: "07:10:10 PM" , jobDivisor: 1, executes: "weekly", day:"Friday",expectedEndDay:"Friday", frequency: 1,interval:1 },
  { jobName: 'ZDP_TRANS_FCST_PA5_PSA', expectedStartTime: '07:10:00 PM', expectedEndTime: "07:10:40 PM" , jobDivisor: 1, executes: "weekly", day:"Friday",expectedEndDay:"Friday", frequency: 1,interval:1 },
  { jobName: 'ZDP_TRAN_FCST_PA4_PSA_MTD', expectedStartTime: '06:56:00 PM', expectedEndTime: "06:56:05 PM" , jobDivisor: 1, executes: "weekly", day:"Friday",expectedEndDay:"Friday", frequency: 2,interval:1 },
  // { jobName: 'ZDP_TRAN_FCST_PA4_PSA_MTD', expectedStartTime: '06:56:00 PM', expectedEndTime: "06:56:05 PM" , jobDivisor: 1, executes: "weekly", day:"Friday",expectedEndDay:"Friday", frequency: 2,interval:2 },
 
  { jobName: 'ZDP_TRAN_FCST_PA6_PSA_MTD', expectedStartTime: '07:11:00 PM', expectedEndTime: "07:12:30 PM" , jobDivisor: 1, executes: "weekly", day:"Friday",expectedEndDay:"Friday", frequency: 1,interval:1 },
  { jobName: 'ZDP_TRAN_FCST_PA5_PSA_MTD', expectedStartTime: '07:51:00 PM', expectedEndTime: "07:51:05 PM" , jobDivisor: 1, executes: "weekly", day:"Friday",expectedEndDay:"Friday", frequency: 1,interval:1 },
  { jobName: 'ZDP_TRANS_REPLENISH_FCST', expectedStartTime: '07:00:00 PM', expectedEndTime: "07:00:05 PM" , jobDivisor: 1, executes: "weekly", day:"Friday",expectedEndDay:"Friday", frequency: 2,interval:1 },
  // { jobName: 'ZDP_TRANS_REPLENISH_FCST', expectedStartTime: '07:00:00 PM', expectedEndTime: "07:00:05 PM" , jobDivisor: 1, executes: "weekly", day:"Friday",expectedEndDay:"Friday", frequency: 2,interval:2 },
 
  { jobName: 'ZDP_TRANS_FCST_APS', expectedStartTime: '07:00:00 PM', expectedEndTime: "08:00:00 PM" , jobDivisor: 1, executes: "weekly", day:"Friday",expectedEndDay:"Friday", frequency: 1,interval:1 },
]
export const in0589endojobdata = [
  { jobName: 'DPMDD5_DAILY_ETHICON_FCST',expectedStartTime: '10:00:00 PM', expectedEndTime: '10:54:00 PM',jobDivisor: 1, executes: "daily", frequency: 1,interval:1 },
  { jobName: 'DPMDD5_MOD_LOC_DET', expectedStartTime: '10:54:00 PM', expectedEndTime: '11:20:00 PM', jobDivisor: 1, executes: "daily", frequency: 1 ,interval:1},
 { jobName: 'ZDP_TRANS_FCST_PA5_PSA', expectedStartTime: '11:10:00 PM', expectedEndTime: '11:55:00 PM', jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Monday',expectedEndDay:'Monday',interval:1},
  { jobName: 'ZDP_TRAN_FCST_PA5_PSA_MTD', expectedStartTime: '11:55:00 PM', expectedEndTime: '12:05:00 AM', jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Monday',expectedEndDay:'Tuesday',interval:1},
  { jobName: 'ZDP_TRANS_FCST_EES_APS', expectedStartTime: '12:05:00 AM', expectedEndTime: '01:35:00 AM', jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Monday',expectedEndDay:'Tuesday',interval:1},
   ]
 
export const in0428endoScoreForecast = [
  { jobName: 'DPMDD5_DAILY_ETHICON_FCST',expectedStartTime: '10:00:00 PM', expectedEndTime: '10:54:00 PM',jobDivisor: 1, executes: "daily", frequency: 1,interval:1 },
  { jobName: 'DPMDD5_MOD_LOC_DET',expectedStartTime: '10:54:00 PM', expectedEndTime: '11:20:00 PM',jobDivisor: 1, executes: "daily", frequency: 1,interval:1 },
  { jobName: 'ZDP_TRANS_FCST_PA5_PSA',expectedStartTime: '11:10:00 PM', expectedEndTime: '11:55:00 PM',jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Monday',expectedEndDay:'Monday',interval:1},
  { jobName: 'ZDP_TRAN_FCST_PA5_PSA_MTD',expectedStartTime: '11:55:00 PM', expectedEndTime: '12:05:00 AM',jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Monday', expectedEndDay:'Tuesday',interval:1},
  { jobName: 'ZDP_TRANS_FCST_EES_APS',expectedStartTime: '12:05:00 AM', expectedEndTime: '01:35:00 AM',jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Monday',expectedEndDay:'Tuesday',interval:1},
  { jobName: 'ZDP_TRANS_FCST_EES_SCORE',expectedStartTime: '06:00:00 AM', expectedEndTime: '09:30:00 AM',jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Tuesday',expectedEndDay:'Tuesday',interval:1},
 
]

export const in0428endoScoreDemand = [
  { jobName: 'ZDP_TRANS_SO_COMPLETE', expectedStartTime: '04:00:00 PM', expectedEndTime: "07:00:00 PM" , jobDivisor: 2, executes: "daily", frequency: 2,interval:2 },
  { jobName: 'ZDP_TRANS_SO_MERGE', expectedStartTime: '07:00:00 PM', expectedEndTime: "07:15:00 PM" , jobDivisor: 2, executes: "daily", frequency: 2 ,interval:2},
  { jobName: 'ZDP_TRANS_OTC_COMPLETE', expectedStartTime: '07:15:00 PM', expectedEndTime: "09:30:00 PM" , jobDivisor: 2, executes: "daily", frequency: 2 ,interval:2},
  { jobName: 'DPMDD6_FCST_REL_SNP_CONS',expectedStartTime: '07:00:00 AM', expectedEndTime: '09:00:00 AM',jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Saturday',interval:1}, 
  { jobName: 'DP_BTB_LOAD_ORDER_HIST',expectedStartTime: '09:00:00 AM', expectedEndTime: '11:52:36 AM',jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Saturday',interval:1}, 
  { jobName: 'DPMDD4_BACKUP_PAST',expectedStartTime: '12:15:00 PM', expectedEndTime: '01:18:36 PM',jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Saturday',interval:1}, 
  { jobName: 'DPMDD5_BACKUP_PAST',expectedStartTime: '12:15:00 PM', expectedEndTime: '01:18:36 PM',jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Saturday',interval:1}, 
  { jobName: 'ZDP_TRANS_WKBKP_PA4_PSA', expectedStartTime: '02:00:00 PM', expectedEndTime: "07:30:00 PM" , jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Saturday', interval:1},
  { jobName: 'ZDP_TRANS_WKBKP_PA5_PSA', expectedStartTime: '02:00:00 PM', expectedEndTime: "04:00:00 PM" , jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Saturday', interval:1},
  { jobName: 'ZDP_TRANS_SHIST_ETHICON', expectedStartTime: '04:00:00 PM', expectedEndTime: "06:00:00 PM" , jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Saturday', interval:1},
  { jobName: 'ZDP_TRANS_SHIST_ADEPTO', expectedStartTime: '06:00:00 PM', expectedEndTime: "04:30:00 AM" , jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Sunday', interval:1},
  { jobName: 'ZDP_TRANS_SHIST_ENDO', expectedStartTime: '04:30:00 AM', expectedEndTime: "06:30:00 AM" , jobDivisor: 1, executes: "weekly", frequency: 1 ,day:'Saturday',expectedEndDay:'Sunday', interval:1},

 


]