import React from 'react';
import CustomDatePicker from "../component/DatePicker";
import { AgGridReact } from 'ag-grid-react';
import * as joint from "jointjs";
import { Chart } from 'chart.js/auto';


import { jobsInfo, demandJobsInfo, in0589APSJobsInfo, in0589endojobdata,in0428endoScoreForecast } from "../data/jobsInfo";


export const breadcrumbMapping = {
  [jobsInfo]: 'Statistical & Consensus Forecast [B11O013.dat]',
  [demandJobsInfo]: 'Demand Planning Order History [B11O012.dat]',
  [in0589APSJobsInfo]: 'IN0589 Forecast Ethicon [B11O011.dat]',
  [in0589endojobdata]: 'IN0589 Demand Forecast  [EES_FCST.dat]',
  [in0428endoScoreForecast]: 'IN0428 SCORE Forecast  [EES_SCORE_FCST.dat]'
  // Add more mappings as needed
};
export const handleBackButtonClick = () => {
  // Go back to the previous page
  window.history.back();
};
export const tabInfo = {
  ETHICON: {
    name: 'ETHICON',
    demand: {
      dailyCount: 0,
      weeklyCount: 3,
      monthlyCount: 0,
      quarterlyCount: 0,
      semiannualCount: 0,
      annualCount: 0,
    },
    supply: {
      dailyCount: 0,
      weeklyCount: 0,
      monthlyCount: 0,
      quarterlyCount: 0,
      semiannualCount: 0,
      annualCount: 0,
    },   
    navigateTo: '/home?reportType=Weekly',
  },
  ENDO: {
    name: 'ENDO',
    demand: {
      dailyCount: 0,
      weeklyCount: 3,
      monthlyCount: 0,
      quarterlyCount: 0,
      semiannualCount: 0,
      annualCount: 0,
    },
    supply: {
      dailyCount: 0,
      weeklyCount: 0,
      monthlyCount: 0,
      quarterlyCount: 0,
      semiannualCount: 0,
      annualCount: 0,
    },      
    navigateTo: '/endo?reportType=Weekly',
  },
  DCF: {
    dailyCount: 0,
    weeklyCount: 1,
    monthlyCount: 0,
    quarterlyCount: 0,
    semiannualCount: 0,
    annualCount: 0,
    navigateTo: '/dcf?reportType=Weekly',
  },
  PHARMA: {
    dailyCount: 0,
    weeklyCount: 0,
    monthlyCount: 0,
    quarterlyCount: 0,
    semiannualCount: 0,
    annualCount: 0,
    navigateTo: '/pharma?reportType=Weekly',
  }, 
  CANADA_DEPTO: {
    dailyCount: 0,
    weeklyCount: 2,
    monthlyCount: 0,
    quarterlyCount: 0,
    semiannualCount: 0,
    annualCount: 0,
    navigateTo: '/canadadepto?reportType=Weekly',
  },
  CORA: {
    dailyCount: 0,
    weeklyCount: 2,
    monthlyCount: 0,
    quarterlyCount: 0,
    semiannualCount: 0,
    annualCount: 0,
    navigateTo: '/cora?reportType=Weekly',
  },
  MANUGISTICS_BLUE_YONDER: {
    dailyCount: 0,
    weeklyCount: 2,
    monthlyCount: 0,
    quarterlyCount: 0,
    semiannualCount: 0,
    annualCount: 0,
    navigateTo: '/manugisticsblue?reportType=Weekly',
  },
  MARS: {
    dailyCount: 0,
    weeklyCount: 2,
    monthlyCount: 0,
    quarterlyCount: 0,
    semiannualCount: 0,
    annualCount: 0,
    navigateTo: '/mars?reportType=Weekly',
  },
  SPINE: {
    dailyCount: 0,
    weeklyCount: 2,
    monthlyCount: 0,
    quarterlyCount: 0,
    semiannualCount: 0,
    annualCount: 0,
    navigateTo: '/spine?reportType=Weekly',
  },
  EDS: {
    dailyCount: 0,
    weeklyCount: 2,
    monthlyCount: 0,
    quarterlyCount: 0,
    semiannualCount: 0,
    annualCount: 0,
    navigateTo: '/eds?reportType=Weekly',
  },
  LATAM_ADEPTO: {
    dailyCount: 1,
    weeklyCount: 2,
    monthlyCount: 3,
    quarterlyCount: 4,
    semiannualCount: 5,
    annualCount: 6,
    navigateTo: '/latam?reportType=Weekly',
  },
  USROTC_MARS: {
    dailyCount: 0,
    weeklyCount: 2,
    monthlyCount: 0,
    quarterlyCount: 0,
    semiannualCount: 0,
    annualCount: 0,
    navigateTo: '/usrotcmars?reportType=Weekly',
  },
     
};

export const formatTime = (Time) => {
  if (!Time) return ""; // Return an empty string if time is not provided

  const [hours, minutes] = Time.split(":");
  let formattedHours = parseInt(hours, 10);
  let period = "AM";

  // Check for PM and adjust formattedHours accordingly
  if (formattedHours >= 12) {
    period = "PM";
    formattedHours =
      formattedHours === 12 ? formattedHours : formattedHours - 12;
  }

  return `${formattedHours}:${minutes} ${period}`;
};
export const renderDatePicker = (label, onChange, selectedDate, placeholder) => (
  
  <CustomDatePicker
    label={label}
    onChange={onChange}
    selectedDate={selectedDate}
    placeholder={placeholder}
  />
);

export const renderSearchButton = (onClick, buttonText) => (
  <button className="search-button" onClick={onClick}>
    {buttonText}
  </button>
);
export const renderAgGrid = (columnDefs, rowData) => (
  <div className="ag-theme-alpine" style={{ height: "300px", width: "100%" }}>
    <AgGridReact
      columnDefs={columnDefs}
      rowData={rowData}
      domLayout="autoHeight"
      enableFilter={true}
      pagination={true}
      paginationPageSize={10}
      enableRangeSelection={true}
      enableBrowserTooltips={true}
      getRowStyle={(params) => {
        const status = params.data.status;
        return {
          backgroundColor: status === "Success" ? "#cbf3f0" : "#fde18b",
          fontFamily: 'Courier-Bold',
          fontSize: '12px',
        };
      }}
    />
  </div>
);
export const createFormattedLink = (graph, sourceRect, targetRect, item) => {
  const link = new joint.shapes.standard.Link({
    source: { id: sourceRect.id },
    target: { id: targetRect.id },
    router: { name: "orthogonal" },
    attrs: {
      line: {
        stroke: "blue",
        "stroke-width": 2,
      },
    },
  });

  // Check if item.linkText is defined before attempting to split
  const words = (item.linkText || '').split(' ');
  const lineBreakAfter = 2;
  const lines = [];
  for (let i = 0; i < words.length; i += lineBreakAfter) {
    lines.push(words.slice(i, i + lineBreakAfter).join(' '));
  }
  const formattedLinkText = lines.join('\n');

  link.appendLabel({
    position: {
      distance: 0.4, // Set distance to 0.5 for centering
      offset: {
        x: 0, // Set x offset to 0 for centering
        y: 0, // Set y offset to 0 for centering
      },
    },
    attrs: {
      text: {
        text: formattedLinkText,
        'font-size': 10,
        fill: '#001861',
        textAnchor: 'middle', // Align text to the center
        refX: 0.5, // Set refX to 0.5 for centering
        refY: 0.5, // Set refY to 0.5 for centering
        textVerticalAnchor: 'middle',
      },
    },
  });

  link.addTo(graph);

  // Return the created link if needed
  return link;
};

export const createRectangle = (item, state) => {
  var labelText = item.task.split(".").join("\n");

  const rect = new joint.shapes.standard.Rectangle();

  rect.position(item.positionX, item.positionY);
  rect.resize(item.width, item.height);
  rect.attr({
    body: {
      fill: item.color,
      rx: 5,
      ry: 5,
      stroke: item.strokeColor,
      strokeWidth: 2,
    },
    label: {
      text: labelText,
      fill: item.fontColor,
      fontSize: 12,
      refX: item.rx,
      refY: item.ry,
      "text-anchor": "start",
      "font-family": "Calibri", // Set font-family to Calibri
      "font-weight": item.fontStyle,
    },
  });

  state.rectDict.push(rect);

  // Return the created rectangle if needed
  return rect;
};

export const createErrorCircle = (graph, item, fill, text) => {
  const errorCircleX = item.positionX - 10;
  const errorCircleY = item.positionY - 10;

  const errorCircle = new joint.shapes.basic.Circle({
    position: { x: errorCircleX, y: errorCircleY },
    size: {
      width: 20,
      height: 20,
    },
    attrs: {
      circle: { fill },
      text: {
        text,
        fill: "white",
        "font-size": 12,
      },
    },
  });

  graph.addCell(errorCircle);
};
export const createCircle = (graph, positionX, positionY, fill, text) => {
  const errorCircle = new joint.shapes.basic.Circle({
    position: { x: positionX, y: positionY },
    size: {
      width: 20,
      height: 20,
    },
    attrs: {
      circle: { fill },
      text: {
        text,
        fill: "white",
        "font-size": 12,
      },
    },
  });

  graph.addCell(errorCircle);
};
export const createSDCircle = (graph, positionX, positionY, fill, text, fontColor) => {
  const errorCircle = new joint.shapes.basic.Circle({
    position: { x: positionX, y: positionY },
    size: {
      width: 20,
      height: 20,
    },
    attrs: {
      circle: { fill },
      text: {
        text,
        fill: fontColor,
        "font-size": 12,
      },
    },
  });

  graph.addCell(errorCircle);
};
export const formatTableData = (files, targetFiles, formatTime) => {
  return files.map((file) => {
    
   
    let status = '';
    let rowClass = '';
    console.log(targetFiles.includes(file) || file.filename.startsWith("B11O012"));
 if(targetFiles.includes(file) || file.filename.startsWith("B11O012")){
   status = "Success" ;
   rowClass = "success-row" ;
 } else{
   status = "Pending Files" ;
   rowClass =  "error-row";
 }
    // Ensure that each property is present in the file object
    return {
      filename: file.filename || "",
      FileSize: file.FileSize || "0",
      Date: file.Date || "",
      Time: formatTime(file.Time),
      status: status,
      fileStatus: file.fileStatus || "",
      MSG: file.msg || "Pending Message",
      rowClass: rowClass,
    };
  });
};
export const createDoughnutChart = (ctx, chartData, count, completionPercentage, navigateCallback) => {
  try {
    // Check if ctx is null
    if (!ctx) {
      console.error('Failed to create chart: ctx is null');
      return null;
    }

    // Check if chartData is valid
    if (!chartData || !Array.isArray(chartData.datasets) || chartData.datasets.length === 0) {
      console.error('Failed to create chart: Invalid chartData');
      return null;
    }

    // Check if count and completionPercentage are valid numbers
    if (isNaN(count) || isNaN(completionPercentage)) {
      console.error('Failed to create chart: Invalid count or completionPercentage');
      return null;
    }

    // Proceed with chart creation
    return new Chart(ctx, {
      type: 'doughnut',
      data: chartData,
      options: {
        plugins: {
          legend: { display: false },
          tooltip: {
            enabled: true,
            callbacks: {
              label: (context) => {
                const label = context.label || '';
                const value = count.toString();
                return `File Received: ${value}`;
              },
            },
          },
        },
        responsive: false,
        maintainAspectRatio: false,
        cutout: '70%',
        elements: {
          center: {
            text: `${completionPercentage.toFixed(2)}%`,
            color: '#FF6384',
            fontStyle: 'Arial',
            fontSize: 12,
            padding: 5,
            lineHeight: 15,
          },
        },
        onClick: (event, chartElements) => {
          if (chartElements && chartElements.length > 0) {
            navigateCallback(); // Always perform navigation when any segment of the doughnut chart is clicked
          }
        },
      },
    });
  } catch (error) {
    console.error('Failed to create chart:', error.message);
    return null;
  }
};

export const createDoughnutChartData = (label, successCount, delayedCount) => {
  if (successCount === 0 && delayedCount === 0) {
    // If both successCount and delayedCount are zero, customize the chart data
    return {
      labels: [label],
      datasets: [
        {
          data: [100],
          backgroundColor: ['#f8f8f8'],
          hoverBackgroundColor: ['#f8f8f8'],
          borderColor: '#e6c5a5',
          borderWidth: 0.5,
        },
      ],
    };
  }else {
    // Calculate success and failure percentages as before
    const totalCount = successCount + delayedCount;
    const successPercentage = (successCount / totalCount) * 100;
    const failurePercentage = (delayedCount / totalCount) * 100;

    // Return the chart data with success and failure percentages
    return {
      labels: [label],
      datasets: [
        {
          data: [successPercentage, failurePercentage],
          backgroundColor: ['#0BDA51', '#FFBF00'],
          hoverBackgroundColor: ['#0BDA51', '#FFBF00'],

          borderColor: '#e6c5a5',
          borderWidth: 0.5,
        },
      ],
    };
  }
};

export const convertTimeToSeconds = (timeString) => {
  const [time, period] = timeString.split(' ');
  const [hours, minutes, seconds] = time.split(':').map(Number);

  // Adjust for AM/PM
  const adjustedHours = period === 'PM' && hours !== 12 ? hours + 12 : hours;
  const totalSeconds = adjustedHours * 3600 + minutes * 60 + seconds;

  return totalSeconds;
};
export const timeFormat = (timeInMillis) => {
  const timeInSeconds = Math.floor(timeInMillis / 1000);
  const hours = Math.floor(timeInSeconds / 3600);
  const minutes = Math.floor((timeInSeconds % 3600) / 60);
  const seconds = Math.floor(timeInSeconds % 60);
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
};

export const calculateOverallTime = (job,selectedDate) => {

  if (job['Expected Run Time'] && job['Actual End Time']) {
   
    const expectedRunTime = new Date(`${job['Expected End Date']} ${job['Expected Run Time']}`);
    const actualEndTime = new Date(`${job['Actual End Date']} ${job['Actual End Time']}`);    
    const overAllTime = expectedRunTime - actualEndTime;
    return overAllTime;
    
  } 
  
 
};


export const doughnutOptions = {
  cutout: '80%',
  responsive: false,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      display: false  // Hides the legend
    },
    tooltip: {
      enabled: false // Disable the tooltip
    }
  },
  cutoutPercentage: 1, // Set cutoutPercentage to 0 to remove the inner circle
  elements: {
    canvas: {
      marginTop: '-5px',
      marginLeft: '-18px',
      height: '150px',
      width: '300px',
    },
    arc: {
      borderWidth: 0.2, // Adjust the width of the border as needed
      borderColor: '#9F8170', // Brown color for the border
    },
  },
};
