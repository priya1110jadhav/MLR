export const dataConstants = {
  time: {
    am: "AM",
    pm: "PM",
  },
  navigation: {
    gmed: "/bpmn/gmed",
    leaplive: "/bpmn/leaplive",
    usrotc: "/bpmn/usrotc",
    canada: "/canada",
  },
  charts: {
    doughnutChartData: [
      {
        id: "doughnut-chart-gmed812",
        header: "AIN0001",
        name: "GMED812",
        percentage: "completionPercentage",
      },
      {
        id: "doughnut-chart-leaplive2",
        header: "AIN0001",
        name: "LeapLive2",
        percentage: "completionPercentageLeap",
      },
      {
        id: "doughnut-chart-USROTC",
        header: "AIN0001",
        name: "USROTC",
        percentage: "completionPercentageUSROTC",
      },
      {
        id: "doughnut-chart-canada908",
        header: "IN0429",
        name: "CANADA",
        percentage: "completionPercentageCANADA",
      },
    ],
  },
  // cardData : [
  //   { id: 'GMED', successCount: successCountGMED, delayedCount: delayedCountGMED },
  //   { id: 'LeapLive2', successCount: successCountLeapLive, delayedCount: delayedCountLeapLive },
  //   { id: 'USROTC', successCount: successCountUSROTC, delayedCount: delayedCountUSROTC },
  //   { id: 'CANADA', successCount: successCountCANADA908, delayedCount: delayedCountCANADA908 }
  // ],
 
  labels: {
    heading:
      "Sales Order / Sales Order History data conversion BtB [APO BW to APO Demand Planning]",
  },
 
  tableColumns: [
    {
      headerName: "Filename",
      field: "filename",
      width: "400",
      filter: "agTextColumnFilter",
      editable: true,
    },
    {
      headerName: "Filesize in KB",
      field: "FileSize",
      valueFormatter: (params) => {
        const FileSize = params.value;
        return FileSize === 0 ? "" : FileSize.toString();
      },
      width: "150",
      filter: "agNumberColumnFilter",
    },
    {
      headerName: "Date: MM/DD/YYYY",
      field: "Date",
      width: "200",
      filter: "agDateColumnFilter",
      sort: "desc",
    },
    {
      headerName: "Expected Time",
      field: "expectedTime",
      width: 200,
      sortable: false,
      filter: false,
      cellRenderer: function (params) {
        // Function to determine expected time based on filename
        function getExpectedTime(filename) {
          if (filename.includes("GMED")) {
            return "Within every 5 mins for Every 3 Hours";
          } else if (filename.includes("LEAPLIVE")) {
            return "10:45 AM - 11:00 AM";
          } else if (filename.includes("USROTC_COD")) {
            return "23:00 PM - 00:00 AM";
          } else if (filename.includes("USROTC_ORTHO")) {
            return "5:00 AM - 8:00 AM";
          } else if (filename.includes("USROTC_MTK")) {
            return "1:00 AM - 2:00 AM";
          } else if (filename.includes("USROTC_SPN")) {
            return "00:00 AM - 1:30 AM";
          } else if (filename.includes("908")) {
            return "1:30 AM - 2:30 AM";
          } else {
            return "";
          }
        }
 
        return getExpectedTime(params.data.filename);
      },
      cellClass: "custom-cell-class",
    },
    {
      headerName: "Actual Receiving Time",
      field: "Time",
      width: "120",
      filter: "agTimeColumnFilter",
    },
    {
      headerName: "File Status",
      field: "fileStatus",
      height: 49,
      sortable: true,
      filter: true,
      cellStyle: (params) => ({
        backgroundColor:
          params.value === "Success"
            ? "#0BDA51"
            : params.value === "Delayed"
            ? "#FFBF00"
            : "#f8f8f8", // Set your default color here
      }),
    },
 
    // {
    //   headerName: "Status",
    //   field: "status",
    //   width: "150",
    //   filter: 'agSetColumnFilter'
    // },
    {
      headerName: "Message",
      field: "MSG",
      width: "600",
      wrapText: true,
      autoHeight: true,
      filter: "agTextColumnFilter",
      cellStyle: {
        whiteSpace: "normal",
        wordWrap: "break-word",
        lineHeight: "1.2",
      },
    },
  ],
 
  columnDefs: [
    {
      headerName: "Job Name",
      field: "Chain",
      width: 270,
      filter: true,
      cellClass: (params) =>
        params.data.runtimeStatus === "Yes" ? "runtime-yes" : "runtime-no",
        cellStyle: (params) => {
          if (params.data.runtimeStatus === "Yes" && params.data.Status!=='Failed') {
            return { backgroundColor: "#FFBF00" }; // Amber color for runtimeStatus === "Yes"
          } else if (params.data.runtimeStatus === "Yes" && params.data.Status === "Failed") {
            return { backgroundColor: "#FFD6D6" }; // Red color for Status === "Failed"
          } else if (params.data.Status === "Failed") {
            return { backgroundColor: "#FFD6D6" }; // Red color for Status === "Failed"
          }
           else {
            return {}; // No background color for other cases
          }
        },
    },
    {
      headerName: "Status",
      field: "Status",
      width: 130,
      filter: true,
      cellClass: (params) =>
        params.data.runtimeStatus === "Yes" ? "runtime-yes" : "runtime-no",
      cellStyle: (params) => {
          if (params.data.runtimeStatus === "Yes" && params.data.Status!=='Failed') {
            return { backgroundColor: "#FFBF00" }; // Amber color for runtimeStatus === "Yes"
          } else if (params.data.runtimeStatus === "Yes" && params.data.Status === "Failed") {
            return { backgroundColor: "#FFD6D6" }; // Red color for Status === "Failed"
          } else if (params.data.Status === "Failed") {
            return { backgroundColor: "#FFD6D6" }; // Red color for Status === "Failed"
          }
           else {
            return {}; // No background color for other cases
          }
        },
    },
    {
      headerName: "Actual Start Date",
      field: "Actual Start Date",
      width: 170,
      filter: 'true',
     
      cellClass: (params) =>
        params.data.runtimeStatus === "Yes" ? "runtime-yes" : "runtime-no",
      cellStyle: (params) => {
          if (params.data.runtimeStatus === "Yes" && params.data.Status!=='Failed') {
            return { backgroundColor: "#FFBF00" }; // Amber color for runtimeStatus === "Yes"
          } else if (params.data.runtimeStatus === "Yes" && params.data.Status === "Failed") {
            return { backgroundColor: "#FFD6D6" }; // Red color for Status === "Failed"
          } else if (params.data.Status === "Failed") {
            return { backgroundColor: "#FFD6D6" }; // Red color for Status === "Failed"
          }
           else {
            return {}; // No background color for other cases
          }
        },
      
    },
    {
      headerName: "Expected Start Time",
      field: "Expected Start Time",
      width: 170,
      filter: true,
      cellClass: (params) =>
        params.data.runtimeStatus === "Yes" ? "runtime-yes" : "runtime-no",
      cellStyle: (params) => {
          if (params.data.runtimeStatus === "Yes" && params.data.Status!=='Failed') {
            return { backgroundColor: "#FFBF00" }; // Amber color for runtimeStatus === "Yes"
          } else if (params.data.runtimeStatus === "Yes" && params.data.Status === "Failed") {
            return { backgroundColor: "#FFD6D6" }; // Red color for Status === "Failed"
          } else if (params.data.Status === "Failed") {
            return { backgroundColor: "#FFD6D6" }; // Red color for Status === "Failed"
          }
           else {
            return {}; // No background color for other cases
          }
        },
    },
    {
      headerName: "Actual Start Time",
      field: "Actual Start Time",
      width: 170,
            filter: true,
      cellClass: (params) =>
        params.data.runtimeStatus === "Yes" ? "runtime-yes" : "runtime-no",
      cellStyle: (params) => {
          if (params.data.runtimeStatus === "Yes" && params.data.Status!=='Failed') {
            return { backgroundColor: "#FFBF00" }; // Amber color for runtimeStatus === "Yes"
          } else if (params.data.runtimeStatus === "Yes" && params.data.Status === "Failed") {
            return { backgroundColor: "#FFD6D6" }; // Red color for Status === "Failed"
          } else if (params.data.Status === "Failed") {
            return { backgroundColor: "#FFD6D6" }; // Red color for Status === "Failed"
          }
           else {
            return {}; // No background color for other cases
          }
        },
    },
    {
      headerName: "Expected End Time",
      field: "Expected Run Time",
      width: 170,
      filter: true,
      cellClass: (params) =>
        params.data.runtimeStatus === "Yes" ? "runtime-yes" : "runtime-no",
      cellStyle: (params) => {
          if (params.data.runtimeStatus === "Yes" && params.data.Status!=='Failed') {
            return { backgroundColor: "#FFBF00" }; // Amber color for runtimeStatus === "Yes"
          } else if (params.data.runtimeStatus === "Yes" && params.data.Status === "Failed") {
            return { backgroundColor: "#FFD6D6" }; // Red color for Status === "Failed"
          } else if (params.data.Status === "Failed") {
            return { backgroundColor: "#FFD6D6" }; // Red color for Status === "Failed"
          }
           else {
            return {}; // No background color for other cases
          }
        },
    },
    {
      headerName: "Actual End Time",
      field: "Actual End Time",
      width: 170,
      filter: true,
      cellClass: (params) =>
        params.data.runtimeStatus === "Yes" ? "runtime-yes" : "runtime-no",
      cellStyle: (params) => {
          if (params.data.runtimeStatus === "Yes" && params.data.Status!=='Failed') {
            return { backgroundColor: "#FFBF00" }; // Amber color for runtimeStatus === "Yes"
          } else if (params.data.runtimeStatus === "Yes" && params.data.Status === "Failed") {
            return { backgroundColor: "#FFD6D6" }; // Red color for Status === "Failed"
          } else if (params.data.Status === "Failed") {
            return { backgroundColor: "#FFD6D6" }; // Red color for Status === "Failed"
          }
           else {
            return {}; // No background color for other cases
          }
        },
    },
    {
      headerName: "Actual End Date",
      field: "Actual End Date",
      width: 150,
      filter: 'true',
      cellClass: (params) =>
        params.data.runtimeStatus === "Yes" ? "runtime-yes" : "runtime-no",
      cellStyle: (params) => {
          if (params.data.runtimeStatus === "Yes" && params.data.Status!=='Failed') {
            return { backgroundColor: "#FFBF00" }; // Amber color for runtimeStatus === "Yes"
          } else if (params.data.runtimeStatus === "Yes" && params.data.Status === "Failed") {
            return { backgroundColor: "#FFD6D6" }; // Red color for Status === "Failed"
          } else if (params.data.Status === "Failed") {
            return { backgroundColor: "#FFD6D6" }; // Red color for Status === "Failed"
          }
           else {
            return {}; // No background color for other cases
          }
        },
    },
    {
      headerName: "Actual Runtime",
      field: "Runtime",
      width: 150,
      filter: true,
      cellClass: (params) =>
        params.data.runtimeStatus === "Yes" ? "runtime-yes" : "runtime-no",
      cellStyle: (params) => {
          if (params.data.runtimeStatus === "Yes" && params.data.Status!=='Failed') {
            return { backgroundColor: "#FFBF00" }; // Amber color for runtimeStatus === "Yes"
          } else if (params.data.runtimeStatus === "Yes" && params.data.Status === "Failed") {
            return { backgroundColor: "#FFD6D6" }; // Red color for Status === "Failed"
          } else if (params.data.Status === "Failed") {
            return { backgroundColor: "#FFD6D6" }; // Red color for Status === "Failed"
          }
           else {
            return {}; // No background color for other cases
          }
        },
    },
    {
      headerName: "Exceeded Runtime",
      field: "exceededRuntime",
      width: 170,
      filter: true,
      cellClass: (params) =>
        params.data.runtimeStatus === "Yes" ? "runtime-yes" : "runtime-no",
      cellStyle: (params) => {
          if (params.data.runtimeStatus === "Yes" && params.data.Status!=='Failed') {
            return { backgroundColor: "#FFBF00" }; // Amber color for runtimeStatus === "Yes"
          } else if (params.data.runtimeStatus === "Yes" && params.data.Status === "Failed") {
            return { backgroundColor: "#FFD6D6" }; // Red color for Status === "Failed"
          } else if (params.data.Status === "Failed") {
            return { backgroundColor: "#FFD6D6" }; // Red color for Status === "Failed"
          }
           else {
            return {}; // No background color for other cases
          }
        },
    },
    {
      headerName: "Frequency",
      field: "Interval",
      width: 150,
      filter: true,
      cellClass: (params) =>
        params.data.runtimeStatus === "Yes" ? "runtime-yes" : "runtime-no",
      cellStyle: (params) => {
          if (params.data.runtimeStatus === "Yes" && params.data.Status!=='Failed') {
            return { backgroundColor: "#FFBF00" }; // Amber color for runtimeStatus === "Yes"
          } else if (params.data.runtimeStatus === "Yes" && params.data.Status === "Failed") {
            return { backgroundColor: "#FFD6D6" }; // Red color for Status === "Failed"
          } else if (params.data.Status === "Failed") {
            return { backgroundColor: "#FFD6D6" }; // Red color for Status === "Failed"
          }
           else {
            return {}; // No background color for other cases
          }
        },
    },
  ],
};
 