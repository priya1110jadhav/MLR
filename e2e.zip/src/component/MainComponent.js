import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Breadcrumbs from '@mui/material/Breadcrumbs';
import Typography from '@mui/material/Typography';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import daily from '../assets/daily.png';
import weekly from '../assets/weekly.png';
import monthly from '../assets/monthly.png';
import quarter from '../assets/quarter.png';
import semiannual from '../assets/semi-annual.png';
import annual from '../assets/annual.png';
import { tabInfo } from "../utils/common";

const MainComponent = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [selectedOption, setSelectedOption] = useState('Demand Planning');
  const [showButtons, setShowButtons] = useState(true);

  const getQueryParam = () => {
    const searchParams = new URLSearchParams(location.search);
    const firstQueryParam = searchParams.keys().next().value;
    return firstQueryParam || 'Planning';
  };

  const reportName = getQueryParam();
  const selectedTabInfo = tabInfo[reportName];

  useEffect(() => {
    if (selectedTabInfo) {
      window.history.replaceState(null, '', `/reports?reportName=${reportName}`);
    }
  }, [reportName, selectedTabInfo]);

  const handleOptionChange = (option) => {
    setSelectedOption(option);
    setShowButtons(true); 
  };

  const navigateTo = (route) => {
    navigate(route);
  };

  return (
    <div>
      <Breadcrumbs
        separator={<NavigateNextIcon fontSize="small" />}
        aria-label="breadcrumb"
        style={{ margin: '10px', padding: '10px', marginBottom: '0px' }}
      >
        <span onClick={() => navigate('/')}>Home</span>
        <Typography color="textPrimary">{getQueryParam()}</Typography>
        <Typography color="textPrimary">{selectedOption}</Typography>
      </Breadcrumbs>

      <div className="main-container">
        {showButtons && (
          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '20px' }}>
            <button
              onClick={() => handleOptionChange('Demand Planning')}
              style={{ marginRight: '10px', backgroundColor: selectedOption === 'Demand Planning' ? '#007bff' : '#ccc', color: '#fff', border: 'none', padding: '5px 10px', borderRadius: '5px', cursor: 'pointer' }}
              disabled={selectedOption === 'Demand Planning'}
            >
              Demand Planning
            </button>
            <button
              onClick={() => handleOptionChange('Supply Network Planning')}
              style={{ backgroundColor: selectedOption === 'Supply Network Planning' ? '#007bff' : '#ccc', color: '#fff', border: 'none', padding: '5px 10px', borderRadius: '5px', cursor: 'pointer' }}
              disabled={selectedOption === 'Supply Network Planning'}
            >
              Supply Network Planning
            </button>
          </div>
        )}
        <h2>{getQueryParam() ? `${getQueryParam()} Reports` : 'Planning Reports'}</h2>
        <div className="cards-container">
          {/* Render cards based on the selected option */}
          {selectedOption === 'Demand Planning' && (
            <>
              <div className="report-card" onClick={() => navigateTo('/')}>
                <div className="cardRowContent">
                  <img src={daily} alt="Daily Icon" className="report-icon" />
                  <span className='textMain'>Daily</span>
                  <p className="textPMain">Report: {selectedTabInfo?.demand?.dailyCount}</p>
                </div>
              </div>
              <div className="report-card" onClick={() => navigateTo(selectedTabInfo.navigateTo)}>
            <div className="cardRowContent">
              <img src={weekly} alt="Weekly Icon" className="report-icon" />
              <span className='textMain'>Weekly</span>
              <p className="textPMain">Report: {selectedTabInfo?.demand?.weeklyCount}</p>
            </div>
          </div>
          <div className="report-card" onClick={() => navigateTo('/')}>
            <div className="cardRowContent">
              <img src={monthly} alt="Monthly Icon" className="report-icon" />
             <span className='textMain'>Monthly</span>
              <p className="textPMain">Report: {selectedTabInfo?.demand?.monthlyCount}</p>
            </div>
          </div>
          <div className="report-card" onClick={() => navigateTo('/')}>
            <div className="cardRowContent">
              <img src={quarter} alt="Quarterly Icon" className="report-icon" />
              <span className='textMain'>Quarterly</span>
              <p className="textPMain">Report: {selectedTabInfo?.demand?.quarterlyCount}</p>
            </div>
          </div>
          <div className="report-card" onClick={() => navigateTo('/')}>
            <div className="cardRowContent">
              <img src={semiannual} alt="Semi-Annual Icon" className="report-icon" />
              <span className='textMain'>Semi-Annual</span>
              <p className="textPMain">Report: {selectedTabInfo?.demand?.semiannualCount}</p>
            </div>
          </div>
          <div className="report-card" onClick={() => navigateTo('/')}>
            <div className="cardRowContent">
              <img src={annual} alt="Annual Icon" className="report-icon" />
              <span className='textMain'>Annual</span>
              <p className="textPMain">Report: {selectedTabInfo?.demand?.annualCount}</p>
            </div>
          </div>
              
            </>
          )}
          {selectedOption === 'Supply Network Planning' && (
            <>
               <div className="report-card" onClick={() => navigateTo('/')}>
                <div className="cardRowContent">
                  <img src={daily} alt="Daily Icon" className="report-icon" />
                  <span className='textMain'>Daily</span>
                  <p className="textPMain">Report: {selectedTabInfo?.supply?.dailyCount}</p>
                </div>
              </div>
              <div className="report-card" onClick={() => navigateTo('/')}>
            <div className="cardRowContent">
              <img src={weekly} alt="Weekly Icon" className="report-icon" />
              <span className='textMain'>Weekly</span>
              <p className="textPMain">Report: {selectedTabInfo?.supply?.weeklyCount}</p>
            </div>
          </div>
          <div className="report-card" onClick={() => navigateTo('/')}>
            <div className="cardRowContent">
              <img src={monthly} alt="Monthly Icon" className="report-icon" />
             <span className='textMain'>Monthly</span>
              <p className="textPMain">Report: {selectedTabInfo?.supply?.monthlyCount}</p>
            </div>
          </div>
          <div className="report-card" onClick={() => navigateTo('/')}>
            <div className="cardRowContent">
              <img src={quarter} alt="Quarterly Icon" className="report-icon" />
              <span className='textMain'>Quarterly</span>
              <p className="textPMain">Report: {selectedTabInfo?.supply?.quarterlyCount}</p>
            </div>
          </div>
          <div className="report-card" onClick={() => navigateTo('/')}>
            <div className="cardRowContent">
              <img src={semiannual} alt="Semi-Annual Icon" className="report-icon" />
              <span className='textMain'>Semi-Annual</span>
              <p className="textPMain">Report: {selectedTabInfo?.supply?.semiannualCount}</p>
            </div>
          </div>
          <div className="report-card" onClick={() => navigateTo('/')}>
            <div className="cardRowContent">
              <img src={annual} alt="Annual Icon" className="report-icon" />
              <span className='textMain'>Annual</span>
              <p className="textPMain">Report: {selectedTabInfo?.supply?.annualCount}</p>
            </div>
          </div>
             
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default MainComponent;
