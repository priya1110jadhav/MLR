import React, { useState } from 'react';
import { handleBackButtonClick } from "../utils/common";
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import salesOrder1 from '../assets/salesOrder1.png';
import salesOrder2 from '../assets/salesOrder2.png';
import salesOrder3 from '../assets/salesOrder3.png';
import backButtonImg from '../assets/backButtton.png';



const PPTViewComponent = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    adaptiveHeight: true,
    centerMode: true,
    centerPadding: '0px',
    beforeChange: (current, next) => {
      setCurrentSlide(next);
    },
  };

  const handleMouseWheel = (event) => {
    const currentDiv = document.getElementById(`slide-${currentSlide}`);
    const currentTransform = currentDiv.style.transform;
    const currentScale = parseFloat(currentTransform.slice(7, -1));
    const newScale = currentScale + (event.deltaY > 0 ? -0.1 : 0.1);
    currentDiv.style.transform = `scale(${newScale})`;
  };
  // const back = () => {
  //   navigate("/");
  // };
  return (
    
    <div onWheel={handleMouseWheel}>
    <div style={{ display: 'flex', justifyContent: 'flex-start', margin: '10px 10px 0px 10px' }}>
    <button onClick={handleBackButtonClick} style={{ backgroundImage: `url(${backButtonImg})`, backgroundSize: 'contain', backgroundRepeat: 'no-repeat', margin: '8px 0px 0px 0px', color: 'transparent', border: 'none', padding: '0', width: '40px', height: '40px', cursor: 'pointer' }}></button>
    </div>
    <Slider {...settings}>
      <div id={`slide-0`} style={{ width: '50%', height: '50%' }}>
        <img src={salesOrder1} alt="Slide 1" style={{ width: '50%', height: '50%', marginLeft: '25%', marginTop: '5px', objectFit: 'cover' }} />
      </div>
      <div id={`slide-1`} style={{ width: '50%', height: '50%' }}>
        <img src={salesOrder2} alt="Slide 2" style={{ width: '50%', height: '50%', marginLeft: '25%', marginTop: '5px', objectFit: 'cover' }} />
      </div>
      <div id={`slide-2`} style={{ width: '50%', height: '50%' }}>
        <img src={salesOrder3} alt="Slide 3" style={{ width: '50%', height: '50%', marginLeft: '25%', marginTop: '5px', objectFit: 'cover' }} />
      </div>
    </Slider>
  </div>
  );
};

export default PPTViewComponent;