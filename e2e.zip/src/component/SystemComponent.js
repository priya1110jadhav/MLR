import React, { useRef, useState, useEffect } from "react";
import { Link } from "react-router-dom";
import moment from "moment";
import { fetchDataJointJs } from "../api/api";
import ClipLoader from "react-spinners/ClipLoader"; // Import ClipLoader

const SystemComponent = () => {
  const [latestDate, setLatestDate] = useState(null);
  const [loading, setLoading] = useState(true); // Add loading state
  const cardsData = [
    { title: "ETHICON", count: 3, link: "/reports" },
    { title: "ENDO", count: 2,link: "/reports" },
    { title: "DCF", link: "/" },
    { title: "PHARMA", link: "/" },
    { title: "CANADA ADEPTO", link: "/" },
    { title: "CORA", link: "/" },
    { title: "MANUGISTICS/BLUE YONDER", link: "/" },
    { title: "MARS", link: "/" },
    { title: "SPINE", link: "/" },
    { title: "EDS", link: "/" },
    { title: "LATAM_ADEPTO", link: "/" },
    { title: "USROTC MARS", link: "/" },
  ];

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetchDataJointJs();
        const { BPUProcessChains } = response.data;

        const mergedData = [...BPUProcessChains];
        const dateObjects = mergedData.map(
          (item) => new Date(item["Last Updated Date"])
        );
        const maxDate = new Date(Math.max.apply(null, dateObjects));
        const formattedDate = moment(maxDate).format("YYYY-MM-DD HH:mm:ss");
        setLatestDate(formattedDate);
        setLoading(false); // Set loading to false when latestDate is ready
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="MainreportCardscontainer">
      <div className="right-section">
        <p className="last-refresh">
          Last Refresh: {loading ? <ClipLoader color={"#007bff"} loading={loading} size={20} /> : latestDate}{" "}
          <span style={{ color: "red", marginLeft: "10px" }}>*</span>{" "}
          <span style={{ color: "#007bff" }}>All times in EST</span>
        </p>
      </div>
      <div className="Maincard-grid">
        {cardsData.map((card, index) => (
          <Link
            key={index}
            className="card4"
            to={card.link === "/" ? "/" : `/reports?${card.title}`}
          >
            <div
              className="cardRowContents"
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
              }}
            >
              <span className="textMains">{card.title}</span>
              {card.count && (
                <span
                  className="mains"
                  style={{ textAlign: "center", marginTop: "10px", color: "#727226" }}
                >
                  Reports: {card.count}
                </span>
              )}
            </div>
            <div class="go-corner">
              <div class="go-arrow">→</div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default SystemComponent;
