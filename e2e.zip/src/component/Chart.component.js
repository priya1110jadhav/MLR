import React from 'react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Doughnut } from 'react-chartjs-2';
ChartJS.register(ArcElement, Tooltip, Legend);

export function Chart(props) {
  const options = {
    plugins: {
      legend: {
        display: false
      }
    },
    cutout: '70%'
  }
  let data = {
    labels: ['Delayed', 'Success'],
    datasets: [{
      label: '# of Files',
      data: props.data,
      backgroundColor: [
        'rgba(5255, 191, 0, 0.8)',
        'rgba(11, 218, 81,0.8)',
      ],
      borderColor: [
        'rgba(5255, 191, 0, 1)',
        'rgba(11, 218, 81,1)',
      ],
      borderWidth: 2,
    },
    ]
  }
  if (props.data[0] == 0 && props.data[1] == 0) {
    data = {
      labels: ['No Data'],
      datasets: [
        {
          // label: 'No Data',
          data: [1],
          backgroundColor: [
            'rgba(250, 250, 250, 1)'
          ],
          borderColor: [
            'rgba(190, 190, 190, 1)'
          ],
          borderWidth: 2,
        },
      ]
    }
  }
  return <div style={{ width: 160, height: 160, margin: "0 auto"}}>
    <Doughnut data={data} options={options} />
  </div>
}
