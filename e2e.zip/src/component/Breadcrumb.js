import React from 'react';
import { Link } from 'react-router-dom';

const Breadcrumb = ({ paths }) => {
  return (
    <div className="breadcrumb" style={{padding:'10px 10px 10px 10px'}}>
      {paths.map((path, index) => (
        <span key={index}>
          <Link to={path.link}>{path.label}</Link>
          {index < paths.length - 1 && ' > '}
        </span>
      ))}
    </div>
  );
};

export default Breadcrumb;
