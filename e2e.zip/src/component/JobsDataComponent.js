import React, { useState, useEffect, useRef } from 'react';
import { DateRangePicker } from 'react-date-range';
import 'react-date-range/dist/styles.css';
import 'react-date-range/dist/theme/default.css';
import { Line } from 'react-chartjs-2';
import { fetchDataJointJs } from '../api/api';
import { useLocation } from 'react-router-dom';
import { breadcrumbMapping, timeFormat, calculateOverallTime, handleBackButtonClick } from '../utils/common'; // Import configurations
import { format, parse } from 'date-fns';
import Breadcrumb from './Breadcrumb';
import MaterialUITable from './MaterialUITable';
import { dataConstants } from '../utils/constants';
import { jobsInfo, demandJobsInfo, in0589APSJobsInfo, in0589endojobdata, in0428endoScoreForecast,in0428endoScoreDemand } from '../data/jobsInfo'; // Import job lists
import moment from 'moment';
import backButtonImg from '../assets/backButtton.png';
const { columnDefs } = dataConstants;

const JobsDataComponent = () => {
  const [data, setData] = useState([]);
  const [dateRange, setDateRange] = useState([
    {
      startDate: new Date(),
      endDate: new Date(),
      key: 'selection'
    }
  ]);
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const chainName = searchParams.get('chain');
  const jobsinfolist = location.state && location.state.jobName; // Access jobName from state
  const gridRef = useRef(null);
  const [displayedData, setDisplayedData] = useState([]);
  const handleDateRangeChange = (ranges) => {
    setDateRange([ranges.selection]);
  };
  const isDayOfWeek = (dateString, dayName) => {
    const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const date = new Date(dateString);
    const dayOfWeek = daysOfWeek[date.getDay()];
    return dayOfWeek === dayName;
  };

  // Function to get the appropriate job list based on jobsinfolist value
  const getJobList = (jobName) => {
    switch (jobName) {
      case 'demandJobsInfo':
        return demandJobsInfo;
      case 'in0589APSJobsInfo':
        return in0589APSJobsInfo;
      case 'in0589endojobdata':
        return in0589endojobdata;
      case 'in0428endoScoreForecast':
        return in0428endoScoreForecast;
      case 'in0428endoScoreDemand':
        return in0428endoScoreDemand;
      // Add other cases for different job lists as needed
      default:
        return jobsInfo; // Default to jobsInfo if no specific job list is found
    }
  };
  const getExpectedEndDate = (selectedDate, expectedEndDay) => {
    const startOfWeek = moment(selectedDate, "MM/DD/YYYY").startOf('isoWeek');
    const endOfWeek = moment(selectedDate, "MM/DD/YYYY").endOf('isoWeek');
    // Find the date of the expectedEndDay within the week range
    let expectedEndDate;
    if(expectedEndDay==='Sunday')
    {
    expectedEndDate=endOfWeek;
    }
  else
  {
  
  
    expectedEndDate = startOfWeek.clone().day(expectedEndDay);
    
  }


    console.log('hello', selectedDate, expectedEndDate)
    return expectedEndDate.format("MM/DD/YYYY");
  };
  useEffect(() => {
    const fetchDataFromAPI = async () => {
      try {
        const response = await fetchDataJointJs();
        const mergedData = [
          ...response.data.BPUProcessChains,
          ...response.data.apujobs,
        ];



        const getJobData = (mergedData, chainName) => {

          const mergedFiltered = mergedData.filter(job => chainName.trim().includes(job.Chain));
          console.log("data", mergedFiltered)
          const dateDataDict = {};

          // Populate the dateDataDict with data from mergedFiltered
          mergedFiltered.forEach((item) => {
            const actualStartDate = item['Actual Start Date'];

            if (!dateDataDict[actualStartDate]) {
              dateDataDict[actualStartDate] = [];
            }

            dateDataDict[actualStartDate].push(item);
          });

          // Sort occurrences within each date based on Actual Start Time
          Object.keys(dateDataDict).forEach((date) => {
            dateDataDict[date].sort((a, b) => {
              const timeA = new Date(`1970-01-01T${a['Actual Start Time']}`);
              const timeB = new Date(`1970-01-01T${b['Actual Start Time']}`);
              return timeA - timeB;
            });
          });

          // Now dateDataDict contains sorted data grouped by Actual Start Date and Actual Start Time

          const filteredData = [];
          console.log(dateDataDict)
          // Iterate through each date and its occurrences
          Object.keys(dateDataDict).forEach((date) => {
            const occurrences = dateDataDict[date];
            // For each occurrence, find the corresponding interval in jobInfoList
            occurrences.forEach((occurrence, index) => {
              const jobName = occurrence['Chain'];
              const interval = index + 1; // Add 1 to match with interval

              // Check if the job executes weekly and the actual start date is a Saturday
              // OR if the job executes daily

              const jobInfodata = getJobList(jobsinfolist);

              const selectedJobInfo = jobInfodata.find(job => job.jobName.includes(chainName));
              let shouldInclude = false;
              const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']; // Define daysOfWeek array here

              if (selectedJobInfo) {
                if (selectedJobInfo.executes === 'weekly') {
                  const startDate = new Date(occurrence['Actual Start Date']);
                  const selectedDayIndex = daysOfWeek.indexOf(selectedJobInfo.day);
                  const currentDayIndex = startDate.getDay();
                  shouldInclude = true;

                } else if (selectedJobInfo.executes === 'daily') {
                  shouldInclude = true;
                }
              }
              if (shouldInclude) {
                filteredData.push({
                  Chain: jobName,
                  Status: occurrence['Status'],
                  'Actual Start Time': convertTo12HourFormat(occurrence['Actual Start Time']),
                  Runtime: occurrence['Runtime'],
                  'Runtime [sec]': occurrence['Runtime [sec]'],
                  'Actual Start Date': occurrence['Actual Start Date'],
                  'Actual End Date': occurrence['Actual End Date'],
                  'Actual End Time': convertTo12HourFormat(occurrence['Actual End Time']),
                  'Expected Start Time': selectedJobInfo ? selectedJobInfo.expectedStartTime : null,
                  'Expected Run Time': selectedJobInfo ? selectedJobInfo.expectedEndTime : null,
                  'Expected End Date': selectedJobInfo.executes === 'weekly' ? getExpectedEndDate(occurrence['Actual Start Date'], selectedJobInfo.expectedEndDay) : occurrence['Actual Start Date'],
                  'Interval': selectedJobInfo ? selectedJobInfo.interval : null,
                  percentage: occurrence['Status'] === 'Completed' ? 100 : 0
                });
              }
            });
          });
          setData(filteredData);
          console.log('data', filteredData)
          const { startDate, endDate } = dateRange[0];

          // Function to group data by selecting the latest interval for each day
          const groupDataByLatestInterval = (dataArray) => {
            return dataArray.reduce((acc, item) => {
              const key = item['Actual Start Date'];
              const existingItem = acc[key];
              if (!existingItem || item.Interval > existingItem.Interval) {
                acc[key] = item;
              }
              return acc;
            }, {});
          };

          const currentMonthData = filteredData.filter(item => {
            const startDate = new Date(item['Actual Start Date']);
            const currentDate = new Date();
            return startDate.getMonth() === currentDate.getMonth() && startDate.getFullYear() === currentDate.getFullYear();
          });

          const groupedCurrentMonthData = groupDataByLatestInterval(currentMonthData);

          const filteredDataInRange = data.filter(item => {
            const startDate = new Date(item['Actual Start Date']);
            return startDate >= dateRange[0].startDate && startDate <= dateRange[0].endDate;
          });

          const groupedData = groupDataByLatestInterval(filteredDataInRange);

          if (startDate.getTime() === endDate.getTime()) {
            setDisplayedData(Object.values(groupedCurrentMonthData));
          } else {
            setDisplayedData(Object.values(groupedData));
          }



        };

        getJobData(mergedData, chainName);






      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchDataFromAPI();
  }, [dateRange]);

  const filteredDatas = chainName
    ? data.filter(item => item.Chain.trim() === chainName.trim())
    : data;

  const convertTo12HourFormat = (timeString) => {
    const [hours, minutes, seconds] = timeString.split(':');
    const date = new Date(0, 0, 0, hours, minutes, seconds);

    return format(date, 'hh:mm:ss a');
  };

  const addRuntimeInfo = (jobs) => {
    return jobs.map(job => ({
      ...job,
      runtimeStatus: calculateOverallTime(job, job['Actual Start Date']) < 0 ? 'Yes' : 'No',
      exceededRuntime: calculateOverallTime(job, job['Actual Start Date']) < 0 ? timeFormat(Math.abs(calculateOverallTime(job, job['Actual Start Date']))) : '00:00:00'
    }));
  };

  const filteredData = addRuntimeInfo(chainName ? data.filter(item => item.Chain.trim() === chainName.trim()) : data);
  const displayedDataWithRuntimeInfo = addRuntimeInfo(displayedData);

  displayedData.sort((a, b) => new Date(b['Actual End Date']) - new Date(a['Actual End Date']));

  const chartData = {
    labels: displayedData.map(item => format(parse(item['Actual End Date'], 'MM/dd/yyyy', new Date()), 'MM/dd/yyyy')),
    datasets: [
      {
        label: 'Expected Run Time',
        data: displayedData.map(item => {
          const time = parse(item['Expected Run Time'], 'hh:mm:ss a', new Date());
          return time.getHours() * 60 + time.getMinutes();
        }),
        fill: false,
        borderColor: 'green',
        pointRadius: 2,
      },
      {
        label: 'Actual End Time',
        data: displayedData.map(item => {
          const time = parse(item['Actual End Time'], 'hh:mm:ss a', new Date());
          return time.getHours() * 60 + time.getMinutes();
        }),
        fill: false,
        borderColor: 'blue',
        backgroundColor: 'rgba(0, 0, 255, 0.2)', // Background color for the filled area
        pointRadius: 2, // Radius of the points
        pointBackgroundColor: 'blue', // Color of the points
      },
    ],
  };

  const chartOptions = {
    scales: {
      y: {
        title: {
          display: true,
          text: 'Time (AM/PM)'
        },
        ticks: {
          callback: function (value, index, values) {
            return formatTimeAMPM(value); // Format y-axis ticks as AM/PM
          }
        }
      }
    },
    plugins: {
      tooltip: {
        callbacks: {
          label: function (context) {
            let label = context.dataset.label || '';
            if (label) {
              label += ': ';
            }
            if (context.parsed.y !== null) {
              label += formatTimeAMPM(context.parsed.y);
            }
            return label;
          }
        }
      }
    }
  };

  const formatTimeAMPM = (time) => {
    const hours = Math.floor(time / 60);
    const minutes = Math.round((time % 60) * 100) / 100; // Round to two decimal places
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const hour = hours % 12 || 12;
    return `${hour}:${minutes.toString().padStart(2, '0')} ${ampm}`;
  };
  // Calculate the average runtime

  const systems = [
    {
      name: 'ETHICON',
      jobNames: ['jobsInfo', 'demandJobsInfo', 'in0589APSJobsInfo'],
      link: '/reports?ETHICON',
      linkName: 'home'
    },
    {
      name: 'ENDO',
      jobNames: ['in0589endojobdata', 'in0428endoScoreForecast'],
      link: '/reports?ENDO',
      linkName: 'endo'
    },
    // Add more systems as needed
  ];
  let systemLink = '';
  let SystemLinkage = '';
  const breadcrumbPaths = [
    { label: 'Home', link: '/' },
    // Find the matching system based on the job name
    ...systems.map(system => {
      if (system.jobNames.includes(jobsinfolist)) {
        systemLink = system.linkName;
        SystemLinkage = system.link;
        return { label: system.name, link: system.link };
      }
      return null;
    }).filter(item => item !== null),
    { label: 'Demand Planning', link: `${SystemLinkage}` },
    { label: 'Weekly', link: `/${systemLink}?reportType=Weekly` },
    {
      label: breadcrumbMapping[getJobList(jobsinfolist)],
      link: `/${systemLink}?reportType=Weekly`,
    },
    { label: chainName, link: `/job-details?chain=${chainName}` },
  ];

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
        <div style={{ display: 'flex', alignItems: 'center', margin: '10px' }}>
        <button onClick={handleBackButtonClick} style={{ backgroundImage: `url(${backButtonImg})`, backgroundSize: 'contain', backgroundRepeat: 'no-repeat', margin: '8px 0px 0px 0px', color: 'transparent', border: 'none', padding: '0', width: '40px', height: '40px', cursor: 'pointer' }}></button>
          <div>
            <Breadcrumb paths={breadcrumbPaths} />
          </div>
        </div>
        <p style={{ color: '#007bff', marginRight: '10px', textAlign: 'right' }}><span style={{ color: 'red' }}>*</span>All times in EST</p>
      </div>

      <div className='jobname'>Runtime Trend for <span className='jobnameBold'>{chainName}</span></div>
      <div className='row' style={{ marginTop: '10px' }}>
        <div className='column' style={{ border: '1px solid black', marginLeft: '20px' }}>
          <DateRangePicker
            ranges={dateRange}
            onChange={handleDateRangeChange}
          />
        </div>
        <div className='column' style={{ width: '780px', border: '1px solid black', marginLeft: '20px' }}>
          <div className='chart-container' style={{ height: '300px', width: '100%', display: 'grid', placeItems: 'center' }}>
            <h3>TREND for: {chainName}</h3>
            <Line data={chartData} options={chartOptions} />
          </div>
        </div>
      </div>

      <div className='TableAgGrid' style={{ width: '100%' }}>

        <MaterialUITable data={dateRange[0].startDate && dateRange[0].endDate ? displayedDataWithRuntimeInfo : filteredData} columns={columnDefs} />


      </div>
    </div>
  );
};

export default JobsDataComponent;