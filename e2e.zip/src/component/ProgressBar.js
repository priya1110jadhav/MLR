import React from 'react';
 // Create a separate CSS file for styling

const ProgressBar = ({ percentage,Status }) => {
  
  const fillStyle = percentage === 100 && Status==='Completed' ? 'progress-bar-fill-green' : (percentage === 100 && Status==='Failed'?'progress-bar-fill-red':'progress-bar-fill-yellow');

  return (
    <div className="progress-bar">
      <div className={fillStyle} style={{ width: `${percentage}%` }}></div>
      <div className="progress-bar-text">{percentage}%</div>
    </div>
  );
};

export default ProgressBar;
