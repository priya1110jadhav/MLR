import React, { useRef, useState, useEffect } from "react";
import Chart from "chart.js/auto";
import { DateTime } from 'luxon';
import { useLocation } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import moment from "moment";
import { SyncLoader } from "react-spinners";
import { fetchDataJointJs } from "../api/api";
import CustomDatePicker from './DatePicker';
import { in0589endojobdata, in0428endoScoreForecast,in0428endoScoreDemand } from "../data/jobsInfo";
import processJobData from './processJobData';
import HomeCardsComponent from "./HomeCardsComponent";
import {
  doughnutOptions,
  convertTimeToSeconds,
  calculateOverallTime,
} from "../utils/common";
import Breadcrumb from "./Breadcrumb";
import { format } from "date-fns";

const useJobDataState = (initialCount = 0) => {
  const [semiComplete, setSemiComplete] = useState(initialCount);
  const [Delay, setDelay] = useState(initialCount);
  const [FailedJob, setFailedJobs] = useState(initialCount);
  let count = 0;
  const [chartData, setChartData] = useState();
  const [percentage, setPercentage] = useState(0);
  const [gridData, setGridData] = useState([]);
  const [totalJobs, setTotalJobs] = useState(0);
  const [completedJobs, setCompletedJobs] = useState(0);
  return {
    semiComplete,
    setSemiComplete,
    Delay,
    setDelay,
    FailedJob,
    setFailedJobs,
    count,
    chartData,
    setChartData,
    percentage,
    setPercentage,
    gridData,
    setGridData,
    totalJobs,
    setTotalJobs,  // Add setTotalJobs to the returned object
    completedJobs,
    setCompletedJobs,
  };
};
const EndoComponent = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [breadcrumbPaths, setBreadcrumbPaths] = useState([]);
  const [previousPath, setPreviousPath] = useState("");
  const chartRef = useRef(null);
  const [latestDate, setLatestDate] = useState(null);

  const in0589endojobDataState = useJobDataState();
  const in0428endoScoreForecastData = useJobDataState();
  const in0428endodemandhistory=useJobDataState();
  const [selectedDate, setSelectedDate] = useState(
    new Date().toLocaleDateString('en-US', {
      month: '2-digit', // 2-digit numeric representation of the month
      day: '2-digit',   // 2-digit numeric representation of the day
      year: 'numeric'   // Full numeric representation of the year
    })
  );

  const [apobwdatFilesNextWeek, setApobwdatFilesNextWeek] = useState([]);
  const [loading, setLoading] = useState(true);

  const handleDateChange = (date) => {


    setSelectedDate(date);
  };
  const handleDoughnutClick = (dataState, gridData, fileName, jobName) => {
    const formattedDate = moment(selectedDate).format('MM/DD/YYYY');
    navigate(`/processChains?date=${formattedDate}`, { state: { gridData, fileName, formattedDate,jobName } });
  };
  const convertTo12HourFormat = (timeString) => {
    const [hours, minutes, seconds] = timeString.split(":");
    const date = new Date(0, 0, 0, hours, minutes, seconds);

    return format(date, "hh:mm:ss a");
  };
  const updateChartData = (jobsData, dataState, counts) => {

    const completedJobs = jobsData.filter((job) => job.Status === "Completed" && job.percentage === 100);

    const completedPercentage = Math.round((completedJobs.length / jobsData.length) * 100);

    const delayedPerc = Math.round((counts / jobsData.length) * 100);
    const completedPerc = completedPercentage - delayedPerc;


    const FailedTheJobs = jobsData.filter((job) => job.Status === "Failed");
    const failedPerc = Math.round((FailedTheJobs.length / jobsData.length) * 100);

    const jobFailed = FailedTheJobs.length;
    const DelayedComp = completedJobs.length - counts;
    const pendingperc = 100 - completedPerc - failedPerc - delayedPerc;

    let delayedColor = "#FFBF00"; // Yellow color
    let completedColor = "#0BDA51"; // Green color
    let failedColor = "red"; // Red color
    let pendingColor = "#f2f2f2";

    if (completedPerc === 100) {
      delayedColor = "#f2f2f2"; // No delay, set delayed color to #f2f2f2
      failedColor = "#f2f2f2"; // No failure, set failed color to #f2f2f2
    } else if (delayedPerc === 0 && completedPerc > 0 && failedPerc === 0) {
      completedColor = "#0BDA51"; // Yellow color for combined completed and delayed
      failedColor = "#f2f2f2"; // No failure, set failed color to #f2f2f2
      delayedColor = "#f2f2f2";
    } else if (delayedPerc > 0 && completedPerc > 0 && failedPerc > 0) {
      completedColor = "red"; // Red color for combined completed, delayed, and failed
      delayedColor = "red";
    }
    else if (delayedPerc > 0 && failedPerc > 0) {
      completedColor = "red";
      delayedColor = "red";
    } else if (delayedPerc > 0 && failedPerc === 0) {
      completedColor = "#FFBF00"; // Yellow color for only delayed
      failedColor = "#FFBF00"; // No failure, set failed color to #f2f2f2
    } else if (completedPerc === 0 && delayedPerc === 0 && failedPerc === 0) {
      completedColor = "#f2f2f2";
      delayedColor = "#f2f2f2";
      failedColor = "#f2f2f2";
    } else if (failedPerc > 0) {
      completedColor = "red"; // Red color for combined delayed and failed
      delayedColor = "red";
    }

    const updatedChartData = {
      labels: ["Delayed", "Completed", "Failed", "Pending"],
      datasets: [
        {
          data: [delayedPerc, completedPerc, failedPerc, pendingperc],
          backgroundColor: [delayedColor, completedColor, failedColor, pendingColor],
          legend: { display: false },
        },
      ],
    };

    const updatedPercentage = completedPercentage;
    // Ensure dataState.chartData is updated correctly
    dataState.setChartData(updatedChartData);
    dataState.setPercentage(updatedPercentage);
    dataState.setTotalJobs(jobsData.length);
    dataState.setCompletedJobs(completedJobs.length);
    dataState.setSemiComplete(DelayedComp);
    dataState.setFailedJobs(jobFailed);
    dataState.setDelay(counts)

  };

  const fetchDataFromAPI = async () => {
    try {
      setLoading(true);
      const response = await fetchDataJointJs();
      const { apobwdatFiles, BPUProcessChains, apujobs } = response.data;
      const mergedData = [...BPUProcessChains, ...apujobs];

      //set latest date as refreshed date
      const dateObjects = mergedData.map(
        (item) => new Date(item["Last Updated Date"])
      );
      const maxDate = new Date(Math.max.apply(null, dateObjects));
      const formattedDate = moment(maxDate).format("YYYY-MM-DD HH:mm:ss");
      setLatestDate(formattedDate);


      const toDate = moment(selectedDate, "MM/DD/YYYY");
      const startOfWeek = toDate.clone().startOf('isoWeek');
      const endOfWeek = toDate.clone().endOf('isoWeek');
      console.log("start", startOfWeek, endOfWeek)
      const nextWeekFiles = apobwdatFiles.filter((file) => {
        const fileDate = moment(file.Date, "MM/DD/YYYY HH:mm:ss");
        return fileDate.isBetween(startOfWeek, endOfWeek, null, '[]'); // '[]' includes start and end dates
      });

      setApobwdatFilesNextWeek(nextWeekFiles);

      // Create or update the chart
      const renderChart = (data) => {
        if (chartRef.current) {
          const ctx = chartRef.current.getContext("2d");
          new Chart(ctx, {
            type: "doughnut",
            data: data,
            options: doughnutOptions,
          });
        }
      };

      renderChart(in0589endojobDataState.chartData);
      renderChart(in0428endoScoreForecastData.chartData);
      renderChart(in0428endodemandhistory.chartData);

      const selectedDateObj = new Date(selectedDate);


      // Usage example
      const in0589endojobInfoData = processJobData(in0589endojobdata, selectedDate, mergedData);
      const in0428endojobInfoData = processJobData(in0428endoScoreForecast, selectedDate, mergedData);
      const in0428endodemandJobInfoData=processJobData(in0428endoScoreDemand, selectedDate, mergedData);
      // Update state or perform further actions
      in0589endojobDataState.setGridData(in0589endojobInfoData);
      in0428endoScoreForecastData.setGridData(in0428endojobInfoData);
      in0428endodemandhistory.setGridData(in0428endodemandJobInfoData);

      const jobCompletionStatus = {};
      in0589endojobInfoData.forEach((job) => {
        const overallTime = calculateOverallTime(job, selectedDate);

        if (overallTime < 0 && job['Status'] === 'Completed') {
          // Update dictionary value to 1 if overallTime is less than 0
          jobCompletionStatus[job.Chain] = 1;
        } else {
          // Set dictionary value to 0 if overallTime is not less than 0
          jobCompletionStatus[job.Chain] = 0;
        }
      });

      // Count the number of completed jobs (where value is 1 in the dictionary)
      in0589endojobDataState.count = Object.values(jobCompletionStatus).filter((value) => value === 1).length;
      updateChartData(in0589endojobInfoData, in0589endojobDataState, in0589endojobDataState.count);

      const in0428endoScoreForecastjobCompletionStatus = {};
      in0428endojobInfoData.forEach((job) => {
        const overallTime = calculateOverallTime(job, selectedDate);

        if (overallTime < 0 && job['Status'] === 'Completed') {
          // Update dictionary value to 1 if overallTime is less than 0
          in0428endoScoreForecastjobCompletionStatus[job.Chain] = 1;
        } else {
          // Set dictionary value to 0 if overallTime is not less than 0
          in0428endoScoreForecastjobCompletionStatus[job.Chain] = 0;
        }
      });
      in0428endoScoreForecastData.count = Object.values(in0428endoScoreForecastjobCompletionStatus).filter((value) => value === 1).length;
      updateChartData(in0428endojobInfoData, in0428endoScoreForecastData, in0428endoScoreForecastData.count);


      const in0428endodemandjobCompletionStatus = {};
      in0428endodemandJobInfoData.forEach((job) => {
        const overallTime = calculateOverallTime(job, selectedDate);

        if (overallTime < 0 && job['Status'] === 'Completed') {
          // Update dictionary value to 1 if overallTime is less than 0
          in0428endodemandjobCompletionStatus[job.Chain] = 1;
        } else {
          // Set dictionary value to 0 if overallTime is not less than 0
          in0428endodemandjobCompletionStatus[job.Chain] = 0;
        }
      });
      in0428endodemandhistory.count = Object.values(in0428endodemandjobCompletionStatus).filter((value) => value === 1).length;
      updateChartData(in0428endodemandJobInfoData, in0428endodemandhistory, in0428endodemandhistory.count);

      const searchParams = new URLSearchParams(location.search);
      const dateParam = searchParams.get("date");
      const paths = [
        { label: "Home", link: "/" },
        { label: "ENDO", link: "/reports?ENDO" },
        { label: "Demand Planning", link: "/reports?ENDO" },
        { label: "Weekly", link: "/endo?reportType=Weekly" },n
      ];
      setBreadcrumbPaths(paths);

      setLoading(false);
    } catch (error) {
      console.error("Error fetching data from API:", error);
      setLoading(false);
      // Handle error as needed
    }
  };
  useEffect(() => {

    fetchDataFromAPI();
  }, [selectedDate]);


  return (
    <div className="homeContainer">
      {loading ? (
        <div className="spinner-container">
          <SyncLoader color="#36D7B7" loading={loading} size={15} />
        </div>
      ) : (
        <div className="display">
          <div className="breadcrumb-section">
            <Breadcrumb paths={breadcrumbPaths} />
          </div>
          <div className="right-section">
            <p className="last-refresh">
              Last Refresh: {latestDate}<span style={{ color: 'red', marginLeft: '10px' }}>*</span> <span style={{ color: '#007bff' }}>All times in EST</span>
            </p>
            {/* <CustomDatePicker onChange={handleDateChange} placeholder={selectedDate} className='date-input' /> */}

            <CustomDatePicker onChange={handleDateChange} selectedDate={selectedDate} placeholder={selectedDate} className='date-input' />

          </div>
        </div>
      )}

      {!loading && (
        <>
          <div className="row mx-auto" style={{ marginTop: '-20px', marginLeft: '20px' }}>
            <HomeCard

              header="[Monday 01:35 AM EST] IN0589 Demand Forecast [EES_FCST.DAT]"
              chartData={in0589endojobDataState.chartData}
              percentage={in0589endojobDataState.percentage}
              semiComplete={in0589endojobDataState.semiComplete}
              Delay={in0589endojobDataState.Delay}
              FailedJob={in0589endojobDataState.FailedJob}
              pendingJobs={in0589endojobDataState.totalJobs - in0589endojobDataState.completedJobs - in0589endojobDataState.FailedJob}
              fileData={apobwdatFilesNextWeek}
              fileName={"EES_FCST"}
              onClick={() => handleDoughnutClick(in0589endojobDataState, in0589endojobDataState.gridData, "EES_FCST","in0589endojobdata")}
            />
            <HomeCard

              header="[Tuesday 09:30 AM EST] IN0428 SCORE Forecast [EES_SCORE_FCST.DAT]"
              chartData={in0428endoScoreForecastData.chartData}
              percentage={in0428endoScoreForecastData.percentage}
              semiComplete={in0428endoScoreForecastData.semiComplete}
              Delay={in0428endoScoreForecastData.Delay}
              FailedJob={in0428endoScoreForecastData.FailedJob}
              pendingJobs={in0428endoScoreForecastData.totalJobs - in0428endoScoreForecastData.completedJobs - in0428endoScoreForecastData.FailedJob}
              fileData={apobwdatFilesNextWeek}
              fileName={"EES_SCORE_FCST"}
              onClick={() => handleDoughnutClick(in0428endoScoreForecastData, in0428endoScoreForecastData.gridData, "EES_SCORE_FCST","in0428endoScoreForecast")}
            />
             <HomeCard

header="[Sunday 06:30 AM EST] IN0428 Demand History [EES_SCORE_DMND.DAT]"
chartData={in0428endodemandhistory.chartData}
percentage={in0428endodemandhistory.percentage}
semiComplete={in0428endodemandhistory.semiComplete}
Delay={in0428endodemandhistory.Delay}
FailedJob={in0428endodemandhistory.FailedJob}
pendingJobs={in0428endodemandhistory.totalJobs - in0428endodemandhistory.completedJobs - in0428endodemandhistory.FailedJob}
fileData={apobwdatFilesNextWeek}
fileName={"EES_SCORE_DMND"}
onClick={() => handleDoughnutClick(in0428endodemandhistory, in0428endodemandhistory.gridData, "EES_SCORE_DMND","in0428endoScoreDemand")}
/>


          </div>
        </>
      )}
    </div>
  );
};

const HomeCard = ({ header, chartData, percentage, semiComplete, Delay, FailedJob, pendingJobs, fileData, fileName, onClick }) => (
  <div className="col-md-3">
    <div className="card-Home" onClick={onClick}>
      <HomeCardsComponent

        header={header}
        chartData={chartData}
        percentage={percentage}
        semiComplete={semiComplete}
        Delay={Delay}
        FailedJob={FailedJob}
        pendingJobs={pendingJobs}
        fileData={fileData}
        fileName={fileName}
      />
    </div>
  </div>
);
export default EndoComponent;


