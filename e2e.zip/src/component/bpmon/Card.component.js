import * as React from 'react';
import { Typography } from '@mui/material';
import RadioButtonUncheckedIcon from '@mui/icons-material/RadioButtonUnchecked';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';

export const CardComponent = (props) => {
  const { name, id, handleCardClick, selectedId } = props;
  return (<div
    className={`component-background-color card ${selectedId === id ? 'card-selected' : ''}`}
    onClick={handleCardClick}
  >
    <div className='icon-holder'>
      {selectedId === id ? <CheckCircleIcon style={{ fill: "#EB1700" }} /> :
        <RadioButtonUncheckedIcon style={{ fill: "#eee" }} />}
    </div>
    <div className='card-content'>
      <Typography>
        {name}
      </Typography>
    </div>
  </div>
  )

}
