import * as React from 'react';
import { Breadcrumbs, Typography } from '@mui/material';

export const BreadcrumbComponent = (props) => {
    const { data } = props;
    const lastIndex = data.length - 1;

    const breadcrumbs = data.map((e, index) => (
        <Typography
            key={index}
            color={index === lastIndex ? "text.primary" : "text.secondary"}
            fontWeight={index === lastIndex ? "bold" : "normal"}
            fontSize={"small"}
        >
            {e}
        </Typography>
    ));

    return (
        <Breadcrumbs separator="/" className='breadcrumbs' >
            {breadcrumbs}
        </Breadcrumbs>
    );
}