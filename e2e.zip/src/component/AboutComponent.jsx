// AboutComponent.jsx
import React from 'react';
import techStackImg from '../assets/techStack.png';
import backButtonImg from '../assets/backButtton.png';
import { handleBackButtonClick } from "../utils/common";

const AboutComponent = () => {
  return (
    <div>
    <div style={{ display: 'flex', alignItems: 'center' }}>
      {/* Use the backButtonImg as background */}
      <button onClick={handleBackButtonClick} style={{ backgroundImage: `url(${backButtonImg})`, backgroundSize: 'contain', backgroundRepeat: 'no-repeat', margin: '15px 15px 0px 15px', color: 'transparent', border: 'none', padding: '0', width: '50px', height: '40px', cursor: 'pointer' }}></button>
    </div>
    <div className="about-container" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', marginTop:'-30px' }}>
      <img src={techStackImg} alt="Tech Stack" className="tech-stack-img" style={{ textAlign: 'center', height: '80%', width: '65%' }} />
    </div>
  </div>
  );
};

export default AboutComponent;
