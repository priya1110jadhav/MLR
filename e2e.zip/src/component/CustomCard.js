import React from 'react';
import ProgressBar from './ProgressBar';
import { useNavigate } from 'react-router-dom';
import { timeFormat, calculateOverallTime } from '../utils/common';
 
const CustomCard = ({ job, serialNumber,headerName ,formattedDate,jobName}) => {
 
  const navigate = useNavigate();
    const isAPUJob = serialNumber <= 4;
   
    const borderColor = headerName === 'APU Jobs' ? '#11b0f9' : '#6a0ec0';
  const handleClick = () => {
    const chainName = job['Chain'].trim();
    navigate(`/jobs-data?chain=${encodeURIComponent(chainName)}`, { state: { jobName } });
  };
 
  return (
    <div className="col-md-4" onClick={handleClick}>
      <div className="cardDashboard smallCard" style={{ borderLeft: `4px solid ${borderColor}` }}>
        <div className={headerName === 'APU Jobs' ? 'cardlabel-first' : 'cardlabel-second'}>
          <img
            src={headerName === 'APU Jobs' ? '/APUJobs.png' : '/BPUChains.png'}
            alt={headerName}
            className="label-icon"
            style={{ position: 'absolute', height: headerName === 'APU Jobs' ? '20px' : '18px', width: headerName === 'APU Jobs' ? '20px' : '18px' }}
          />
          <p className='jobsHeaderName'>{headerName}</p>
        </div>
        {job.percentage === 100 && calculateOverallTime(job,formattedDate) < 0 && job.Status!=='Failed' &&(
          <img
            src='/amberSuccess.png'
            alt="Amber Success Flag"
            className="status-flag"
            style={{ position: 'absolute', top: 8, right: 7, height: '20px', width: '20px' }}
          />
        )}
        {job.percentage === 100 && calculateOverallTime(job,formattedDate) >= 0 && job.Status==='Completed'&& (
          <img
            src='/successFlag.png'
            alt="Success Flag"
            className="status-flag"
            style={{ position: 'absolute', top: 8, right: 7, height: '20px', width: '20px' }}
          />
        )}
        {job.percentage !== 100 && job.Status!=='Completed' && job.Status!=='Failed'&& (
          <img
            src='/pendingFlag.png'
            alt="Pending Flag"
            className="status-flag"
            style={{ position: 'absolute', top: 4, right: 2, height: '30px', width: '30px' }}
          />
        )}
        {job.percentage === 100 && job.Status==='Failed' && (
          <img
            src='/failed.png'
            alt="Failed Flag"
            className="status-flag"
            style={{ position: 'absolute', top: 4, right: 4, height: '24px', width: '24px' }}
          />
        )}
         {job.percentage !== 100 && job.Status==='Completed' && (
         <img
         src='/successFlag.png'
         alt="Success Flag"
         className="status-flag"
         style={{ position: 'absolute', top: 8, right: 7, height: '20px', width: '20px' }}
       />
        )}
         {job.percentage !== 100 && job.Status==='Failed' && (
         <img
         src='/failed.png'
         alt="Failed Flag"
         className="status-flag"
         style={{ position: 'absolute', top: 4, right: 4, height: '24px', width: '24px' }}
         />
        )}
        <div className="cardHead"> {`${serialNumber}. ${job['Chain']}`}</div>
        <div className="cardContent">
          {job['Runtime'] && (
            <>
              <span>{job['Runtime']}</span>
              <span style={{ fontSize: '14px', marginLeft: '2px', fontWeight: 'normal' }}> [hh:mm:ss]</span>
            </>
          )}
          <span className="overallTime">
            <span className="percentageBox" style={{ backgroundColor: calculateOverallTime(job,formattedDate) < 0 ? '#FFE9E9' : '#E8FEF5' }}>
              {calculateOverallTime(job,formattedDate) < 0 ? (
                <span style={{ color: '#670000' }}>
                  {timeFormat(Math.abs(calculateOverallTime(job,formattedDate)))}</span>
              ) : (
                <span style={{ color: '#005F31' }}>00:00:00</span>
              )}
            </span>
          </span>
          {job.percentage === 100 && <p className='CardText'>Actual Run Time</p>}
          {job.percentage !== 100 && <p className='CardText'>Current Run Time</p>}
          <ProgressBar percentage={job.percentage} Status={job.Status}/>
        </div>
      </div>
    </div>
  );
 
};
 
export default CustomCard;