import * as React from 'react';
import { Grid, Card, CardContent, Typography, Divider } from '@mui/material';
import { Chart } from './Chart.component';
import { fetchData } from '../api/api';
import { Link, useSearchParams } from 'react-router-dom';
import MaterialUITable from './MaterialUITable';
import { SyncLoader } from "react-spinners";
import { renderDatePicker ,handleBackButtonClick} from "../utils/common";
import { dataConstants } from '../utils/constants';
import moment from 'moment';
import Breadcrumb from './Breadcrumb';
import backButtonImg from '../assets/backButtton.png';


const breadcrumbItems = [
  { link: '/', label: 'Home' },
  { link: '/reports?ETHICON', label: 'Ethicon' },
  { label: "Demand Planning", link: "/reports?ETHICON" },
  { link: '/home?reportType=Weekly', label: 'Weekly' },
  { link:'/home?reportType=Weekly',label: 'Demand Planning Order History [B11O012.dat]' },
  { label: 'Data source feed' },
];

const CardComponent = (props) => {
  return (
    <Card sx={{ maxWidth: 250 }}>
      <div style={{ textAlign: "center",padding:'10px' }}>
        <Typography style={{ fontSize: '16px', marginBottom: '5px', fontWeight: '700',background:'#f8f8f8', borderRadius:'5px' }}>{props.type}</Typography>
        <Typography style={{ fontSize: '12px', marginBottom: '3px', fontWeight: '600' }}>{props.name}</Typography>
      </div>
      {/* <Divider />
      <br /> */}
      <Chart data={[props.data.delayed, props.data.success]} />
      <br />
      <Divider />
      <CardContent>
        <div style={{ display: 'flex' }}>
          <Typography sx={{ fontSize: '14px',textAlign: 'center'  }} color="text.secondary">
            Success
          </Typography>
          <Typography sx={{ fontSize: '14px' }} color="text.primary">
            &nbsp;:&nbsp;{props.data.success}
          </Typography>
        </div>
        <div style={{ display: 'flex' }}>
          <Typography sx={{ fontSize: '14px' }} color="text.secondary">
            Delayed
          </Typography>
          <Typography sx={{ fontSize: '14px' }} color="text.primary">
            &nbsp;:&nbsp;{props.data.delayed}
          </Typography>
        </div>
        <Link to={`${props.path}?Date=${new Date(props.selectedDate).toLocaleDateString('en-US', {
      month: '2-digit', // 2-digit numeric representation of the month
      day: '2-digit',   // 2-digit numeric representation of the day
      year: 'numeric'   // Full numeric representation of the year
    })}`}>View Details</Link>
      </CardContent >
    </Card >
  );
}

const Legend = () => {
  return <div className="legendCard">
    <div className="legendHeader">Legend</div>
    <div className="legendContent">
      <div className="legendItem">
        <div className="legendSquare" style={{ backgroundColor: '#0BDA51' }}></div>
        <div className="legendLabel">Success</div>
      </div>
      <div className="legendItem">
        <div className="legendSquare" style={{ backgroundColor: '#FFBF00' }}></div>
        <div className="legendLabel">Delayed</div>
      </div>
    </div>
  </div>
}

const DonoughtComponent = (props) => {
  const { selectedDate, handleChange, currentData } = props
  const cardObj = [
    {
      type: "AIN0001",
      name: "GMED812",
      data: currentData?.gmed,
      path: dataConstants.navigation.gmed
    },
    {
      type: "AIN0001",
      name: "LEAPLIVE2",
      data: currentData?.leaplive,
      path: dataConstants.navigation.leaplive
    },
    {
      type: "AIN0001",
      name: "USROTC",
      data: currentData?.usrotc,
      path: dataConstants.navigation.usrotc
    },
    {
      type: "IN0429",
      name: "CANADA908",
      data: currentData?.canada908,
      path: dataConstants.navigation.canada
    },
  ]

  const agGridColumns = [
    { headerName: 'Filename', field: 'filename', width: 400, tooltip: (params) => params.value, cellClass: 'custom-cell-class', sortable: true, filter: 'agTextColumnFilter' },
    { headerName: 'FileSize (KB)', field: 'FileSize', width: 130, cellClass: 'custom-cell-class', sortable: true, filter: 'agNumberColumnFilter' },
    { headerName: 'Date', field: 'Date', width: 100, cellClass: 'custom-cell-class', sortable: true, filter: 'agDateColumnFilter' },
    {
      headerName: 'Expected Time',
      field: 'expectedTime',
      width: 220,
      sortable: false,
      filter: false,
      cellRenderer: function (params) {
        const filename = params.data.filename
        if (filename.includes('GMED')) {
          return 'Within every 5 mins for Every 3 Hours';
        } else if (filename.includes('LEAPLIVE')) {
          return '10:45 AM - 11:00 AM';
        } else if (filename.includes('USROTC_COD')) {
          return '23:00 PM - 00:00 AM';
        } else if (filename.includes('USROTC_ORTHO')) {
          return '5:00 AM - 8:00 AM';
        } else if (filename.includes('USROTC_MTK')) {
          return '1:00 AM - 2:00 AM';
        } else if (filename.includes('USROTC_SPN')) {
          return '00:00 AM - 1:30 AM';
        } else if (filename.includes('908')) {
          return '1:30 AM - 2:30 AM';
        } else {
          return '';
        }
      },
      cellClass: 'custom-cell-class',
    },
    {
      headerName: 'Actual Receiving Time',
      field: 'Time',
      width: 180,
      cellClass: 'custom-cell-class',
      sortable: true,
      filter: 'agTextColumnFilter'
    },
    {
      headerName: "File Status",
      field: "fileStatus",
      height: 49,
      width: 120,
      sortable: true,
      filter: true,
      cellStyle: params => ({
        backgroundColor: params.value === "Success" ? "#0BDA51" : "#FFBF00",
        fontSize: 12,
      }),
    },
    {
      headerName: 'MSG',
      field: 'msg',
      width: 800,
      cellClass: 'custom-cell-class',
      tooltip: (params) => params.value,
    },
  ]

  return <div>
     
     <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '10px' }}>
  <div style={{ display: 'flex', alignItems: 'center' }}>
  <button onClick={handleBackButtonClick} style={{ backgroundImage: `url(${backButtonImg})`, backgroundSize: 'contain', backgroundRepeat: 'no-repeat', margin: '8px 0px 0px 0px', color: 'transparent', border: 'none', padding: '0', width: '40px', height: '40px', cursor: 'pointer' }}></button>
    <div>
      <Breadcrumb paths={breadcrumbItems} />
    </div>
  </div>
  <div style={{ display: 'flex', alignItems: 'center', marginLeft: 'auto' }}>
    <p style={{ color: '#007bff', marginRight: '10px' }}><span style={{ color: 'red' }}>*</span> All times in EST</p>
    {renderDatePicker("", handleChange, selectedDate)}
  </div>
</div>
    
    <Legend />
    <div style={{ marginLeft: '15%' }}>
      <Grid container spacing={2}>
        {cardObj.map(e => (<Grid item xs={2.5}>
          <CardComponent type={e.type} name={e.name} data={e.data} path={e.path} selectedDate={selectedDate} />
        </Grid>))}
      </Grid>
    </div>
    <div className='TableAgGrid'>
    Total Records: {currentData.data.length}
          <MaterialUITable data={currentData.data} columns={agGridColumns} />
    </div>
  </div>
}


const DoughnutChart = () => {
  const [loading, setLoading] = React.useState(true); // Define loading state
  const [queryParameters] = useSearchParams()
  let urlDate = queryParameters.get("date")
  console.log("urlDate",urlDate);

  if (!urlDate) {
    urlDate = moment().format("MM/DD/YYYY");
  }
  const [selectedDate, setSelectedDate] = React.useState(urlDate)
  const [apiData, setApiData] = React.useState([])
  const [currentData, setCurrentData] = React.useState(null)


  React.useEffect(() => {
    e2eData();
  }, []);


  const e2eData = async () => {
    const allData = await fetchData();
    setApiData([...allData.targetFiles, ...allData.inctargetFiles])
    handleChange(selectedDate, [...allData.targetFiles, ...allData.inctargetFiles]);
  }

  const handleDate = (date) => {
    handleChange(date, apiData)
    setSelectedDate(date)
  }

  const handleChange = (date, allData) => {
    const formattedDate = new Date(date).toLocaleDateString('en-US');
    const currentDateData = allData.filter(e => e.Date === formattedDate)

    const filterData = (string) => currentDateData.filter(item => item.filename.includes(string))
    const gmed812Data = filterData('GMED812')
    const leaplive2Data = filterData('LEAPLIVE2')
    const USROTCData = filterData('USROTC')
    const CANADA908Data = filterData('908')

    const filterStatus = (data) => {
      return {
        success: data.filter(item => item.fileStatus === 'Success').length,
        delayed: data.filter(item => item.fileStatus === 'Delayed').length
      }
    }
    setCurrentData({
      data: currentDateData,
      gmed: filterStatus(gmed812Data),
      leaplive: filterStatus(leaplive2Data),
      usrotc: filterStatus(USROTCData),
      canada908: filterStatus(CANADA908Data),
    })
    setLoading(false); // Set loading to false after data is fetched
  }
 

  return (
    <>
      {loading ? (
        <div className="spinner-container">
          <SyncLoader color="#36D7B7" loading={loading} size={15} />
        </div>
      ) : (
        currentData && (
          <DonoughtComponent
            selectedDate={selectedDate}
            currentData={currentData}
            handleChange={handleDate}
          />
        )
      )}
    </>
  );
}

export default DoughnutChart;
