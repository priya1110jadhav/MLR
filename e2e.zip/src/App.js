// Update your import statements in App.js
import "./App.scss";

import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Navbar from "./component/Navbar";
import MainComponent from "./component/MainComponent";
import HomeComponent from "./component/HomeComponent";
import EndoComponent from "./component/EndoComponent";
import DoughnutChart from "./component/DoughnutChart";
import MyJointJSComponent from "./component/MyJointJSComponent";
import MboxBtbJsComponent from "./component/MboxBtBJsComponent";
import LeapLiveComponent from "./component/LeapLiveComponent";
import UsrotcComponent from "./component/UsrotcComponent";
import JobsDataComponent from "./component/JobsDataComponent";
import SliderComp from "./component/SliderComp";
import SystemComponent from "./component/SystemComponent";
import PPTViewComponent from "./component/PPTViewComponent";

import BpmonComponent from "./component/bpmon/Bpmon.component";
import AboutComponent from "./component/AboutComponent";

const App = () => {
  const current_theme = localStorage.getItem("current_theme");
  const [theme, setTheme] = useState(current_theme ? current_theme : "light");

  const [cssClass, setCssClass] = useState("app-main");

  useEffect(() => {
    localStorage.setItem("current_theme", theme);
  }, [theme]);

  //################temporary useEffect (will be removed)
  useEffect(() => {
    if (cssClass === "temporary-app") {
      import(`./temporary.scss`).then(({ default: styles }) => {
        const styleElement = document.createElement("style");
        styleElement.innerHTML = styles.default;
        document.head.appendChild(styleElement);
      });
    } 
  }, [cssClass]);

  return (
    <Router>
      <div className={cssClass}>
        <div className={`container ${theme}`}>
          {cssClass === "app-main" ? <Navbar theme={theme} setTheme={setTheme} />:<></>}
          <Routes>
            <Route path="/" element={<SystemComponent />} />
            <Route path="/reports" element={<MainComponent />} />
            <Route path="/home" element={<HomeComponent />} />
            <Route path="/endo" element={<EndoComponent />} />
            <Route path="/bpmn" element={<DoughnutChart />} />
            <Route path="/bpmn/gmed" element={<MyJointJSComponent />} />
            <Route path="/bpmn/leaplive" element={<LeapLiveComponent />} />
            <Route path="/bpmn/usrotc" element={<UsrotcComponent />} />
            <Route path="/canada" element={<MboxBtbJsComponent />} />
            <Route path="/jobs-data" element={<JobsDataComponent />} />
            <Route path="/processChains" element={<SliderComp />} />
            <Route path="/ppt" element={<PPTViewComponent />} />
            <Route path="/about" element={<AboutComponent />} />
            <Route
              path="/bpmon"
              element={<BpmonComponent setCssClass={setCssClass} />}
            />
          </Routes>
        </div>
      </div>
    </Router>
  );
};

export default App;
