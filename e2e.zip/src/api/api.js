// api.js
import axios from 'axios';

const baseURL = `${process.env.REACT_APP_VISUALIZATION_MS_URL}/fileSystem`;


export const fetchData = async () => {
    try {
        const response = await axios.get(`${baseURL}/`);
        return response.data || [];
    } catch (error) {
        console.error('Error fetching data:', error);
        throw error; // Re-throw the error so that the component can handle it
    }
};
export const fetchInoData = async () => {
  try {
      const response = await axios.get(`${baseURL}/`);
      return response.data.inctargetFiles || [];
  } catch (error) {
      console.error('Error fetching data:', error);
      throw error; // Re-throw the error so that the component can handle it
  }
};

export const postData = async (formattedDate, targetFilesData) => {
    try {
        const response = await axios.post(`${baseURL}/selectedDate`, {
            date: formattedDate,
            targetFiles: targetFilesData,
        });
        return response.data;
    } catch (error) {
        console.error('Error posting data:', error);
        throw error; // Re-throw the error so that the component can handle it
    }
};
export const postIncData = async (formattedDate, inctargetFilesData) => {
  try {
      const response = await axios.post(`${baseURL}/selectedDate`, {
          date: formattedDate,
          inctargetFiles: inctargetFilesData,
      });
      return response.data;
  } catch (error) {
      console.error('Error posting data:', error);
      throw error; // Re-throw the error so that the component can handle it
  }
};

export const fetchDataJointJs = () => {
    return axios.get(`${baseURL}/`);
  };
  
  export const compareFiles = (data) => {
    return axios.post(`${baseURL}/compareFiles`, data);
  };
  export const compareLeapLiveFiles = (data) => {
    return axios.post(`${baseURL}/compareLeapLiveFiles`, data);
  };
  export const compareUsrotcFiles = (data) => {
    return axios.post(`${baseURL}/compareUsrotcFiles`, data);
  };
  export const compareIncFiles = (data) => {
    return axios.post(`${baseURL}/compareIncFiles`, data);
  };

  
