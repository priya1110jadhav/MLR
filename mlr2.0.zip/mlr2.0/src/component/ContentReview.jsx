import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import FadeLoader from 'react-spinners/FadeLoader';
import './styles.css';

const ContentReview = () => {
  const location = useLocation();
  const { fileName, fileSize, previewSrc } = location.state || {};

  const [tooltip, setTooltip] = useState({ visible: false, content: '', x: 0, y: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  const showTooltip = (content, event) => {
    const { clientX: x, clientY: y } = event;
    setTooltip({ visible: true, content, x, y });
    setTimeout(() => {
      setTooltip({ visible: false, content: '', x: 0, y: 0 });
    }, 10000);
  };

  return (
    <div className="main-container">
      {loading ? (
        <div className="loader-container">
          <FadeLoader color="#123abc" loading={loading} size={150} />
        </div>
      ) : (
        <>
          <video className="background-video" autoPlay loop muted>
            <source src="/recreationBackground4.mp4" type="video/mp4" />
            Your browser does not support the video tag.
          </video>
          <h1 className="app-title">Marketing Material Compliance - Content Review</h1>
          <div className="OcontentOverlay1">
            <div className="left-column1">
              {previewSrc && (
                <div className="image-card1">
                  <img src={previewSrc} alt="Uploaded Preview" className="preview-image1" />
                  <div className="image-info1">
                    <p className="file-info1">FILE: {fileName}</p>
                    <p className="file-info1">SIZE: {fileSize}</p>
                  </div>
                </div>
              )}
            </div>
            <div className="right-column1">
              <div className="glass-card1" style={{ fontFamily: 'New', height: '570px', width: '250%' }}>
                <h2>Information:</h2>
                <p
                  style={{ backgroundColor: 'rgba(22 230 81 / 57%)' }}
                  onMouseEnter={(e) => showTooltip('<b>Alignment between the product\'s claimed purpose and the supporting clinical data.</b><br/><br/>The review confirms that data used to substantiate the product\'s claims (e.g., itch relief, pain reduction) appears to map appropriately to the intended use described on the label. This demonstrates a strong link between the product\'s functionality and the evidence supporting its effectiveness.', e)}
                >
                  <strong>Product Name:</strong> "Itch Stopping Gel"
                </p>
                <p><strong>Additional Information:</strong> "Cooling relief for most outdoor itches."</p>
                <p
                  style={{ backgroundColor: 'rgba(22 230 81 / 57%)' }}
                  onMouseEnter={(e) => showTooltip('<b>Alignment between the product\'s claimed purpose and the supporting clinical data.</b><br/><br/>The review confirms that data used to substantiate the product\'s claims (e.g., itch relief, pain reduction) appears to map appropriately to the intended use described on the label. This demonstrates a strong link between the product\'s functionality and the evidence supporting its effectiveness.', e)}
                >
                  <strong>Product Type:</strong> "Extra Strength" indicated below the product name.
                </p>
                <p
                  style={{ backgroundColor: 'rgba(22 230 81 / 57%)' }}
                  onMouseEnter={(e) => showTooltip('<b>Alignment between the product\'s claimed purpose and the supporting clinical data.</b><br/><br/>The review confirms that data used to substantiate the product\'s claims (e.g., itch relief, pain reduction) appears to map appropriately to the intended use described on the label. This demonstrates a strong link between the product\'s functionality and the evidence supporting its effectiveness.', e)}
                >
                  <strong>Ingredients:</strong> Lists active ingredients as Diphenhydramine HCI 2%.
                </p>
                <p
                  style={{ backgroundColor: 'rgba(22 230 81 / 57%)' }}
                  onMouseEnter={(e) => showTooltip('<b>Alignment between the product\'s claimed purpose and the supporting clinical data.</b><br/><br/>The review confirms that data used to substantiate the product\'s claims (e.g., itch relief, pain reduction) appears to map appropriately to the intended use described on the label. This demonstrates a strong link between the product\'s functionality and the evidence supporting its effectiveness.', e)}
                >
                  <strong>Purpose:</strong> Describes the use of the product, including its cooling effect on minor burns, scrapes, sunburn, and minor skin irritations due to poison ivy, oak, and poison sumac.
                </p>
                <p><strong>Warnings:</strong> Advises against external use only and cautions not to use on large areas of the body, with other products containing diphenhydramine, or by those under certain medical conditions.</p>
                <p><strong>Insect Bite Relief:</strong> Indicates that it can also be used for insect bites from bees, mosquitoes, and ticks.</p>
                <p><strong>Other Information:</strong> Includes storage temperature information, inactive ingredients list, and questions or comments section.</p>
                <p><strong>Contact Information:</strong> Provides a phone number for questions and a website for additional information.</p>
                <p><strong>Distributed By:</strong> Johnson & Johnson Consumer Inc., Skillman, NJ 08558, USA.</p>
                <p><strong>Made In:</strong> Japan.</p>
                <p><strong>Patent Information:</strong> © J&JCI 2023, Pat. www.jjciats.com.</p>
                <p><strong>Barcode and Numbers:</strong> A barcode with numbers beneath it.</p>
                <p><strong>Minor Burns:</strong> Illustration of insect bites and minor burns.</p>
                <p><strong>Quantity:</strong> "3.5 FL OZ (103 ml)" indicating the volume of the product.</p>
                <p><strong>Bar Code:</strong> Present at the bottom right corner.</p>
                <p><strong>Label Color:</strong> Predominantly pink and #39D688 with white text.</p>
                <p><strong>Label Layout:</strong> The label is well-organized with clear sections for different types of information.</p>
                <p
                  style={{ backgroundColor: 'rgba(240 54 54 / 85%)' }}
                  onMouseEnter={(e) => showTooltip('<b>Non Compliant with Company Branding Guidelines<br/> <br/>Reference:</b>Regulatory Authority Document Title<br/><br/> <b>Recommendation:</b> Include a clear and concise Directions for Use section on the label that details the appropriate application method, frequency, and amount for achieving the intended effect. This section should be easily identifiable and separate from other information with regulatory Requirement', e)}
                >
                  The label currently lacks a dedicated section outlining the product's intended use, often referred to as "Directions for Use." This information is critical for ensuring safe and proper application of the product by consumers.
                </p>
                <p
                  style={{ backgroundColor: 'rgba(240 54 54 / 85%)' }}
                  onMouseEnter={(e) => showTooltip('<b>Non Compliant with Regulatory Guidelines<br/><br/> Reference:</b> Company Branding Guidelines <br/><br/><b>Recommendation:</b> Revise the label background colors to match the approved company color palette as outlined in the branding guidelines. This will ensure brand consistency across all marketing materials and labeling', e)}
                >
                  The label background colors deviate from the approved company branding guidelines. The following inconsistencies were identified:
                </p>
                <ul>
                  <li
                    style={{ backgroundColor: 'rgba(240 54 54 / 85%)' }}
                    onMouseEnter={(e) => showTooltip('<b>Non Compliant with Regulatory Guidelines<br/><br/> Reference:</b> Company Branding Guidelines <br/><br/><b>Recommendation:</b> Revise the label background colors to match the approved company color palette as outlined in the branding guidelines. This will ensure brand consistency across all marketing materials and labeling', e)}
                  >
                    Label Color: #B88296 Correct
                  </li>
                  <li
                    style={{ backgroundColor: 'rgba(240 54 54 / 85%)' }}
                    onMouseEnter={(e) => showTooltip('<b>Non Compliant with Regulatory Guidelines<br/><br/> Reference:</b> Company Branding Guidelines <br/><br/><b>Recommendation:</b> Revise the label background colors to match the approved company color palette as outlined in the branding guidelines. This will ensure brand consistency across all marketing materials and labeling', e)}
                  >
                    Label Color: #3E767B Correct Color: #156082
                  </li>
                  <li
                    style={{ backgroundColor: 'rgba(240 54 54 / 85%)' }}
                    onMouseEnter={(e) => showTooltip('<b>Non Compliant with Regulatory Guidelines<br/><br/> Reference:</b> Company Branding Guidelines <br/><br/><b>Recommendation:</b> Revise the label background colors to match the approved company color palette as outlined in the branding guidelines. This will ensure brand consistency across all marketing materials and labeling', e)}
                  >
                    Label Color: #4CAE47 Correct Color: #3E767B
                  </li>
                </ul>
              </div>
              <div className="glass-card1" style={{ fontFamily: 'New', height: '570px', paddingLeft: '20px' }}>
                <h2>Compliance Score:</h2>
                <table>
                  <thead>
                    <tr>
                      <th>Section</th>
                      <th>Sub-Section</th>
                      <th>%</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td rowSpan="3">Medical</td>
                      <td>1. Claims</td>
                      <td rowSpan="3">100 %</td>
                    </tr>
                    <tr>
                      <td>2. Language & Readability</td>
                    </tr>
                    <tr>
                      <td>3. Content</td>
                    </tr>
                    <tr>
                      <td rowSpan="2">Legal</td>
                      <td>1. Content</td>
                      <td rowSpan="2">100 %</td>
                    </tr>
                    <tr>
                      <td>2. Language & Readability</td>
                    </tr>
                    <tr>
                      <td rowSpan="3">Regulatory</td>
                      <td>1. Policy</td>
                      <td rowSpan="3">70 %</td>
                    </tr>
                    <tr>
                      <td>2. Content</td>
                    </tr>
                    <tr>
                      <td>3. Language & Readability</td>
                    </tr>
                    <tr>
                      <td rowSpan="3">Company Branding</td>
                      <td>1. Logo</td>
                      <td rowSpan="3">70 %</td>
                    </tr>
                    <tr>
                      <td>2. Font</td>
                    </tr>
                    <tr>
                      <td>3. Colour</td>
                    </tr>
                    <tr>
                      <td colSpan="2">Overall Score</td>
                      <td>88.75 %</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          {tooltip.visible && (
            <div className="tooltip1" style={{ top: tooltip.y, left: tooltip.x }} dangerouslySetInnerHTML={{ __html: tooltip.content }} />
          )}
        </>
      )}
    </div>
  );
};

export default ContentReview;
