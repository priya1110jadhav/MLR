import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import FadeLoader from 'react-spinners/FadeLoader';
import './styles.css';

const ContentRecreation = () => {
    const navigate = useNavigate();
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const timer = setTimeout(() => {
            setLoading(false);
        }, 2000);

        return () => clearTimeout(timer);
    }, []);

    return (
        <div className="main-container">
            {loading ? (
                <div className="loader-container">
                    <FadeLoader color="#123abc" loading={loading} size={150} />
                </div>
            ) : (
                <>
                    <video className="background-video" autoPlay loop muted>
                        <source src="/recreationBackground4.mp4" type="video/mp4" />
                        Your browser does not support the video tag.
                    </video>
                    <h1 className="app-title">Marketing Material Compliance - Content Creator</h1>
                    <div className="cardContainer">
                        <div className="cardReview">
                            <h2 className='cardTitle'>Email Content</h2>
                            <p className='cardContent'>
                                Subject: Fast Relief for Allergies with Benadryl Allergy Liquid Gels
                                <br /><br />
                                Dear [Recipient's Name],
                                <br /><br />
                                We understand how quickly allergies can disrupt your day. That’s why we are excited to introduce Benadryl Allergy Liquid Gels, designed to provide powerful relief when you need it most.
                                <br /><br />
                                Why choose Benadryl Allergy Liquid Gels?
                                <br /><br />
                                Fast-acting relief: Our formula works quickly to alleviate allergy symptoms.
                                Dye-free: Ideal for those who prefer a dye-free option.
                                Trusted brand: Benadryl is a leading name in allergy relief.
                                <br /><br />
                                Features:
                                <br /><br />
                                Effective against sneezing, itching, and watery eyes
                                Easy-to-swallow liquid gel form
                                <br /><br />
                                Important Information:
                                <br /><br />
                                Always read and follow label directions.
                                Use only as directed.
                                <br /><br />
                                Don’t let allergies hold you back. Choose Benadryl Allergy Liquid Gels for fast and effective relief.
                                <br /><br />
                                Best regards,
                                <br /><br />
                                [Your Name]
                                [Your Position]
                                [Your Contact Information]
                                [Company Name]
                                <br /><br />
                                This email contains confidential information and is intended only for the recipient. Please do not share or distribute this content without prior authorization.
                            </p>
                        </div>
                        <div className="cardReview">
                            <h2 className='cardTitle'>Social Media Post</h2>
                            <p className='cardContent'>
                                🕒🌸 Allergies can hit fast. Get powerful relief with Benadryl Allergy Liquid Gels! 🌟💧
                                <br /><br />
                                #AllergyRelief #FastActing #DyeFree #Benadryl
                                <br /><br />
                                ✨ Say goodbye to sneezing, itching, and watery eyes with our dye-free liquid gel form. 🌼💪
                                <br /><br />
                                🔹 Always read and follow label directions.
                                🔹 Use only as directed.
                                <br /><br />
                                Feel the relief you need, just when you need it. 💙 #StayHealthy #AllergySeason #BenadrylRelief  <br /> #(40-60)Female
                            </p>
                        </div>
                        <div className="cardReview">
                            <h2 className='cardTitle'>Language Translation</h2>
                            <p className='cardContent'>
                                Las alergias pueden aparecer rápidamente. Obtén un alivio poderoso.
                                <br /><br />
                                Forma de gel líquido sin colorantes
                                <br /><br />
                                Benadryl
                                <br /><br />
                                ALERGY LIQUID GELS
                                <br /><br />
                                Hidrocloruro de difenhidramina 25 mg - Antihistamínico
                                <br /><br />
                                "Lic. L.C.O. USP" es una marca registrada de McNeil Consumer Healthcare Division de McNEIL-PPC, Inc.
                                <br /><br />
                                Use el producto solo como se indica.
                            </p>
                        </div>
                    </div>
                </>
            )}
        </div>
    );
};

export default ContentRecreation;
