import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './styles.css';

const MainComponent = () => {
  const navigate = useNavigate();
  const [file, setFile] = useState(null);
  const [fileName, setFileName] = useState('');
  const [fileSize, setFileSize] = useState('');
  const [previewSrc, setPreviewSrc] = useState('');
  const [isLanguageChecked, setIsLanguageChecked] = useState(false);

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setPreviewSrc(e.target.result);
        setFileName(file.name);
        setFileSize((file.size / 1024).toFixed(2) + ' KB');
      };
      reader.readAsDataURL(file);
      setFile(file);
      console.log("File selected:", file.name, file.size);
    }
  };

  const handleBrowseClick = () => {
    document.getElementById('file-upload').click();
  };

  const handleUpload = () => {
    navigate("/recreation");
  };

  const handleCheckboxChange = (event) => {
    if (event.target.id === 'translate-spanish') {
      setIsLanguageChecked(event.target.checked);
    }
  };

  return (
    <div className="main-container">
      <video className="background-video" autoPlay loop muted>
        <source src="/backgroundVideo.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>
      <div className="content-overlay">
        <h1 className="app-title">Marketing Material Compliance - Content Creator</h1>
        <div className="upload-box">
          <div className="upload-header">
            <img src="/upload.png" alt="Upload Icon" className="upload-icon-image" />
            <h2>Upload Image or Enter Text</h2>
          </div>
          <input
            type="file"
            id="file-upload"
            accept="image/*"
            style={{ display: 'none' }}
            onChange={handleFileChange}
          />
          <div className="button-group">
            <button id="browse-btn" onClick={handleBrowseClick} className="glass-button">
              Browse Image
            </button>
            {!file && (
              <button id="upload-btn" onClick={handleUpload} className="glass-button">
                Upload
              </button>
            )}
            
          </div>
          <input
                  type="text"
                  placeholder="Enter your text here..."
                  className="text-input"
                />
          {file && (
            <>
              <div id="preview">
                <div className="preview-container">
                  <img
                    id="preview-image"
                    src={previewSrc}
                    alt="Image Preview"
                    style={{ maxWidth: '250px', maxHeight: '250px' }}
                  />
                  <div className="file-info-overlay">
                    <div>Name: {fileName}</div>
                    <div>Size: {fileSize}</div>
                  </div>
                </div>
                
                <div className="checkbox-group">
                  <label>
                    <input type="checkbox" id="email-content" /> Email Content
                  </label>
                  <label>
                    <input type="checkbox" id="social-media-post" /> Social Media Post
                  </label>
                  <label>
                    <input
                      type="checkbox"
                      id="translate-spanish"
                      onChange={handleCheckboxChange}
                    /> Language Translation
                  </label>
                </div>
                
                <div className='Dropdowns'>
                <div className="dropdown-group">
                  <select className="dropdown" >
                    <option>Age Group</option>
                    <option>15-20 (Male)</option>
                    <option>20-40 (Male)</option>
                    <option>40-60 (Male)</option>
                    <option>15-20 (Female)</option>
                    <option>20-40 (Female)</option>
                    <option>40-60 (Female)</option>
                  </select>
                </div>
                {isLanguageChecked && (
                  <div className="dropdown-group">
                    <select className="dropdown" style={{marginLeft:'-10px'}} >
                      <option>English</option>
                      <option>Spanish</option>
                      <option>French</option>
                      <option>German</option>
                      <option>Chinese</option>
                      <option>Japanese</option>
                      <option>Hindi</option>
                    </select>
                  </div>
                )}
                </div>
              </div>
              <button id="upload-btn" onClick={handleUpload} className="glass-button">
                Upload
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default MainComponent;
