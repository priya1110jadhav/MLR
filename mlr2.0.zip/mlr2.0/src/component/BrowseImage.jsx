import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './styles.css';

const BrowseImage = () => {
  const navigate = useNavigate();
  const [file, setFile] = useState(null);
  const [fileName, setFileName] = useState('');
  const [fileSize, setFileSize] = useState('');
  const [previewSrc, setPreviewSrc] = useState('');

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setPreviewSrc(e.target.result);
        setFileName(file.name);
        setFileSize((file.size / 1024).toFixed(2) + ' KB');
      };
      reader.readAsDataURL(file);
      setFile(file);
      console.log("File selected:", file.name, file.size);
    }
  };

  const handleBrowseClick = () => {
    document.getElementById('file-upload').click();
  };

  const handleUpload = () => {
    navigate("/review", { state: { file, fileName, fileSize, previewSrc } });
  };

  return (
    <div className="main-container">
      <video className="background-video" autoPlay loop muted>
        <source src="/backgroundVideo.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>
      <div className="content-overlay">
        <h1 className="app-title">Marketing Material Compliance - Content Review</h1>
        <div className="upload-box">
          <img src="/upload.png" alt="Upload Icon" className="upload-icon-image" />
          <h2 style={{marginTop:'0px'}}>Upload Image</h2>
          <label htmlFor="file-upload" className="custom-file-upload">
            <div className="upload-icon"></div>
            {/* <div className="upload-text">
              <h5>Drag and Drop file here</h5>
              <p>Limit 200MB per file - JPG, PNG, JPEG</p>
            </div> */}
          </label>
          <input
            type="file"
            id="file-upload"
            accept="image/*"
            style={{ display: 'none' }}
            onChange={handleFileChange}
          />
          <button id="browse-btn" onClick={handleBrowseClick} className="glass-button">
            Browse Image
          </button>
          {file && (
            <div id="preview">
              <img
                id="preview-image"
                src={previewSrc}
                alt="Image Preview"
                style={{ maxWidth: '300px', maxHeight: '300px' }}
              />
              <table className="fileinfotable">
                <tbody>
                  <tr>
                    <td>Name:</td>
                    <td id="filename">{fileName}</td>
                  </tr>
                  <tr>
                    <td>Size:</td>
                    <td id="filesize">{fileSize}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          )}
          <button id="upload-btn" onClick={handleUpload} className="glass-button">
            Upload
          </button>
        </div>
      </div>
    </div>
  );
};

export default BrowseImage;
